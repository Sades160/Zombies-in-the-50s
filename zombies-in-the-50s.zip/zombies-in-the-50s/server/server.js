const http = require('http');
const fs = require('fs');
const path = require('path');
const { WebSocketServer } = require('ws');

const PORT = process.env.PORT || 8080;
const ROOT = path.join(__dirname, '..');
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'application/javascript', '.css': 'text/css', '.txt': 'text/plain', '.ico': 'image/x-icon' };

function allowed(url) {
  return url === '/index.html' || /^\/(css\/[\w-]+\.css|js\/[\w-]+\.js|js\/lib\/[\w.-]+\.js)$/.test(url);
}

const server = http.createServer((req, res) => {
  let url = decodeURIComponent((req.url || '/').split('?')[0]);
  if (url === '/') url = '/index.html';
  if (!allowed(url)) {
    res.writeHead(404);
    res.end('Not found');
    return;
  }
  if (url === '/js/config.js') {
    res.writeHead(200, { 'Content-Type': 'application/javascript', 'Cache-Control': 'no-cache' });
    res.end("window.DEPOT9_SERVER = '';\n");
    return;
  }
  fs.readFile(path.join(ROOT, url), (err, data) => {
    if (err) {
      res.writeHead(404);
      res.end('Not found');
      return;
    }
    res.writeHead(200, { 'Content-Type': TYPES[path.extname(url)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(data);
  });
});

const rooms = new Map();
let nextId = 1;
const wss = new WebSocketServer({ server, path: '/ws', maxPayload: 16 * 1024 });

wss.on('connection', (ws, req) => {
  const q = new URL(req.url, 'http://x').searchParams;
  const roomName = (q.get('room') || 'public').replace(/[^a-z0-9_-]/gi, '').slice(0, 32) || 'public';
  if (!rooms.has(roomName)) rooms.set(roomName, new Map());
  const room = rooms.get(roomName);
  if (room.size >= 64) {
    ws.close(1013, 'Room full');
    return;
  }
  const id = 'c' + (nextId++).toString(36) + Math.random().toString(36).slice(2, 6);
  const me = { ws, presence: {} };
  room.set(id, me);

  const others = (msg) => {
    const s = JSON.stringify(msg);
    for (const [k, v] of room) if (k !== id && v.ws.readyState === 1) v.ws.send(s);
  };

  ws.send(JSON.stringify({ t: 'hi', id, peers: [...room].filter(([k]) => k !== id).map(([k, v]) => ({ id: k, p: v.presence })) }));
  others({ t: 'p', id, p: me.presence });

  ws.on('message', (buf) => {
    let m;
    try { m = JSON.parse(buf); } catch (e) { return; }
    if (m.t !== 'p' || !m.p || typeof m.p !== 'object') return;
    for (const k in m.p) {
      if (m.p[k] === null) delete me.presence[k];
      else me.presence[k] = m.p[k];
    }
    if (JSON.stringify(me.presence).length > 8000) return;
    others({ t: 'p', id, p: me.presence });
  });

  ws.on('close', () => {
    room.delete(id);
    others({ t: 'bye', id });
    if (!room.size) rooms.delete(roomName);
  });
});

server.listen(PORT, () => console.log(`Zombies in the 50's running at http://localhost:${PORT}`));

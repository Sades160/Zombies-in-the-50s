# Recorded sounds

The game makes all of its sounds in code, so it works with this folder empty. To use real recordings instead, put audio files here (`.ogg`, `.mp3` or `.wav`) and list them in `manifest.json`. Any sound you list replaces the built-in one; anything you leave out keeps the built-in version.

```json
{
  "gun_rifle": ["kar98k-1.ogg", "kar98k-2.ogg"],
  "gun_shotgun": ["trenchgun.ogg"],
  "rip": ["board-rip-1.ogg", "board-rip-2.ogg", "board-rip-3.ogg"],
  "hammer": ["board-hammer.ogg"]
}
```

Listing several files for one sound makes the game pick one at random each time, which keeps repeated shots from sounding identical.

## Sound names

| Name | When it plays |
| --- | --- |
| `gun_pistol` | M1911 |
| `gun_rifle` | Kar98k, Springfield |
| `gun_semi` | M1 Garand |
| `gun_shotgun` | Trench Gun |
| `gun_smg` | Thompson, MP40, PPSh-41 |
| `gun_ar` | BAR, STG-44 |
| `gun_lmg` | MG42 |
| `magout`, `magin`, `boltback`, `boltfwd`, `pump`, `shell`, `clipin`, `slidefwd`, `dry` | Reload and handling |
| `rip` | A zombie tearing a board off a window |
| `hammer` | Nailing a board back up |
| `wood` | A torn board landing on the ground |
| `flesh`, `headshot` | Bullet hits |
| `z_groan`, `z_growl`, `z_scream`, `z_shriek`, `z_snarl`, `z_death` | Zombie voices |
| `boom` | Grenades |
| `step` | Footsteps |

Gunshots sound best as stereo recordings trimmed to start right at the shot, about 1 to 2 seconds long.

## Where to find recordings

Only use sounds whose licence lets you publish them in your game, and keep a note of the author and licence for each file. Good places to look:

- Freesound (freesound.org): filter by the CC0 licence to avoid attribution requirements.
- Sonniss GDC Game Audio Bundles (sonniss.com/gameaudiogdc): large royalty-free packs, including weapons and foley.
- OpenGameArt (opengameart.org): check the licence on each item.

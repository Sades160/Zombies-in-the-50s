# Zombies in the 50's

A wave-survival zombie shooter set in a freight warehouse in October 1953. It runs in the browser with no install.

## Playing

Open `index.html` through any web server, or play the hosted copy on GitHub Pages.

- Solo works everywhere.
- Co-op needs the small relay server in `server/` (see below).
- Easy difficulty adds the Penny Candy machine in the receiving bay.

### Default controls

| | Keyboard / mouse | Controller |
| --- | --- | --- |
| Move / look | WASD / mouse | Left stick / right stick |
| Fire / aim | Left / right mouse | RT / LT |
| Use, buy, repair | F (hold to board up) | X (hold to board up) |
| Reload | R | X |
| Jump | Space | A |
| Crouch / prone | C (hold for prone), Z | B (hold for prone) |
| Sprint | Left Shift | L3 |
| Knife | V | R3 |
| Grenade | G | RB |
| Switch weapon | Q, 1, 2, wheel | Y |
| Flashlight | L | LB |
| Pause | Esc | Start |

Every keyboard binding can be changed in Settings. On phones and tablets the on-screen controls appear automatically.

## Hosting on GitHub Pages

1. Push this folder to a repository.
2. In the repository settings, open **Pages**, pick the branch and the root folder, and save.
3. The game will be live at `https://<your-name>.github.io/<repo>/`.

The `.nojekyll` file stops GitHub from processing the files. Leave it in place.

## Co-op

GitHub Pages only serves files, so co-op needs the relay in `server/` running somewhere that supports Node.js and WebSockets (Render, Railway, Fly.io, a VPS, and so on).

```
cd server
npm install
npm start
```

The server also serves the game itself, so opening its address is enough to play co-op. If you want to keep the game on GitHub Pages and only run the relay elsewhere, set the relay address in `js/config.js`:

```js
window.DEPOT9_SERVER = 'wss://your-relay.example.com/ws';
```

Add `?room=anything` to the link to get a private lobby list for your group.

## Sounds

Every sound is generated in code. To use real recordings for guns, barricades or anything else, drop audio files into `sounds/` and list them in `sounds/manifest.json`. `sounds/README.md` has the full list of sound names.

## Credits

Built on [three.js](https://threejs.org) r128 (MIT, see `js/lib/LICENSE-three.txt`). Every model, texture, sound and piece of music is generated in code at load time, unless you add recordings to `sounds/`.

const T = 0.35;

const MAPS = {
  depot: {
    id: 'depot',
    name: 'Depot 9',
    sub: 'Harlan Freight Co. receiving warehouse',
    when: 'October 1953, 2:40 a.m.',
    blurb:
      'A freight warehouse on the edge of the rail yard. Five areas behind locked-up debris: the receiving bay, the foreman’s office, the break room, the cold storage lockers and the shipping floor. The main power is out.',
    bounds: {
      x0: -26,
      x1: 22,
      z0: -10,
      z1: 22,
    },
    rooms: {
      R: {
        name: 'Receiving Bay',
        x0: -12,
        x1: 12,
        z0: -10,
        z1: 6,
        h: 6.5,
        floor: 'concrete',
        wall: 'paint',
        ceil: 'roof',
        open: true,
        lamps: [
          [-6, -5, 1],
          [6, -5, 0],
          [0, 2, 1],
        ],
      },
      O: {
        name: 'Foreman’s Office',
        x0: 12,
        x1: 22,
        z0: -10,
        z1: 0,
        h: 3.4,
        floor: 'checker',
        wall: 'panel',
        ceil: 'tiles',
        lamps: [[17, -5, 0]],
      },
      B: {
        name: 'Break Room',
        x0: 12,
        x1: 22,
        z0: 0,
        z1: 6,
        h: 3.4,
        floor: 'checker',
        wall: 'paint',
        ceil: 'tiles',
        lamps: [[17, 3, 0]],
      },
      C: {
        name: 'Cold Storage',
        x0: -26,
        x1: -12,
        z0: -10,
        z1: 6,
        h: 4.2,
        floor: 'cold',
        wall: 'tile',
        ceil: 'coldc',
        cold: true,
        lamps: [
          [-19, -5, 1],
          [-19, 2, 0],
        ],
      },
      S: {
        name: 'Shipping Floor',
        x0: -26,
        x1: 22,
        z0: 6,
        z1: 22,
        h: 6.5,
        floor: 'concrete',
        wall: 'paint',
        ceil: 'roof',
        lamps: [
          [-16, 11, 1],
          [-2, 11, 1],
          [12, 11, 0],
          [-8, 20, 1],
        ],
      },
    },
    walls: [
      [
        'x',
        -10,
        -26,
        -12,
        null,
        'C',
        [
          {
            w: 1,
            a: -22,
            b: -20,
          },
        ],
      ],
      [
        'x',
        -10,
        -12,
        12,
        null,
        'R',
        [
          {
            w: 1,
            a: -8.5,
            b: -5.5,
            dock: 1,
          },
          {
            w: 1,
            a: -1,
            b: 1,
          },
          {
            w: 1,
            a: 5.5,
            b: 8.5,
            dock: 1,
          },
        ],
      ],
      [
        'x',
        -10,
        12,
        22,
        null,
        'O',
        [
          {
            w: 1,
            a: 15,
            b: 17,
          },
        ],
      ],
      [
        'z',
        -26,
        -10,
        6,
        null,
        'C',
        [
          {
            w: 1,
            a: -6,
            b: -4,
          },
          {
            w: 1,
            a: 1,
            b: 3,
          },
        ],
      ],
      [
        'z',
        -26,
        6,
        22,
        null,
        'S',
        [
          {
            w: 1,
            a: 12,
            b: 15,
            dock: 1,
          },
        ],
      ],
      [
        'x',
        22,
        -26,
        22,
        'S',
        null,
        [
          {
            w: 1,
            a: -20,
            b: -17,
            dock: 1,
          },
          {
            w: 1,
            a: -4,
            b: -2,
          },
          {
            w: 1,
            a: 10,
            b: 13,
            dock: 1,
          },
        ],
      ],
      [
        'z',
        22,
        -10,
        0,
        'O',
        null,
        [
          {
            w: 1,
            a: -7,
            b: -5,
          },
        ],
      ],
      [
        'z',
        22,
        0,
        6,
        'B',
        null,
        [
          {
            w: 1,
            a: 2,
            b: 4,
          },
        ],
      ],
      [
        'z',
        22,
        6,
        22,
        'S',
        null,
        [
          {
            w: 1,
            a: 14,
            b: 16,
          },
        ],
      ],
      [
        'z',
        -12,
        -10,
        6,
        'C',
        'R',
        [
          {
            d: 1,
            a: -2,
            b: 0,
            cost: 1e3,
          },
        ],
      ],
      [
        'z',
        12,
        -10,
        0,
        'R',
        'O',
        [
          {
            d: 1,
            a: -6,
            b: -4,
            cost: 750,
          },
        ],
      ],
      ['z', 12, 0, 6, 'R', 'B', []],
      [
        'x',
        0,
        12,
        22,
        'O',
        'B',
        [
          {
            d: 1,
            a: 16,
            b: 18,
            cost: 750,
          },
        ],
      ],
      [
        'x',
        6,
        -26,
        -12,
        'C',
        'S',
        [
          {
            d: 1,
            a: -20,
            b: -18,
            cost: 1e3,
          },
        ],
      ],
      [
        'x',
        6,
        -12,
        12,
        'R',
        'S',
        [
          {
            d: 1,
            a: -1,
            b: 1,
            cost: 1250,
          },
        ],
      ],
      [
        'x',
        6,
        12,
        22,
        'B',
        'S',
        [
          {
            d: 1,
            a: 16,
            b: 18,
            cost: 1e3,
          },
        ],
      ],
    ],
    wallbuys: [
      ['karvel', -6, 6 - T / 2, [0, -1]],
      ['scatter', 6, 6 - T / 2, [0, -1]],
      ['ridgeback', 12 + T / 2, -1.6, [1, 0]],
      ['halberd', -23, 6 - T / 2, [0, -1]],
      ['mercer', -7, 6 + T / 2, [0, 1]],
    ],
    sodas: [
      ['titan', 20, -10 + T / 2 + 0.38, [0, 1]],
      ['quick', 12 + T / 2 + 0.38, 1.3, [1, 0]],
      ['rocket', 12 + T / 2 + 0.38, 4.5, [1, 0]],
      ['jet', -26 + T / 2 + 0.38, -1.2, [1, 0]],
      ['second', 22 - T / 2 - 0.38, 9.5, [-1, 0]],
    ],
    crates: [
      [-12 + T / 2 + 0.4, -7, [1, 0]],
      [13.7, -10 + T / 2 + 0.4, [0, 1]],
      [-15.5, -10 + T / 2 + 0.4, [0, 1]],
      [7, 22 - T / 2 - 0.4, [0, -1]],
    ],
    power: [-26 + T / 2 + 0.12, 19.5, [1, 0]],
    press: [17.5, 22 - T / 2 - 0.55, [0, -1]],
    candy: [-12 + T / 2 + 0.35, 4.3, [1, 0]],
    spawns: [
      [0, 1],
      [2, 1.6],
      [-2, 1.6],
      [0, 3.2],
    ],
  },
};

const WORLD = {
  tubes: [],
  powerLights: [],
  press: null,
  candy: null,
  map: null,
  rooms: {},
  windows: [],
  doors: [],
  colliders: [],
  solids: [],
  inter: [],
  lamps: [],
  sodas: [],
  wallbuys: [],
  crate: null,
  power: null,
  radio: null,
  spawns: [],
  dyn: [],
  rain: null,
};

const geoBins = new Map();

function addStatic(g, mat, cast = true) {
  const k = mat.uuid + (cast ? 'c' : 'n');
  if (!geoBins.has(k)) {
    geoBins.set(k, {
      mat: mat,
      cast: cast,
      list: [],
    });
  }
  geoBins.get(k).list.push(g);
}

function addCol(minX, maxX, minZ, maxZ, tag) {
  const c = {
    minX: minX,
    maxX: maxX,
    minZ: minZ,
    maxZ: maxZ,
    on: true,
    tag: tag,
  };
  WORLD.colliders.push(c);
  return c;
}

function addSolid(minX, minY, minZ, maxX, maxY, maxZ, surf = 'conc') {
  const s = {
    min: [minX, minY, minZ],
    max: [maxX, maxY, maxZ],
    surf: surf,
    on: true,
  };
  WORLD.solids.push(s);
  return s;
}

function sbox(x, y, z, w, h, d, mat, o = {}) {
  const g = new THREE.BoxGeometry(w, h, d);
  if (o.ry) {
    g.rotateY(o.ry);
  }
  g.translate(x, y, z);
  if (o.uv !== false) {
    worldUV(g, o.uv || 4);
  }
  addStatic(g, mat, o.cast !== false);
  if (o.col !== false || o.solid !== false) {
    g.computeBoundingBox();
    const b = g.boundingBox;
    if (o.col !== false) {
      addCol(b.min.x, b.max.x, b.min.z, b.max.z, o.tag);
    }
    if (o.solid !== false) {
      addSolid(b.min.x, b.min.y, b.min.z, b.max.x, b.max.y, b.max.z, o.surf || 'conc');
    }
  }
  return g;
}

function sgeo(g, mat, o = {}) {
  if (o.uv) {
    worldUV(g, o.uv);
  }
  addStatic(g, mat, o.cast !== false);
  return g;
}

function finalizeStatic() {
  for (const { mat: mat, cast: cast, list: list } of geoBins.values()) {
    const m = new THREE.Mesh(mergeGeos(list), mat);
    m.castShadow = cast;
    m.receiveShadow = true;
    m.matrixAutoUpdate = false;
    m.updateMatrix();
    scene.add(m);
  }
  geoBins.clear();
}

function roomAt(x, z) {
  for (const k in WORLD.rooms) {
    const r = WORLD.rooms[k];
    if (x >= r.x0 - 0.01 && x <= r.x1 + 0.01 && z >= r.z0 - 0.01 && z <= r.z1 + 0.01) {
      return k;
    }
  }
  return null;
}

function roomOpen(k) {
  return !!(WORLD.rooms[k] && WORLD.rooms[k].open);
}

function buildWall(def) {
  const [axis, c, a0, a1, A, B, ops] = def;
  const rA = A && WORLD.rooms[A],
    rB = B && WORLD.rooms[B];
  const H = Math.max(rA ? rA.h : 0, rB ? rB.h : 0);
  const matFor = (r) => (r ? MAT[r.wall] : MAT.brick);
  const side = (off, mat, a, b, y0, y1) => {
    const m = (a + b) / 2,
      len = b - a,
      cy = (y0 + y1) / 2,
      hh = y1 - y0;
    return axis === 'x'
      ? sbox(m, cy, c + off, len, hh, T / 2, mat, {
          col: false,
          solid: false,
        })
      : sbox(c + off, cy, m, T / 2, hh, len, mat, {
          col: false,
          solid: false,
        });
  };
  const piece = (a, b, y0, y1, collide) => {
    side(-T / 4, matFor(rA), a, b, y0, y1);
    side(T / 4, matFor(rB), a, b, y0, y1);
    if (collide) {
      if (axis === 'x') {
        addCol(a, b, c - T / 2, c + T / 2, 'wall');
      } else {
        addCol(c - T / 2, c + T / 2, a, b, 'wall');
      }
    }
    if (axis === 'x') {
      addSolid(a, y0, c - T / 2, b, y1, c + T / 2, 'conc');
    } else {
      addSolid(c - T / 2, y0, a, c + T / 2, y1, b, 'conc');
    }
  };
  let cur = a0 - T / 2;
  const end = a1 + T / 2;
  for (const o of ops.slice().sort((p, q) => p.a - q.a)) {
    if (o.a > cur) {
      piece(cur, o.a, 0, H, true);
    }
    if (o.w) {
      const sill = o.dock ? 1.05 : 1,
        top = o.dock ? 3 : 2.15;
      if (sill > 0) {
        piece(o.a, o.b, 0, sill, false);
      }
      piece(o.a, o.b, top, H, false);
      buildWindow(axis, c, o, A, B, sill, top);
    } else {
      piece(o.a, o.b, 2.7, H, false);
      buildDoor(axis, c, o, A, B);
    }
    cur = o.b;
  }
  if (cur < end) {
    piece(cur, end, 0, H, true);
  }
}

function buildWindow(axis, c, o, A, B, sill, top) {
  const n = A ? 1 : -1;
  const room = A || B;
  const m = (o.a + o.b) / 2,
    len = o.b - o.a;
  const x = axis === 'x' ? m : c,
    z = axis === 'x' ? c : m,
    nx = axis === 'x' ? 0 : n,
    nz = axis === 'x' ? n : 0;
  const w = {
    i: WORLD.windows.length,
    x: x,
    z: z,
    nx: nx,
    nz: nz,
    axis: axis,
    room: room,
    dock: !!o.dock,
    sill: sill,
    top: top,
    len: len,
    n: 6,
    boards: [],
    busy: null,
    repairT: 0,
  };
  const od = o.dock ? 1.45 : 1.15;
  w.outer = {
    x: x + nx * od,
    z: z + nz * od,
  };
  w.inner = {
    x: x - nx * 1.05,
    z: z - nz * 1.05,
  };
  w.col =
    axis === 'x'
      ? addCol(o.a, o.b, c - T / 2, c + T / 2, 'win')
      : addCol(c - T / 2, c + T / 2, o.a, o.b, 'win');
  const L = len + (w.dock ? 0.45 : 0.32),
    bh = w.dock ? 0.22 : 0.15,
    bt = w.dock ? 0.06 : 0.05;
  const y0 = sill + 0.15,
    y1 = w.dock ? 2.7 : 2;
  const R = mulberry(w.i * 99 + 7);
  for (let i = 0; i < 6; i++) {
    const geo = axis === 'x' ? new THREE.BoxGeometry(L, bh, bt) : new THREE.BoxGeometry(bt, bh, L);
    const b = new THREE.Mesh(geo, MAT.board);
    b.castShadow = true;
    const hx = x - nx * 0.26,
      hz = z - nz * 0.26,
      y = lerp(y0, y1, i / 5),
      tilt = (R() - 0.5) * (w.dock ? 0.22 : 0.3);
    b.position.set(hx, y, hz);
    if (axis === 'x') {
      b.rotation.z = tilt;
    } else {
      b.rotation.x = tilt;
    }
    b.userData = {
      home: new THREE.Vector3(hx, y, hz),
      tilt: tilt,
      anim: null,
    };
    scene.add(b);
    w.boards.push(b);
  }
  const fr = (px, pz, sx, sz, y, h) =>
    sbox(px, y, pz, sx, h, sz, MAT.pineDark, {
      col: false,
      solid: false,
      uv: 1,
    });
  const fh = top - sill,
    fy = sill + fh / 2;
  if (axis === 'x') {
    fr(o.a - 0.04, c, 0.08, T + 0.06, fy, fh);
    fr(o.b + 0.04, c, 0.08, T + 0.06, fy, fh);
  } else {
    fr(c, o.a - 0.04, T + 0.06, 0.08, fy, fh);
    fr(c, o.b + 0.04, T + 0.06, 0.08, fy, fh);
  }
  if (w.dock) {
    const dg = new THREE.CylinderGeometry(0.28, 0.28, len + 0.3, 16);
    if (axis === 'x') {
      dg.rotateZ(Math.PI / 2);
    } else {
      dg.rotateX(Math.PI / 2);
    }
    dg.translate(x + nx * 0.45, top + 0.3, z + nz * 0.45);
    sgeo(dg, MAT.corr);
    const pg = axis === 'x' ? new THREE.BoxGeometry(len, 0.5, 0.04) : new THREE.BoxGeometry(0.04, 0.5, len);
    pg.translate(x + nx * 0.2, top - 0.25, z + nz * 0.2);
    sgeo(pg, MAT.corr, {
      uv: 2,
    });
    const hg =
      axis === 'x' ? new THREE.BoxGeometry(len, 0.015, 0.12) : new THREE.BoxGeometry(0.12, 0.015, len);
    hg.translate(x - nx * 0.02, sill + 0.008, z - nz * 0.02);
    sgeo(hg, MAT.yellowPaint);
    const dk =
      axis === 'x'
        ? new THREE.BoxGeometry(len + 1.2, sill, 0.85)
        : new THREE.BoxGeometry(0.85, sill, len + 1.2);
    dk.translate(x + nx * (T / 2 + 0.425), sill / 2, z + nz * (T / 2 + 0.425));
    worldUV(dk, 4);
    addStatic(dk, MAT.concrete);
    [-1, 1].forEach((sd) => {
      const bum =
        axis === 'x' ? new THREE.BoxGeometry(0.25, 0.35, 0.12) : new THREE.BoxGeometry(0.12, 0.35, 0.25);
      bum.translate(
        x + nx * (T / 2 + 0.9) + (axis === 'x' ? sd * len * 0.35 : 0),
        sill - 0.25,
        z + nz * (T / 2 + 0.9) + (axis === 'z' ? sd * len * 0.35 : 0),
      );
      addStatic(bum, MAT.rubber);
    });
  }
  WORLD.windows.push(w);
  WORLD.inter.push({
    kind: 'window',
    ref: w,
    x: w.inner.x,
    z: w.inner.z,
    r: 2.3,
    hold: true,
    enabled: () => w.n < 6 && roomOpen(w.room),
    label: () => `Hold ${K('use')} to rebuild the barricade`,
  });
}

function setBoardVis(w, i, present, animate) {
  const b = w.boards[i];
  const u = b.userData;
  if (present) {
    b.visible = true;
    if (animate) {
      u.anim = {
        t: 0,
        type: 'in',
        from: b.position.clone(),
        fr: b.rotation.clone(),
      };
    } else {
      u.anim = null;
      b.position.copy(u.home);
      b.rotation.set(w.axis === 'z' ? u.tilt : 0, 0, w.axis === 'x' ? u.tilt : 0);
    }
  } else {
    const lx = w.x + w.nx * rand(1.6, 2.6) + (w.axis === 'x' ? rand(-0.8, 0.8) : 0),
      lz = w.z + w.nz * rand(1.6, 2.6) + (w.axis === 'z' ? rand(-0.8, 0.8) : 0);
    u.ground = {
      x: lx,
      z: lz,
      ry: rand(-0.8, 0.8),
      y: w.dock ? 0.03 : 0.03,
    };
    if (animate) {
      u.anim = {
        t: 0,
        type: 'out',
        from: b.position.clone(),
        fr: b.rotation.clone(),
      };
    } else {
      b.visible = true;
      u.anim = null;
      b.position.set(lx, 0.03, lz);
      b.rotation.set(
        (Math.PI / 2) * (w.axis === 'z' ? 1 : 0),
        u.ground.ry,
        (Math.PI / 2) * (w.axis === 'x' ? 1 : 0),
      );
    }
  }
}

function syncBoards(w, n, animate) {
  n = clamp(n, 0, 6);
  if (n === w.n && !animate) {
    for (let i = 0; i < 6; i++) {
      setBoardVis(w, i, i < n, false);
    }
    return;
  }
  while (w.n < n) {
    setBoardVis(w, w.n, true, animate);
    w.n++;
  }
  while (w.n > n) {
    w.n--;
    setBoardVis(w, w.n, false, animate);
  }
}

function updateBoards(dt) {
  for (const w of WORLD.windows) {
    for (const b of w.boards) {
      const a = b.userData.anim;
      if (!a) {
        continue;
      }
      a.t += dt;
      const u = b.userData;
      if (a.type === 'out') {
        const k = Math.min(1, a.t / 0.7),
          gnd = u.ground;
        const e = 1 - Math.pow(1 - k, 2);
        b.position.set(
          lerp(a.from.x, gnd.x, e),
          lerp(a.from.y, gnd.y, k) + Math.sin(k * Math.PI) * 0.9,
          lerp(a.from.z, gnd.z, e),
        );
        b.rotation.set(
          lerp(a.fr.x, (Math.PI / 2) * (w.axis === 'z' ? 1 : 0), k) + (1 - k) * k * 6,
          lerp(a.fr.y, gnd.ry, k),
          lerp(a.fr.z, (Math.PI / 2) * (w.axis === 'x' ? 1 : 0), k),
        );
        if (k >= 1) {
          u.anim = null;
          if (Math.hypot(b.position.x - ME.x, b.position.z - ME.z) < 30) {
            AU.play('wood', {
              pos: [b.position.x, 0.1, b.position.z],
              g: 0.6,
            });
          }
        }
      } else {
        const k = Math.min(1, a.t / 0.55),
          h = u.home;
        const e = smooth(k);
        b.position.set(
          lerp(a.from.x, h.x, e),
          lerp(a.from.y, h.y, e) + Math.sin(k * Math.PI) * 0.5,
          lerp(a.from.z, h.z, e),
        );
        b.rotation.set(
          lerp(a.fr.x, w.axis === 'z' ? u.tilt : 0, e),
          lerp(a.fr.y, 0, e) + Math.sin(k * Math.PI) * 0.8,
          lerp(a.fr.z, w.axis === 'x' ? u.tilt : 0, e),
        );
        if (k >= 1) {
          u.anim = null;
        }
      }
    }
  }
}

function buildDoor(axis, c, o, A, B) {
  const d = {
    i: WORLD.doors.length,
    axis: axis,
    x: axis === 'x' ? (o.a + o.b) / 2 : c,
    z: axis === 'x' ? c : (o.a + o.b) / 2,
    cost: o.cost,
    rooms: [A, B],
    open: false,
    fade: 0,
  };
  d.col =
    axis === 'x'
      ? addCol(o.a, o.b, c - 0.45, c + 0.45, 'door')
      : addCol(c - 0.45, c + 0.45, o.a, o.b, 'door');
  d.solid =
    axis === 'x'
      ? addSolid(o.a, 0, c - 0.45, o.b, 2.7, c + 0.45, 'wood')
      : addSolid(c - 0.45, 0, o.a, c + 0.45, 2.7, o.b, 'wood');
  const g = new THREE.Group();
  scene.add(g);
  d.group = g;
  d.pieces = [];
  const R = mulberry(d.i * 31 + 3);
  const span = o.b - o.a;
  const put = (geo, mat, px, py, pz, ry, rz) => {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(px, py, pz);
    m.rotation.set(0, ry || 0, rz || 0);
    m.castShadow = true;
    m.receiveShadow = true;
    g.add(m);
    d.pieces.push(m);
    m.userData.home = m.position.clone();
    m.userData.homeR = m.rotation.clone();
    return m;
  };
  const along = (t) => (axis === 'x' ? [lerp(o.a, o.b, t), c] : [c, lerp(o.a, o.b, t)]);
  for (let i = 0; i < 3; i++) {
    const [px, pz] = along(0.2 + i * 0.3);
    put(
      new THREE.BoxGeometry(axis === 'x' ? 0.9 : 0.7, 0.7, axis === 'x' ? 0.7 : 0.9),
      MAT.pine,
      px + (R() - 0.5) * 0.15,
      0.35 + (i === 1 ? 0.7 : 0),
      pz + (R() - 0.5) * 0.15,
      (R() - 0.5) * 0.4,
    );
  }
  {
    const [px, pz] = along(0.5);
    put(
      new THREE.BoxGeometry(axis === 'x' ? 0.8 : 0.6, 0.6, axis === 'x' ? 0.6 : 0.8),
      MAT.pineDark,
      px,
      1.75,
      pz,
      0.3,
    );
  }
  {
    const [px, pz] = along(0.85);
    put(new THREE.CylinderGeometry(0.28, 0.28, 0.85, 14), MAT.redPaint, px, 0.43, pz);
  }
  for (let i = 0; i < 5; i++) {
    const [px, pz] = along(0.5);
    const len = span + 0.4;
    const geo =
      axis === 'x' ? new THREE.BoxGeometry(len, 0.16, 0.05) : new THREE.BoxGeometry(0.05, 0.16, len);
    const m = put(
      geo,
      MAT.board,
      px + (axis === 'z' ? 0.3 : 0),
      0.4 + i * 0.45 + R() * 0.1,
      pz + (axis === 'x' ? 0.3 : 0),
      0,
      0,
    );
    if (axis === 'x') {
      m.rotation.z = (R() - 0.5) * 0.5;
    } else {
      m.rotation.x = (R() - 0.5) * 0.5;
    }
    m.userData.homeR = m.rotation.clone();
  }
  for (let i = 0; i < 5; i++) {
    const [px, pz] = along(0.5);
    const len = span + 0.4;
    const geo =
      axis === 'x' ? new THREE.BoxGeometry(len, 0.16, 0.05) : new THREE.BoxGeometry(0.05, 0.16, len);
    const m = put(
      geo,
      MAT.board,
      px - (axis === 'z' ? 0.3 : 0),
      0.5 + i * 0.42 + R() * 0.1,
      pz - (axis === 'x' ? 0.3 : 0),
    );
    if (axis === 'x') {
      m.rotation.z = (R() - 0.5) * 0.5;
    } else {
      m.rotation.x = (R() - 0.5) * 0.5;
    }
    m.userData.homeR = m.rotation.clone();
  }
  WORLD.doors.push(d);
  WORLD.inter.push({
    kind: 'door',
    ref: d,
    x: d.x,
    z: d.z,
    r: 2.5,
    enabled: () => !d.open,
    label: () => `Press ${K('use')} to clear the debris <span class="c">${d.cost}</span>`,
    use: () => {
      if (spend(d.cost)) {
        sendEvent(['door', d.i]);
      }
    },
  });
}

function setDoorOpen(d, open, animate) {
  if (d.open === open) {
    return;
  }
  d.open = open;
  d.col.on = !open;
  d.solid.on = !open;
  d.rooms.forEach((r) => {
    if (r && open) {
      WORLD.rooms[r].open = true;
    }
  });
  if (open) {
    if (animate) {
      d.fade = 0.001;
      AU.play('clear', {
        pos: [d.x, 1, d.z],
        wet: 0.5,
      });
      spawnFX(d.x, 1, d.z, 30, 'dust');
    } else {
      d.group.visible = false;
    }
  } else {
    d.group.visible = true;
    d.fade = 0;
    d.pieces.forEach((p) => {
      p.position.copy(p.userData.home);
      p.rotation.copy(p.userData.homeR);
    });
  }
  gridBuild();
}

function updateDoors(dt) {
  for (const d of WORLD.doors) {
    if (!d.fade) {
      continue;
    }
    d.fade += dt;
    d.pieces.forEach((p, i) => {
      p.position.y -= dt * (1 + i * 0.15) * d.fade * 2;
      p.rotation.x += dt * (i % 2 ? 1.5 : -1.5);
      p.position.x += (d.axis === 'z' ? (i % 2 ? 1 : -1) : 0) * dt;
      p.position.z += (d.axis === 'x' ? (i % 2 ? 1 : -1) : 0) * dt;
    });
    if (d.fade > 1.6) {
      d.group.visible = false;
      d.fade = 0;
    }
  }
}

function crateBox(x, y, z, w, h, d, ry = 0, mat = MAT.pine) {
  sbox(x, y, z, w, h, d, mat, {
    ry: ry,
    uv: 1,
    surf: 'wood',
  });
  const e = 0.045;
  [
    [-1, -1],
    [1, -1],
    [-1, 1],
    [1, 1],
  ].forEach(([sx, sz]) => {
    const g = new THREE.BoxGeometry(e, h + 0.01, e);
    g.translate(sx * (w / 2 - e / 2 + 0.005), 0, sz * (d / 2 - e / 2 + 0.005));
    if (ry) {
      g.rotateY(ry);
    }
    g.translate(x, y, z);
    sgeo(g, MAT.pineDark, {
      uv: 1,
    });
  });
}

function barrel(x, z, mat, y = 0) {
  const g = new THREE.CylinderGeometry(0.29, 0.29, 0.88, 18);
  g.translate(x, y + 0.44, z);
  sgeo(g, mat);
  [0.15, 0.73].forEach((h) => {
    const r = new THREE.TorusGeometry(0.295, 0.018, 6, 20);
    r.rotateX(Math.PI / 2);
    r.translate(x, y + h, z);
    sgeo(r, MAT.steel);
  });
  addCol(x - 0.29, x + 0.29, z - 0.29, z + 0.29);
  addSolid(x - 0.29, y, z - 0.29, x + 0.29, y + 0.88, z + 0.29, 'metal');
}

function rack(x0, x1, z0, z1, R) {
  const h = 4.2,
    levels = [0.12, 1.45, 2.8, 4.1];
  for (let x = x0; x <= x1 + 0.01; x += (x1 - x0) / Math.max(1, Math.round((x1 - x0) / 2.7))) {
    for (const z of [z0, z1]) {
      sbox(x, h / 2, z, 0.09, h, 0.09, MAT.rack, {
        col: false,
        uv: 1,
        surf: 'metal',
      });
    }
  }
  for (const y of levels) {
    for (const z of [z0, z1]) {
      sbox((x0 + x1) / 2, y, z, x1 - x0, 0.1, 0.06, MAT.rack, {
        col: false,
        solid: false,
        uv: 1,
      });
    }
    sbox((x0 + x1) / 2, y + 0.06, (z0 + z1) / 2, x1 - x0, 0.03, z1 - z0, MAT.pineDark, {
      col: false,
      uv: 1,
      surf: 'wood',
    });
  }
  addCol(x0 - 0.05, x1 + 0.05, z0 - 0.05, z1 + 0.05, 'rack');
  for (let li = 0; li < 3; li++) {
    const y = levels[li] + 0.08;
    let x = x0 + 0.2;
    while (x < x1 - 0.6) {
      const w = 0.6 + R() * 0.7;
      if (R() < 0.78) {
        const hh = 0.45 + R() * 0.7;
        if (R() < 0.25) {
          barrel(x + 0.3, (z0 + z1) / 2, R() < 0.5 ? MAT.redPaint : MAT.metal, y);
          WORLD.colliders.pop();
        } else {
          (crateBox(
            x + w / 2,
            y + hh / 2,
            (z0 + z1) / 2 + (R() - 0.5) * 0.1,
            w - 0.05,
            hh,
            z1 - z0 - 0.12,
            (R() - 0.5) * 0.08,
            R() < 0.5 ? MAT.pine : MAT.pineDark,
          ),
            WORLD.colliders.pop());
        }
      }
      x += w + 0.08;
    }
  }
}

function lampAt(x, z, h, cold, shadowPref) {
  const y = h > 5 ? 4.6 : h - 0.45;
  const cg = new THREE.BoxGeometry(0.015, h - y, 0.015);
  cg.translate(x, (h + y) / 2, z);
  sgeo(cg, MAT.dark, {
    cast: false,
  });
  const shade = new THREE.Mesh(
    new THREE.ConeGeometry(h > 5 ? 0.42 : 0.3, 0.3, 20, 1, true),
    std({
      color: cold ? 6978176 : 3095091,
      roughness: 0.5,
      metalness: 0.6,
      side: THREE.DoubleSide,
    }),
  );
  shade.position.set(x, y, z);
  scene.add(shade);
  const bulbM = new THREE.MeshBasicMaterial({
    color: 16773320,
  });
  const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.07, 10, 8), bulbM);
  bulb.position.set(x, y - 0.12, z);
  scene.add(bulb);
  const col = cold ? 12375807 : 16764820;
  const L = new THREE.SpotLight(col, 0, h * 3.2, 0.95, 0.6, 1.4);
  L.position.set(x, y - 0.1, z);
  L.target.position.set(x, 0, z);
  scene.add(L);
  scene.add(L.target);
  L.shadow.mapSize.set(1024, 1024);
  L.shadow.bias = -8e-4;
  L.shadow.camera.near = 0.3;
  L.shadow.camera.far = h * 3;
  const ch = y - 0.1,
    cone = new THREE.Mesh(
      new THREE.ConeGeometry(ch * 0.95, ch, 24, 1, true),
      new THREE.MeshBasicMaterial({
        map: TX.cone,
        color: col,
        transparent: true,
        opacity: 0.05,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        side: THREE.DoubleSide,
      }),
    );
  cone.position.set(x, ch / 2, z);
  scene.add(cone);
  const glow = glowSprite(col, 1.1, 0.7, false);
  glow.position.set(x, y - 0.15, z);
  scene.add(glow);
  const lp = {
    L: L,
    bulb: bulb,
    bulbM: bulbM,
    cone: cone,
    glow: glow,
    shadowPref: shadowPref,
    cold: cold,
    seed: Math.random() * 100,
    x: x,
    z: z,
    y: y,
    cur: 0,
  };
  WORLD.lamps.push(lp);
  return lp;
}

function applyShadowSetting() {
  const s = SET.video.shadows,
    q = qual();
  let n = 0;
  const order = WORLD.lamps.slice().sort((a, b) => (b.shadowPref ? 1 : 0) - (a.shadowPref ? 1 : 0));
  order.forEach((l) => {
    const on = s === 'high' && n < q.lampShadows;
    if (on) {
      n++;
    }
    l.L.castShadow = on;
    if (l.L.shadow.mapSize.x !== q.shadowRes / 2) {
      l.L.shadow.mapSize.set(q.shadowRes / 2, q.shadowRes / 2);
      if (l.L.shadow.map) {
        l.L.shadow.map.dispose();
        l.L.shadow.map = null;
      }
    }
  });
  if (ME.flashlight) {
    ME.flashlight.castShadow = s !== 'off';
    if (ME.flashlight.shadow.mapSize.x !== q.shadowRes) {
      ME.flashlight.shadow.mapSize.set(q.shadowRes, q.shadowRes);
      if (ME.flashlight.shadow.map) {
        ME.flashlight.shadow.map.dispose();
        ME.flashlight.shadow.map = null;
      }
    }
  }
  ZBS.forEach((z) => z.rig.all.forEach((m) => (m.castShadow = s === 'high')));
  renderer.shadowMap.needsUpdate = true;
}

function buildForklift(x, z, ry) {
  const grp = [];
  const B = (px, py, pz, w, h, d, m) => {
    const g = new THREE.BoxGeometry(w, h, d);
    g.translate(px, py, pz);
    grp.push([g, m]);
  };
  B(0, 0.55, 0, 1.1, 0.7, 1.8, MAT.yellowPaint);
  B(0, 1.05, 0.5, 1, 0.3, 0.7, MAT.yellowPaint);
  B(0, 1.2, -0.1, 0.5, 0.12, 0.45, MAT.rubber);
  [
    [-0.5, -0.5],
    [0.5, -0.5],
    [-0.5, 0.75],
    [0.5, 0.75],
  ].forEach(([px, pz]) => B(px, 1.55, pz, 0.06, 1.3, 0.06, MAT.steel));
  B(0, 2.2, 0.12, 1.06, 0.06, 1.35, MAT.steel);
  B(-0.3, 1.4, -1, 0.08, 2.6, 0.08, MAT.steel);
  B(0.3, 1.4, -1, 0.08, 2.6, 0.08, MAT.steel);
  B(-0.25, 0.08, -1.55, 0.12, 0.05, 1.1, MAT.steel);
  B(0.25, 0.08, -1.55, 0.12, 0.05, 1.1, MAT.steel);
  B(0, 0.5, -1.05, 0.8, 0.8, 0.05, MAT.steel);
  grp.forEach(([g, m]) => {
    g.rotateY(ry);
    g.translate(x, 0, z);
    worldUV(g, 1);
    addStatic(g, m);
  });
  [
    [-0.55, -0.55],
    [0.55, -0.55],
    [-0.55, 0.6],
    [0.55, 0.6],
  ].forEach(([px, pz]) => {
    const w = new THREE.CylinderGeometry(0.26, 0.26, 0.2, 16);
    w.rotateZ(Math.PI / 2);
    w.translate(px, 0.26, pz);
    w.rotateY(ry);
    w.translate(x, 0, z);
    addStatic(w, MAT.rubber);
  });
  const c = Math.cos(ry),
    s = Math.sin(ry);
  const pts = [
    [-0.6, -2.1],
    [0.6, -2.1],
    [-0.6, 1],
    [0.6, 1],
  ].map(([px, pz]) => [x + px * c + pz * s, z - px * s + pz * c]);
  const xs = pts.map((p) => p[0]),
    zs = pts.map((p) => p[1]);
  addCol(Math.min(...xs), Math.max(...xs), Math.min(...zs), Math.max(...zs));
  addSolid(Math.min(...xs), 0, Math.min(...zs), Math.max(...xs), 2.2, Math.max(...zs), 'metal');
}

function buildTruck(x0, x1, z0, z1) {
  const cx = (x0 + x1) / 2,
    cz = (z0 + z1) / 2,
    L = x1 - x0,
    W = z1 - z0;
  const green = std({
    color: 2900530,
    roughness: 0.45,
    metalness: 0.3,
  });
  sbox(
    x0 + L * 0.38,
    1.9,
    cz,
    L * 0.72,
    2.5,
    W,
    std({
      map: textCanvas(512, 256, (g, w, h) => {
        g.fillStyle = '#6a6452';
        g.fillRect(0, 0, w, h);
        blotch(g, w, h, 20, 'rgba(0,0,0,.25)', 20, 80);
        g.fillStyle = '#7a1a12';
        g.fillRect(0, h * 0.3, w, h * 0.32);
        g.fillStyle = '#e8dcc4';
        g.font = '64px Oswald, Impact, sans-serif';
        g.textAlign = 'center';
        g.fillText('HARLAN FREIGHT', w / 2, h * 0.53);
        g.font = '24px "Special Elite", monospace';
        g.fillText('Rail • Road • Cold Storage • Since 1921', w / 2, h * 0.76);
      }),
      roughness: 0.7,
    }),
    {
      uv: false,
      surf: 'metal',
    },
  );
  sbox(x1 - L * 0.14, 1.2, cz, L * 0.26, 1.5, W * 0.92, green, {
    surf: 'metal',
  });
  sbox(x1 - L * 0.1, 2.1, cz, L * 0.16, 0.8, W * 0.88, green, {
    col: false,
  });
  sbox(x1 - L * 0.03, 2.15, cz, 0.02, 0.5, W * 0.8, MAT.glass, {
    col: false,
    solid: false,
  });
  sbox((x0 + x1) / 2, 0.55, cz, L * 0.96, 0.3, W * 0.7, MAT.steel, {
    col: false,
  });
  [
    [x0 + L * 0.15, z0],
    [x0 + L * 0.15, z1],
    [x0 + L * 0.45, z0],
    [x0 + L * 0.45, z1],
    [x1 - L * 0.15, z0],
    [x1 - L * 0.15, z1],
  ].forEach(([px, pz]) => {
    const w = new THREE.CylinderGeometry(0.48, 0.48, 0.3, 18);
    w.rotateX(Math.PI / 2);
    w.translate(px, 0.48, pz);
    addStatic(w, MAT.rubber);
  });
  [z0 + 0.35, z1 - 0.35].forEach((pz) => {
    const h = new THREE.CylinderGeometry(0.13, 0.13, 0.08, 14);
    h.rotateZ(Math.PI / 2);
    h.translate(x1 + 0.01, 1.1, pz);
    addStatic(h, MAT.chrome);
  });
}

function buildCarcass(x, z, R) {
  const g = new THREE.SphereGeometry(0.28, 12, 10);
  g.scale(1, 2.7, 0.75);
  g.rotateY(R() * 3);
  g.translate(x, 2.05, z);
  sgeo(g, MAT.meat);
  const f = new THREE.SphereGeometry(0.2, 10, 8);
  f.scale(1, 2, 0.6);
  f.translate(x + 0.1, 2.2, z + 0.12);
  sgeo(f, MAT.fat);
  const hook = new THREE.TorusGeometry(0.06, 0.012, 6, 12, Math.PI * 1.4);
  hook.translate(x, 2.95, z);
  sgeo(hook, MAT.steel, {
    cast: false,
  });
  const ch = new THREE.BoxGeometry(0.02, 0.6, 0.02);
  ch.translate(x, 3.3, z);
  sgeo(ch, MAT.steel, {
    cast: false,
  });
  addCol(x - 0.3, x + 0.3, z - 0.25, z + 0.25, 'meat');
  addSolid(x - 0.3, 1.3, z - 0.25, x + 0.3, 2.8, z + 0.25, 'flesh');
}

const PERKS = {
  titan: {
    name: 'Titan Tonic',
    short: 'Titan',
    desc: 'Take more hits before going down',
    cost: 2500,
    color: '#8e1b16',
    ink: '#f3e6c8',
    hex: 9313046,
    bottle: 4852232,
    tag: 'Stands up to anything',
  },
  quick: {
    name: 'Quick-Draw Cream Soda',
    short: 'Quick-Draw',
    desc: 'Reload twice as fast',
    cost: 3e3,
    color: '#c3952a',
    ink: '#3a1e0a',
    hex: 12817706,
    bottle: 9067024,
    tag: 'Fastest hands in town',
  },
  rocket: {
    name: 'Rocket Pop',
    short: 'Rocket',
    desc: 'Fire 35% faster',
    cost: 2e3,
    color: '#1d8084',
    ink: '#f4efe2',
    hex: 1933444,
    bottle: 936524,
    tag: 'Out of this world!',
  },
  second: {
    name: 'Second Chance Sarsaparilla',
    short: 'Second Chance',
    desc: 'Solo: get back up once. Co-op: revive twice as fast',
    cost: 1500,
    color: '#2e5a34',
    ink: '#ecdfbc',
    hex: 3037748,
    bottle: 1718812,
    tag: 'Never say die',
  },
  jet: {
    name: 'Jet Stream Ginger Ale',
    short: 'Jet Stream',
    desc: 'Move and sprint faster',
    cost: 2e3,
    color: '#3b6ea5',
    ink: '#f2ead6',
    hex: 3894949,
    bottle: 2771568,
    tag: 'Goes like a jet',
  },
};

const PERK_ICONS = {};

function perkIcon(id) {
  if (PERK_ICONS[id]) {
    return PERK_ICONS[id];
  }
  const p = PERKS[id];
  const [c, g] = mkC(96, 96);
  g.beginPath();
  for (let i = 0; i < 42; i++) {
    const a = (i / 42) * TAU,
      r = i % 2 ? 44 : 47;
    g.lineTo(48 + Math.cos(a) * r, 48 + Math.sin(a) * r);
  }
  g.closePath();
  const gr = g.createRadialGradient(40, 36, 4, 48, 48, 48);
  gr.addColorStop(0, '#fff');
  gr.addColorStop(0.25, p.color);
  gr.addColorStop(1, '#111');
  g.fillStyle = gr;
  g.fill();
  g.fillStyle = p.color;
  g.beginPath();
  g.arc(48, 48, 36, 0, TAU);
  g.fill();
  g.strokeStyle = p.ink;
  g.lineWidth = 3;
  g.beginPath();
  g.arc(48, 48, 31, 0, TAU);
  g.stroke();
  g.fillStyle = p.ink;
  g.font = '38px Yellowtail, cursive';
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  g.fillText(p.short[0], 48, 52);
  return (PERK_ICONS[id] = c.toDataURL());
}

function sodaFace(p) {
  return textCanvas(320, 640, (g, w, h) => {
    const gr = g.createLinearGradient(0, 0, 0, h);
    gr.addColorStop(0, p.color);
    gr.addColorStop(1, '#1a1210');
    g.fillStyle = gr;
    g.fillRect(0, 0, w, h);
    g.fillStyle = p.ink;
    g.beginPath();
    g.arc(w / 2, 150, 124, 0, TAU);
    g.fill();
    g.fillStyle = p.color;
    g.beginPath();
    g.arc(w / 2, 150, 112, 0, TAU);
    g.fill();
    g.fillStyle = p.ink;
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    const words = p.short.split(' ');
    g.font = (words.length > 1 ? 64 : 76) + 'px Yellowtail, cursive';
    words.forEach((wd, i) => g.fillText(wd, w / 2, 140 + (i - (words.length - 1) / 2) * 62));
    g.font = '20px Oswald, sans-serif';
    g.fillText('ICE COLD', w / 2, 238);
    g.fillStyle = '#0d0b0a';
    g.fillRect(40, 300, w - 80, 170);
    g.strokeStyle = '#d8d8d8';
    g.lineWidth = 6;
    g.strokeRect(40, 300, w - 80, 170);
    for (let i = 0; i < 3; i++) {
      const bx = 80 + i * 80;
      const bc = '#' + p.bottle.toString(16).padStart(6, '0');
      g.fillStyle = bc;
      g.fillRect(bx - 16, 340, 32, 110);
      g.fillRect(bx - 8, 318, 16, 28);
      g.fillStyle = 'rgba(255,255,255,.35)';
      g.fillRect(bx - 11, 350, 5, 90);
      g.fillStyle = p.ink;
      g.fillRect(bx - 16, 380, 32, 30);
    }
    g.fillStyle = p.ink;
    g.font = '22px "Special Elite", monospace';
    g.fillText(p.tag, w / 2, 505);
    g.fillStyle = '#d8d8d8';
    g.fillRect(60, 540, w - 120, 64);
    g.fillStyle = '#1a1210';
    g.font = '40px Oswald, sans-serif';
    g.fillText(String(p.cost), w / 2, 574);
  });
}

function buildSoda(id, x, z, face) {
  const p = PERKS[id];
  const grp = new THREE.Group();
  grp.position.set(x, 0, z);
  grp.rotation.y = Math.atan2(face[0], face[1]);
  scene.add(grp);
  const MW = 0.86,
    Hs = 1.55,
    Rr = MW / 2,
    D = 0.72;
  const sh = new THREE.Shape();
  sh.moveTo(-MW / 2, 0);
  sh.lineTo(MW / 2, 0);
  sh.lineTo(MW / 2, Hs);
  sh.absarc(0, Hs, Rr, 0, Math.PI, false);
  sh.lineTo(-MW / 2, 0);
  const bodyG = new THREE.ExtrudeGeometry(sh, {
    depth: D - 0.04,
    bevelEnabled: true,
    bevelThickness: 0.02,
    bevelSize: 0.02,
    bevelSegments: 3,
    curveSegments: 24,
  });
  bodyG.translate(0, 0.06, -(D - 0.04) / 2);
  const body = new THREE.Mesh(
    bodyG,
    std({
      color: p.hex,
      roughness: 0.32,
      metalness: 0.35,
    }),
  );
  body.castShadow = true;
  grp.add(body);
  const fg = new THREE.ShapeGeometry(sh, 24);
  const pos = fg.attributes.position,
    uv = fg.attributes.uv;
  for (let i = 0; i < pos.count; i++) {
    uv.setXY(i, (pos.getX(i) + MW / 2) / MW, pos.getY(i) / (Hs + Rr));
  }
  fg.scale(0.9, 0.94, 1);
  fg.translate(0, 0.1, D / 2 + 0.005);
  const tex = sodaFace(p);
  const fm = std({
    map: tex,
    emissiveMap: tex,
    emissive: 0,
    roughness: 0.3,
  });
  grp.add(new THREE.Mesh(fg, fm));
  [-1, 1].forEach((sx) => {
    const t = new THREE.Mesh(new THREE.BoxGeometry(0.025, Hs, 0.03), MAT.chrome);
    t.position.set(sx * (MW / 2 + 0.005), 0.06 + Hs / 2, D / 2 - 0.02);
    grp.add(t);
  });
  const arc = new THREE.Mesh(new THREE.TorusGeometry(Rr + 0.005, 0.014, 6, 30, Math.PI), MAT.chrome);
  arc.position.set(0, 0.06 + Hs, D / 2 - 0.02);
  grp.add(arc);
  const handle = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.3, 0.05), MAT.chrome);
  handle.position.set(MW / 2 - 0.09, 0.95, D / 2 + 0.03);
  grp.add(handle);
  const opener = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.05, 0.05), MAT.chrome);
  opener.position.set(-0.2, 0.7, D / 2 + 0.03);
  grp.add(opener);
  [-1, 1].forEach((sx) =>
    [-1, 1].forEach((sz) => {
      const f = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.04, 0.06, 8), MAT.chrome);
      f.position.set(sx * 0.36, 0.03, sz * 0.28);
      grp.add(f);
    }),
  );
  const glow = glowSprite(p.hex, 2.4, 0, false);
  glow.position.set(0, 1.3, D / 2 + 0.3);
  grp.add(glow);
  const halfW = Math.abs(face[0]) > 0 ? D / 2 : MW / 2,
    halfD = Math.abs(face[0]) > 0 ? MW / 2 : D / 2;
  addCol(x - halfW, x + halfW, z - halfD, z + halfD, 'soda');
  addSolid(x - halfW, 0, z - halfD, x + halfW, 2, z + halfD, 'metal');
  const s = {
    id: id,
    fm: fm,
    glow: glow,
    grp: grp,
    x: x,
    z: z,
  };
  WORLD.sodas.push(s);
  WORLD.inter.push({
    kind: 'soda',
    ref: s,
    x: x + face[0] * 1,
    z: z + face[1] * 1,
    r: 1.7,
    enabled: () => !ME.perks.has(id) && W.drinkT <= 0,
    label: () =>
      !G.power
        ? `${p.name}. The machine is dark. Throw the main power on the shipping floor.`
        : `Press ${K('use')} to buy ${p.name} <span class="c">${p.cost}</span><br><small>${p.desc}</small>`,
    use: () => {
      if (!G.power) {
        AU.play('denied');
        return;
      }
      if (spend(p.cost)) {
        drinkPerk(id);
      }
    },
  });
}

function setPower(on, animate) {
  G.power = on;
  WORLD.sodas.forEach((s) => {
    s.fm.emissive.set(on ? 9079434 : 0);
    s.glow.material.opacity = on ? 0.35 : 0;
  });
  if (WORLD.power) {
    WORLD.power.lampM.color.set(on ? 3407718 : 11147792);
    WORLD.power.anim = on && animate ? 0.001 : 0;
    WORLD.power.lever.rotation.x = on && !animate ? -1.1 : 0.9;
  }
  WORLD.tubes.forEach((t) => {
    t.mat.color.set(on ? 16054271 : 2763822);
    t.glow.material.opacity = on ? 0.45 : 0;
  });
  WORLD.powerLights.forEach((l) => {
    l.target = on ? l.base : 0;
    if (!animate) {
      l.L.intensity = l.target;
    }
  });
  ambient.intensity = on ? 0.5 : 0.4;
  hemi.userData.base = on ? 0.38 : 0.3;
  if (on && animate) {
    AU.play('lever', {
      pos: [WORLD.power.x, 1.4, WORLD.power.z],
    });
    flashScreen(0.25);
  }
  if (on) {
    AU.loop('hum', 'hum', {
      pos: [WORLD.power.x, 1.5, WORLD.power.z],
      ref: 3,
      g: 0.5,
    });
  } else {
    AU.stopLoop('hum');
  }
  if (WORLD.radio) {
    AU.loopGain('radio', on ? 0.9 : 0.35);
  }
}

function buildWallBuy(id, x, z, face) {
  const d = GUNS[id];
  const grp = new THREE.Group();
  grp.position.set(x + face[0] * 0.01, 0, z + face[1] * 0.01);
  grp.rotation.y = Math.atan2(face[0], face[1]);
  scene.add(grp);
  const sign = textCanvas(512, 256, (g, w, h) => {
    g.fillStyle = '#2a211a';
    g.fillRect(0, 0, w, h);
    for (let i = 0; i < 4; i++) {
      g.fillStyle = `rgba(255,255,255,${rand(0.02, 0.05)})`;
      g.fillRect(0, i * 64, w, 2);
    }
    g.strokeStyle = '#c9b88f';
    g.lineWidth = 6;
    g.strokeRect(10, 10, w - 20, h - 20);
    g.fillStyle = '#e8dcc4';
    g.textAlign = 'center';
    g.font = '44px Oswald, Impact, sans-serif';
    g.fillText(d.name.toUpperCase(), w / 2, 196);
    g.fillStyle = '#e0a040';
    g.font = '40px "Special Elite", monospace';
    g.fillText(String(d.wall), w / 2, 238);
    blotch(g, w, h, 12, 'rgba(0,0,0,.35)', 10, 50);
  });
  const pm = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.75, 0.03), [
    MAT.pineDark,
    MAT.pineDark,
    MAT.pineDark,
    MAT.pineDark,
    std({
      map: sign,
      roughness: 0.8,
    }),
    MAT.pineDark,
  ]);
  pm.position.set(0, 1.55, 0.02);
  grp.add(pm);
  const gun = d.build().g;
  gun.rotation.y = Math.PI / 2;
  gun.position.set(0, 1.62, 0.09);
  gun.traverse((o) => {
    if (o.isMesh) {
      o.castShadow = true;
    }
  });
  grp.add(gun);
  [-0.3, 0.3].forEach((px) => {
    const peg = new THREE.Mesh(cyl(0.01, 0.08), MAT.steel);
    peg.position.set(px, 1.56, 0.07);
    grp.add(peg);
  });
  WORLD.inter.push({
    kind: 'wall',
    x: x + face[0] * 0.7,
    z: z + face[1] * 0.7,
    r: 1.9,
    label: () => {
      const own = ownSlot(id);
      return own
        ? `Press ${K('use')} to buy ammo for the ${d.name} <span class="c">${Math.floor(d.wall / 2)}</span>`
        : `Press ${K('use')} to buy the ${d.name} <span class="c">${d.wall}</span>`;
    },
    use: () => {
      const own = ownSlot(id);
      if (own) {
        if (own.res >= d.res && own.mag >= d.mag) {
          return;
        }
        if (spend(Math.floor(d.wall / 2))) {
          own.res = d.res;
          own.mag = d.mag;
        }
      } else if (spend(d.wall)) {
        giveWeapon(id);
      }
    },
  });
}

function buildCrate(spots) {
  const grp = new THREE.Group();
  scene.add(grp);
  const tex = textCanvas(512, 256, (g, w, h) => {
    g.drawImage(TX.pine.image, 0, 0, w, h);
    g.fillStyle = 'rgba(15,12,10,.75)';
    g.font = '46px Oswald, Impact, sans-serif';
    g.textAlign = 'center';
    g.fillText('FRAGILE', w / 2, 92);
    g.font = '28px "Special Elite", monospace';
    g.fillText('CONTENTS UNKNOWN • DEPOT 9', w / 2, 150);
    g.strokeStyle = 'rgba(15,12,10,.75)';
    g.lineWidth = 5;
    g.strokeRect(40, 40, w - 80, 140);
  });
  const sideM = std({
    map: tex,
    roughness: 0.8,
  });
  const W = 1.7,
    H = 0.78,
    D = 0.78;
  const body = new THREE.Mesh(new THREE.BoxGeometry(W, H, D), [
    MAT.pineDark,
    MAT.pineDark,
    MAT.pine,
    MAT.pine,
    sideM,
    sideM,
  ]);
  body.position.y = H / 2;
  body.castShadow = true;
  body.receiveShadow = true;
  grp.add(body);
  [
    [-1, -1],
    [1, -1],
    [-1, 1],
    [1, 1],
  ].forEach(([sx, sz]) => {
    const b = new THREE.Mesh(new THREE.BoxGeometry(0.07, H + 0.02, 0.07), MAT.steel);
    b.position.set(sx * (W / 2 - 0.03), H / 2, sz * (D / 2 - 0.03));
    grp.add(b);
  });
  const inner = new THREE.Mesh(
    new THREE.PlaneGeometry(W - 0.1, D - 0.1),
    new THREE.MeshBasicMaterial({
      color: 1050628,
    }),
  );
  inner.rotation.x = -Math.PI / 2;
  inner.position.y = H - 0.02;
  grp.add(inner);
  const lidP = new THREE.Group();
  lidP.position.set(0, H, -D / 2);
  grp.add(lidP);
  const lid = new THREE.Mesh(new THREE.BoxGeometry(W + 0.04, 0.07, D + 0.04), MAT.pine);
  lid.position.set(0, 0.035, D / 2);
  lid.castShadow = true;
  lidP.add(lid);
  const glow = glowSprite(16756816, 2.6, 0, false);
  glow.position.y = 1.2;
  grp.add(glow);
  const cage = new THREE.Group();
  cage.position.set(0, 3.2, 0);
  grp.add(cage);
  const cb = new THREE.Mesh(new THREE.SphereGeometry(0.07, 10, 8), MAT.bulb);
  cage.add(cb);
  for (let i = 0; i < 4; i++) {
    const w = new THREE.Mesh(new THREE.TorusGeometry(0.11, 0.006, 4, 14), MAT.steel);
    w.rotation.y = (i * Math.PI) / 4;
    cage.add(w);
  }
  const cord = new THREE.Mesh(new THREE.BoxGeometry(0.012, 3, 0.012), MAT.dark);
  cord.position.y = 1.55;
  cage.add(cord);
  const cglow = glowSprite(16765072, 0.9, 0.8, false);
  cage.add(cglow);
  const L = new THREE.PointLight(16760944, 0.9, 6, 2);
  L.position.set(0, 1.4, 0.4);
  grp.add(L);
  const col = addCol(0, 0, 0, 0, 'crate');
  const sol = addSolid(0, 0, 0, 0, 0, 0, 'wood');
  WORLD.crate = {
    grp: grp,
    lidP: lidP,
    glow: glow,
    cage: cage,
    L: L,
    col: col,
    sol: sol,
    spots: spots,
    spot: 0,
    disp: null,
    dispId: null,
    state: 'idle',
    t: 0,
    cyc: 0,
    H: H,
  };
  placeCrate(0);
  WORLD.inter.push({
    kind: 'crate',
    get x() {
      return WORLD.crate.ix;
    },
    get z() {
      return WORLD.crate.iz;
    },
    r: 2.1,
    enabled: () => {
      const c = G.crate;
      return c.state === 'idle' || (c.state === 'ready' && c.owner === NET.me);
    },
    label: () =>
      G.crate.state === 'idle'
        ? `Press ${K('use')} to open the supply crate <span class="c">${CRATE_COST}</span>`
        : `Press ${K('use')} to take the ${GUNS[G.crate.result].name}`,
    use: () => {
      const c = G.crate;
      if (c.state === 'idle') {
        if (spend(CRATE_COST)) {
          sendEvent(['crate']);
        }
      } else if (c.state === 'ready' && c.owner === NET.me) {
        giveWeapon(c.result);
        sendEvent(['crtake']);
      }
    },
  });
}

function placeCrate(i) {
  const C = WORLD.crate;
  C.spot = i;
  const [x, z, f] = C.spots[i];
  C.grp.position.set(x, 0, z);
  C.grp.rotation.y = Math.atan2(f[0], f[1]);
  const side = Math.abs(f[0]) > 0;
  const hw = side ? 0.4 : 0.85,
    hd = side ? 0.85 : 0.4;
  Object.assign(C.col, {
    minX: x - hw,
    maxX: x + hw,
    minZ: z - hd,
    maxZ: z + hd,
  });
  C.sol.min = [x - hw, 0, z - hd];
  C.sol.max = [x + hw, 0.8, z + hd];
  C.ix = x + f[0] * 1;
  C.iz = z + f[1] * 1;
  if (gridReady) {
    gridBuild();
  }
}

function crateDisplay(id) {
  const C = WORLD.crate;
  if (C.dispId === id && C.disp) {
    return;
  }
  if (C.disp) {
    C.grp.remove(C.disp);
  }
  C.disp = id ? GUNS[id].build().g : null;
  C.dispId = id;
  if (C.disp) {
    C.disp.scale.setScalar(1.3);
    C.disp.rotation.y = Math.PI / 2;
    C.grp.add(C.disp);
  }
}

function updateCrateVisual(dt) {
  const C = WORLD.crate,
    S = G.crate;
  C.t += dt;
  if (S.spot !== C.spot && S.state !== 'moving') {
    placeCrate(S.spot);
  }
  const open = S.state === 'rolling' || S.state === 'ready' || (S.state === 'moving' && S.t < 1.5);
  C.lidP.rotation.x = damp(C.lidP.rotation.x, open ? -1.95 : 0, 8, dt);
  C.glow.material.opacity = damp(C.glow.material.opacity, open ? 0.8 : 0, 5, dt);
  C.L.intensity = (open ? 2.2 : 0.9) + Math.sin(G.time * 11) * 0.08;
  C.cage.rotation.z = Math.sin(G.time * 0.9) * 0.06;
  if (S.state === 'rolling') {
    const k = clamp(S.t / 4.6, 0, 1);
    C.cyc -= dt;
    if (C.cyc <= 0) {
      crateDisplay(k > 0.96 ? S.result : pick(CRATE_POOL));
      C.cyc = lerp(0.06, 0.32, k * k);
    }
    if (C.disp) {
      C.disp.position.y = 0.7 + k * 0.85;
    }
  } else if (S.state === 'ready') {
    crateDisplay(S.result);
    if (C.disp) {
      C.disp.position.y = 1.55 - Math.max(0, S.t - 9) * 0.35;
    }
  } else if (C.disp && S.state !== 'moving') {
    crateDisplay(null);
  }
  if (S.state === 'moving') {
    crateDisplay(null);
    const y =
      S.t < 2.4 ? -Math.min(1.2, Math.max(0, S.t - 1.2) * 1.2) : -1.2 + Math.min(1.2, (S.t - 2.4) * 1.2);
    if (S.t >= 2.4 && C.spot !== S.spot) {
      placeCrate(S.spot);
    }
    C.grp.position.y = y;
  } else {
    C.grp.position.y = 0;
  }
}

function buildPower(x, z, face) {
  const grp = new THREE.Group();
  grp.position.set(x, 0, z);
  grp.rotation.y = Math.atan2(face[0], face[1]);
  scene.add(grp);
  const box = new THREE.Mesh(new THREE.BoxGeometry(0.9, 1.2, 0.22), MAT.metal);
  box.position.set(0, 1.5, 0);
  box.castShadow = true;
  grp.add(box);
  const sign = textCanvas(256, 96, (g, w, h) => {
    g.fillStyle = '#c9b12a';
    g.fillRect(0, 0, w, h);
    g.fillStyle = '#111';
    for (let i = -2; i < 12; i++) {
      g.beginPath();
      g.moveTo(i * 26, 0);
      g.lineTo(i * 26 + 13, 0);
      g.lineTo(i * 26 - 7, h);
      g.lineTo(i * 26 - 20, h);
      g.fill();
    }
    g.fillStyle = '#111';
    g.fillRect(20, 20, w - 40, h - 40);
    g.fillStyle = '#e8dcc4';
    g.font = '34px Oswald, sans-serif';
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    g.fillText('MAIN POWER', w / 2, h / 2 + 2);
  });
  const sm = new THREE.Mesh(
    new THREE.PlaneGeometry(0.8, 0.3),
    std({
      map: sign,
    }),
  );
  sm.position.set(0, 2.35, 0.01);
  grp.add(sm);
  const lever = new THREE.Group();
  lever.position.set(0, 1.45, 0.14);
  grp.add(lever);
  const arm = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.45, 0.05), MAT.steel);
  arm.position.y = 0.22;
  lever.add(arm);
  const knob = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.07, 0.07), MAT.rubber);
  knob.position.y = 0.45;
  lever.add(knob);
  lever.rotation.x = 0.9;
  const hand = new THREE.Group();
  hand.position.set(-0.06, 0.45, 0);
  lever.add(hand);
  const skin = ZM.skins[0];
  const palm = new THREE.Mesh(rbox(0.075, 0.085, 0.04, 0.015), skin);
  palm.position.set(0, 0, 0.045);
  hand.add(palm);
  for (let i = 0; i < 4; i++) {
    const f = new THREE.Group();
    f.position.set(-0.027 + i * 0.018, 0.035 - Math.abs(i - 1.5) * 0.005, 0.04);
    hand.add(f);
    const f1 = new THREE.Mesh(rbox(0.015, 0.016, 0.04, 0.006), skin);
    f1.position.z = -0.02;
    f.rotation.x = 1.25;
    f.add(f1);
    const f2 = new THREE.Group();
    f2.position.z = -0.04;
    f2.rotation.x = 1.3;
    f.add(f2);
    const f3 = new THREE.Mesh(rbox(0.014, 0.015, 0.032, 0.006), skin);
    f3.position.z = -0.016;
    f2.add(f3);
  }
  const thumb = new THREE.Mesh(rbox(0.018, 0.018, 0.045, 0.007), skin);
  thumb.position.set(0.045, -0.02, 0.02);
  thumb.rotation.set(0.9, 0.5, 0);
  hand.add(thumb);
  const wrist = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.034, 0.16, 12), skin);
  wrist.position.set(-0.01, -0.08, 0.09);
  wrist.rotation.x = -0.9;
  hand.add(wrist);
  const stump = new THREE.Mesh(new THREE.CircleGeometry(0.034, 12), ZM.stump);
  stump.position.set(-0.01, -0.13, 0.155);
  stump.rotation.x = 0.7;
  hand.add(stump);
  const bone = new THREE.Mesh(new THREE.CylinderGeometry(0.009, 0.009, 0.05, 8), MAT.fat);
  bone.position.set(-0.012, -0.15, 0.17);
  bone.rotation.x = -0.9;
  hand.add(bone);
  for (let i = 0; i < 5; i++) {
    const d = new THREE.Mesh(new THREE.SphereGeometry(0.012 + Math.random() * 0.01, 6, 5), ZM.stump);
    d.position.set(rand(-0.2, 0.2), rand(-0.3, 0.2), 0.115);
    d.scale.z = 0.2;
    grp.add(d);
    d.position.y += 1.45;
  }
  const lampM = new THREE.MeshBasicMaterial({
    color: 11147792,
  });
  const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.04, 8, 6), lampM);
  lamp.position.set(0.32, 1.95, 0.12);
  grp.add(lamp);
  const [cw, cd] = Math.abs(face[0]) > 0 ? [0.25, 0.5] : [0.5, 0.25];
  addCol(x - cw, x + cw, z - cd, z + cd, 'power');
  WORLD.power = {
    x: x,
    z: z,
    lever: lever,
    lampM: lampM,
    grp: grp,
    anim: 0,
  };
  WORLD.inter.push({
    kind: 'power',
    x: x + face[0] * 0.9,
    z: z + face[1] * 0.9,
    r: 1.8,
    enabled: () => !G.power,
    label: () => `Press ${K('use')} to throw the main power`,
    use: () => sendEvent(['power']),
  });
}

function buildPowerFixtures() {
  const add1 = (x, z, h, len, alongX) => {
    const y = h > 5 ? 5.2 : h - 0.12;
    const g = new THREE.Group();
    g.position.set(x, y, z);
    if (!alongX) {
      g.rotation.y = Math.PI / 2;
    }
    scene.add(g);
    const housing = new THREE.Mesh(new THREE.BoxGeometry(len, 0.06, 0.22), MAT.metal);
    g.add(housing);
    const mat = new THREE.MeshBasicMaterial({
      color: 2763822,
    });
    [-0.05, 0.05].forEach((o) => {
      const tube = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, len - 0.1, 8), mat);
      tube.rotation.z = Math.PI / 2;
      tube.position.set(0, -0.05, o);
      g.add(tube);
    });
    const glow = new THREE.Sprite(
      new THREE.SpriteMaterial({
        map: TX.glow,
        color: 14674175,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        transparent: true,
        opacity: 0,
      }),
    );
    glow.scale.set(len * 1.3, 0.8, 1);
    glow.position.y = -0.08;
    g.add(glow);
    if (h > 5) {
      const ch = new THREE.Mesh(new THREE.BoxGeometry(0.01, h - y, 0.01), MAT.dark);
      ch.position.set(-len / 3, (h - y) / 2, 0);
      g.add(ch);
      const ch2 = ch.clone();
      ch2.position.x = len / 3;
      g.add(ch2);
    }
    WORLD.tubes.push({
      mat: mat,
      glow: glow,
    });
  };
  for (const [x, z] of [
    [-9, -1],
    [-3, -7.5],
    [3, -7.5],
    [9, -1],
    [-3, 3.5],
    [3, 3.5],
  ]) {
    add1(x, z, 6.5, 2.4, true);
  }
  for (const [x, z] of [
    [-20, 10],
    [-10, 10],
    [0, 10],
    [10, 10],
    [18, 16],
    [-14, 16.5],
    [-2, 16.5],
    [8, 21],
    [-20, 21],
  ]) {
    add1(x, z, 6.5, 2.4, true);
  }
  for (const [x, z] of [
    [-22, -8],
    [-16, -8],
    [-22, 4],
    [-16, 4],
  ]) {
    add1(x, z, 4.2, 1.8, false);
  }
  add1(19.5, -8, 3.4, 1.8, true);
  add1(14.5, -2.5, 3.4, 1.8, true);
  add1(19.5, 1.5, 3.4, 1.8, true);
  for (const [x, y, z, d] of [
    [-5, 5, -2, 22],
    [6, 5, -2, 22],
    [-14, 5, 14, 24],
    [6, 5, 14, 24],
    [-19, 3.6, -2, 14],
  ]) {
    const L = new THREE.PointLight(15133951, 0, d, 1.6);
    L.position.set(x, y, z);
    scene.add(L);
    WORLD.powerLights.push({
      L: L,
      base: 1.15,
      target: 0,
    });
  }
}

function buildPress(x, z, face) {
  const grp = new THREE.Group();
  grp.position.set(x, 0, z);
  grp.rotation.y = Math.atan2(face[0], face[1]);
  scene.add(grp);
  const steel = std({
      color: 3949640,
      map: TX.metal,
      roughness: 0.45,
      metalness: 0.7,
    }),
    red = std({
      color: 9051156,
      roughness: 0.4,
      metalness: 0.4,
    });
  const B = (w, h, d, m, px, py, pz) => {
    const me = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
    me.position.set(px, py, pz);
    me.castShadow = true;
    me.receiveShadow = true;
    grp.add(me);
    return me;
  };
  B(1.6, 0.9, 1, steel, 0, 0.45, 0);
  B(1.4, 0.06, 0.8, MAT.steel, 0, 0.93, 0.05);
  [-0.62, 0.62].forEach((sx) => B(0.16, 2.4, 0.2, red, sx, 1.6, -0.25));
  B(1.6, 0.3, 0.5, red, 0, 2.85, -0.15);
  const cylM = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 0.6, 18), MAT.chrome);
  cylM.position.set(0, 2.45, -0.1);
  grp.add(cylM);
  const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.6, 12), MAT.chrome);
  rod.position.set(0, 2, -0.1);
  grp.add(rod);
  const platen = new THREE.Group();
  platen.position.set(0, 1.62, -0.1);
  grp.add(platen);
  const pm = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.14, 0.6), steel);
  pm.castShadow = true;
  platen.add(pm);
  const rod2 = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.5, 12), MAT.chrome);
  rod2.position.y = 0.3;
  platen.add(rod2);
  [-0.35, 0.35].forEach((gx) => {
    const ga = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.04, 18), MAT.gBrass);
    ga.rotation.x = Math.PI / 2;
    ga.position.set(gx, 2.85, 0.12);
    grp.add(ga);
    const face2 = new THREE.Mesh(
      new THREE.CircleGeometry(0.075, 18),
      new THREE.MeshBasicMaterial({
        color: 15260864,
      }),
    );
    face2.position.set(gx, 2.85, 0.145);
    grp.add(face2);
    const nd = new THREE.Mesh(new THREE.BoxGeometry(0.005, 0.06, 0.003), MAT.dark);
    nd.position.set(gx, 2.86, 0.148);
    nd.rotation.z = rand(-1, 1);
    grp.add(nd);
  });
  const sign = textCanvas(512, 128, (g, w, h) => {
    g.fillStyle = '#1a1614';
    g.fillRect(0, 0, w, h);
    g.strokeStyle = '#c9b12a';
    g.lineWidth = 6;
    g.strokeRect(8, 8, w - 16, h - 16);
    g.fillStyle = '#e8dcc4';
    g.font = '46px Oswald, Impact, sans-serif';
    g.textAlign = 'center';
    g.fillText('HARLAN HEAVY OVERHAUL', w / 2, 62);
    g.fillStyle = '#c9b12a';
    g.font = '26px "Special Elite", monospace';
    g.fillText('RATED 40 TONS • KEEP HANDS CLEAR', w / 2, 102);
  });
  const sm = new THREE.Mesh(
    new THREE.PlaneGeometry(1.5, 0.38),
    std({
      map: sign,
      roughness: 0.7,
    }),
  );
  sm.position.set(0, 3.25, 0.1);
  grp.add(sm);
  const lamp = new THREE.Mesh(
    new THREE.SphereGeometry(0.06, 10, 8),
    new THREE.MeshBasicMaterial({
      color: 3349012,
    }),
  );
  lamp.position.set(0.6, 0.75, 0.51);
  grp.add(lamp);
  const beacon = new THREE.Group();
  beacon.position.set(0, 3.1, -0.15);
  grp.add(beacon);
  const bm = new THREE.Mesh(
    new THREE.CylinderGeometry(0.08, 0.1, 0.14, 12),
    new THREE.MeshBasicMaterial({
      color: 16738848,
      transparent: true,
      opacity: 0.8,
    }),
  );
  beacon.add(bm);
  const bl = glowSprite(16738848, 0.7, 0.7, false);
  bl.position.x = 0.1;
  beacon.add(bl);
  const hw = Math.abs(face[0]) > 0 ? 0.55 : 0.85,
    hd = Math.abs(face[0]) > 0 ? 0.85 : 0.55;
  addCol(x - hw, x + hw, z - hd, z + hd, 'press');
  addSolid(x - hw, 0, z - hd, x + hw, 3, z + hd, 'metal');
  WORLD.press = {
    grp: grp,
    platen: platen,
    platenY: 1.62,
    lamp: lamp,
    beacon: beacon,
    x: x,
    z: z,
    disp: null,
  };
  WORLD.inter.push({
    kind: 'press',
    x: x + face[0] * 1.2,
    z: z + face[1] * 1.2,
    r: 1.9,
    enabled: () => PRESS.state === 'idle' || PRESS.state === 'ready',
    label: () => pressLabel(),
    use: () => pressUse(),
  });
}

function buildCandy(x, z, face) {
  const grp = new THREE.Group();
  grp.position.set(x, 0, z);
  grp.rotation.y = Math.atan2(face[0], face[1]);
  scene.add(grp);
  const red = std({
    color: 10492440,
    roughness: 0.35,
    metalness: 0.5,
  });
  const base = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.26, 0.9, 18), red);
  base.position.y = 0.45;
  grp.add(base);
  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.18, 0.22, 18), red);
  body.position.y = 1;
  grp.add(body);
  const globe = new THREE.Group();
  globe.position.y = 1.32;
  grp.add(globe);
  globe.add(
    new THREE.Mesh(
      new THREE.SphereGeometry(0.22, 20, 16),
      new THREE.MeshStandardMaterial({
        color: 13625070,
        roughness: 0.05,
        metalness: 0.1,
        transparent: true,
        opacity: 0.28,
      }),
    ),
  );
  const cols = [12591146, 15257664, 2787898, 15239712, 6961824, 15790320];
  for (let i = 0; i < 40; i++) {
    const b = new THREE.Mesh(
      new THREE.SphereGeometry(0.028, 8, 6),
      std({
        color: pick(cols),
        roughness: 0.3,
      }),
    );
    const a = rand(0, TAU),
      r = rand(0, 0.17),
      yy = rand(-0.18, 0.02);
    b.position.set(Math.cos(a) * r, yy, Math.sin(a) * r);
    globe.add(b);
  }
  const lid = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.12, 0.07, 16), red);
  lid.position.y = 1.56;
  grp.add(lid);
  const crank = new THREE.Group();
  crank.position.set(0, 1, 0.17);
  grp.add(crank);
  const ch = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.025, 0.02), MAT.chrome);
  crank.add(ch);
  const kn = new THREE.Mesh(new THREE.SphereGeometry(0.02, 8, 6), MAT.chrome);
  kn.position.x = 0.07;
  crank.add(kn);
  const chute = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.06, 0.08), MAT.chrome);
  chute.position.set(0, 0.88, 0.16);
  grp.add(chute);
  const tag = textCanvas(256, 64, (g, w, h) => {
    g.fillStyle = '#e8dcc4';
    g.fillRect(0, 0, w, h);
    g.fillStyle = '#a01a18';
    g.font = '34px Yellowtail, cursive';
    g.textAlign = 'center';
    g.fillText('Penny Candy', w / 2, 44);
  });
  const tm = new THREE.Mesh(
    new THREE.PlaneGeometry(0.3, 0.075),
    std({
      map: tag,
    }),
  );
  tm.position.set(0, 0.7, 0.205);
  grp.add(tm);
  addCol(x - 0.28, x + 0.28, z - 0.28, z + 0.28, 'candy');
  WORLD.candy = {
    grp: grp,
    globe: globe,
    crank: crank,
    x: x,
    z: z,
    spin: 0,
  };
  WORLD.inter.push({
    kind: 'candy',
    x: x + face[0] * 0.9,
    z: z + face[1] * 0.9,
    r: 1.6,
    enabled: () => G.diff === 'easy' && !G.candyBusy,
    label: () => candyLabel(),
    use: () => candyUse(),
  });
}

function buildExterior(b) {
  const g = new THREE.BoxGeometry(240, 0.2, 240);
  g.translate(0, -0.1, 6);
  worldUV(g, 8);
  addStatic(g, MAT.asphalt, false);
  const R = mulberry(42);
  const bldgs = [
    [-50, -30, 18, 14, 10],
    [-10, -38, 26, 12, 12],
    [30, -34, 20, 14, 9],
    [52, 6, 12, 30, 11],
    [44, 42, 26, 14, 10],
    [-4, 50, 30, 12, 13],
    [-52, 40, 14, 22, 9],
    [-58, 6, 12, 20, 12],
  ];
  bldgs.forEach(([x, z, w, d, h]) => {
    sbox(x, h / 2, z, w, h, d, MAT.brick, {
      col: false,
      solid: false,
      cast: false,
    });
    for (let i = 0; i < 5; i++) {
      if (R() < 0.45) {
        continue;
      }
      const wx = x + (R() - 0.5) * (w - 2),
        wy = 2 + R() * (h - 4);
      const wg = new THREE.PlaneGeometry(1, 1.3);
      const faceZ = z + (z < 6 ? d / 2 + 0.01 : -d / 2 - 0.01);
      wg.rotateY(z < 6 ? 0 : Math.PI);
      wg.translate(wx, wy, faceZ);
      addStatic(wg, MAT.window, false);
    }
  });
  [
    [-34, -18],
    [30, -16],
    [30, 30],
    [-34, 30],
  ].forEach(([x, z]) => {
    const p = new THREE.CylinderGeometry(0.08, 0.12, 7, 8);
    p.translate(x, 3.5, z);
    addStatic(p, MAT.steel, false);
    const hd = new THREE.BoxGeometry(0.9, 0.15, 0.35);
    hd.translate(x + (x < 0 ? 0.45 : -0.45), 7, z);
    addStatic(hd, MAT.steel, false);
    const gl = glowSprite(16752704, 5, 0.6, true);
    gl.position.set(x + (x < 0 ? 0.7 : -0.7), 6.8, z);
    scene.add(gl);
  });
  for (let a = 0; a < TAU; a += 0.09) {
    const x = -2 + Math.cos(a) * 44,
      z = 6 + Math.sin(a) * 34;
    const p = new THREE.BoxGeometry(0.08, 2.4, 0.08);
    p.translate(x, 1.2, z);
    addStatic(p, MAT.steel, false);
  }
  sbox(
    40,
    2.3,
    18,
    3,
    3.4,
    14,
    std({
      color: 4858904,
      roughness: 0.8,
      map: TX.corr,
    }),
    {
      col: false,
      solid: false,
      cast: false,
    },
  );
  const N = 2600,
    pos = new Float32Array(N * 6);
  const rain = {
    N: N,
    pos: pos,
  };
  for (let i = 0; i < N; i++) {
    let x, z;
    do {
      x = rand(-60, 56);
      z = rand(-45, 58);
    } while (x > b.x0 - 0.6 && x < b.x1 + 0.6 && z > b.z0 - 0.6 && z < b.z1 + 0.6);
    const y = rand(0, 22);
    pos.set([x, y, z, x + 0.02, y + 0.55, z], i * 6);
  }
  const rg = new THREE.BufferGeometry();
  rg.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  rain.mesh = new THREE.LineSegments(
    rg,
    new THREE.LineBasicMaterial({
      color: 9083048,
      transparent: true,
      opacity: 0.3,
    }),
  );
  rain.mesh.frustumCulled = false;
  scene.add(rain.mesh);
  WORLD.rain = rain;
}

function updateRain(dt) {
  const r = WORLD.rain;
  if (!r) {
    return;
  }
  const p = r.pos;
  for (let i = 0; i < r.N; i++) {
    const o = i * 6;
    let y = p[o + 1] - dt * 16;
    if (y < 0) {
      y += 22;
    }
    p[o + 1] = y;
    p[o + 4] = y + 0.55;
  }
  r.mesh.geometry.attributes.position.needsUpdate = true;
}

let hemi, ambient;

function buildMap(id) {
  const M = MAPS[id];
  WORLD.map = M;
  WORLD.rooms = JSON.parse(JSON.stringify(M.rooms));
  WORLD.spawns = M.spawns;
  ambient = new THREE.AmbientLight(4870752, 0.4);
  scene.add(ambient);
  hemi = new THREE.HemisphereLight(5925765, 1708556, 0.3);
  scene.add(hemi);
  const floorMat = {
    concrete: MAT.concrete,
    checker: MAT.checker,
    cold: MAT.cold,
  };
  for (const k in WORLD.rooms) {
    const r = WORLD.rooms[k],
      w = r.x1 - r.x0,
      d = r.z1 - r.z0,
      cx = (r.x0 + r.x1) / 2,
      cz = (r.z0 + r.z1) / 2;
    sbox(cx, -0.05, cz, w, 0.1, d, floorMat[r.floor], {
      col: false,
      solid: false,
      cast: false,
      uv: 4,
    });
    if (r.ceil === 'roof') {
      sbox(cx, r.h + 0.05, cz, w, 0.1, d, MAT.corr, {
        col: false,
        solid: false,
        cast: false,
        uv: 2,
      });
      for (let x = r.x0 + 3; x < r.x1 - 1; x += 4) {
        sbox(x, r.h - 0.9, cz, 0.14, 0.14, d, MAT.steel, {
          col: false,
          solid: false,
          cast: false,
        });
        sbox(x, r.h - 0.08, cz, 0.14, 0.14, d, MAT.steel, {
          col: false,
          solid: false,
          cast: false,
        });
        for (let z = r.z0 + 1; z < r.z1; z += 2) {
          const g = new THREE.BoxGeometry(0.06, 1.1, 0.06);
          g.rotateX(z % 4 < 2 ? 0.6 : -0.6);
          g.translate(x, r.h - 0.5, z);
          addStatic(g, MAT.steel, false);
        }
      }
    } else {
      sbox(cx, r.h + 0.05, cz, w, 0.1, d, r.ceil === 'coldc' ? MAT.cold : MAT.ceilTile, {
        col: false,
        solid: false,
        cast: false,
        uv: r.ceil === 'tiles' ? 1.2 : 4,
      });
    }
    r.lamps.forEach(([x, z, sh]) => lampAt(x, z, r.h, r.cold, sh));
  }
  M.walls.forEach(buildWall);
  const R = mulberry(1953);
  rack(-10, -4.5, -5.2, -4.2, R);
  rack(4.5, 10, -5.2, -4.2, R);
  buildForklift(8, 2.2, 0.7);
  crateBox(-8.5, 0.45, 2.5, 1.2, 0.9, 1.2, 0.1);
  crateBox(-8.4, 1.3, 2.4, 0.9, 0.8, 0.9, -0.2);
  crateBox(-4.2, 0.4, 4.6, 1, 0.8, 1, 0.3);
  barrel(10.8, 4.6, MAT.redPaint);
  barrel(10.1, 5.1, MAT.metal);
  barrel(10.9, 3.9, MAT.yellowPaint);
  for (let i = 0; i < 3; i++) {
    sbox(-1.5 + i * 0.02, 0.08 + i * 0.15, -6.8, 1.2, 0.14, 1, MAT.pineDark, {
      col: i === 2,
      solid: true,
      uv: 1,
      surf: 'wood',
    });
  }
  sbox(17, 0.76, -4.8, 1.8, 0.06, 0.85, MAT.pineDark, {
    uv: 1,
    surf: 'wood',
  });
  sbox(16.2, 0.38, -4.8, 0.06, 0.72, 0.8, MAT.pineDark, {
    col: false,
    uv: 1,
  });
  sbox(17.8, 0.38, -4.8, 0.06, 0.72, 0.8, MAT.pineDark, {
    col: false,
    uv: 1,
  });
  sbox(17, 0.45, -3.9, 0.5, 0.06, 0.5, MAT.rubber, {
    col: false,
    uv: 1,
  });
  sbox(17, 0.72, -3.65, 0.5, 0.5, 0.06, MAT.rubber, {
    col: false,
    uv: 1,
  });
  sbox(21.55, 0.7, -2.6, 0.55, 1.4, 0.6, MAT.metal, {
    uv: 1,
    surf: 'metal',
  });
  sbox(21.55, 0.7, -1.9, 0.55, 1.4, 0.6, MAT.metal, {
    uv: 1,
    surf: 'metal',
  });
  const lampShade = new THREE.Mesh(
    new THREE.CylinderGeometry(0.06, 0.12, 0.1, 12, 1, true),
    std({
      color: 2054698,
      roughness: 0.3,
      side: THREE.DoubleSide,
    }),
  );
  lampShade.position.set(17.6, 1.2, -5);
  scene.add(lampShade);
  const dl = glowSprite(16767136, 0.6, 0.8, false);
  dl.position.set(17.6, 1.1, -5);
  scene.add(dl);
  const cal = new THREE.Mesh(
    new THREE.PlaneGeometry(0.5, 0.7),
    std({
      map: textCanvas(200, 280, (g, w, h) => {
        g.fillStyle = '#e4d8b8';
        g.fillRect(0, 0, w, h);
        g.fillStyle = '#7a1a12';
        g.fillRect(0, 0, w, 50);
        g.fillStyle = '#f0e6cc';
        g.font = '22px Oswald';
        g.textAlign = 'center';
        g.fillText('HARLAN FREIGHT CO.', w / 2, 33);
        g.fillStyle = '#2a1e14';
        g.font = '30px Oswald';
        g.fillText('OCTOBER 1953', w / 2, 90);
        g.font = '14px "Special Elite"';
        for (let i = 0; i < 31; i++) {
          const x = 20 + (i % 7) * 26,
            y = 125 + Math.floor(i / 7) * 30;
          g.fillText(String(i + 1), x + 6, y);
          if (i + 1 === 30) {
            g.strokeStyle = '#8a1510';
            g.lineWidth = 2;
            g.beginPath();
            g.arc(x + 6, y - 5, 12, 0, TAU);
            g.stroke();
          }
        }
      }),
    }),
  );
  cal.position.set(14.5, 1.8, -10 + T / 2 + 0.01);
  scene.add(cal);
  sbox(19.7, 0.74, 5, 1.2, 0.05, 0.75, MAT.pine, {
    uv: 1,
    surf: 'wood',
  });
  [
    [19.2, 4.7],
    [20.2, 4.7],
    [19.2, 5.3],
    [20.2, 5.3],
  ].forEach(([x, z]) =>
    sbox(x, 0.36, z, 0.05, 0.72, 0.05, MAT.steel, {
      col: false,
      solid: false,
      uv: 1,
    }),
  );
  {
    const rg = new THREE.Group();
    rg.position.set(19.5, 0.77, 5.1);
    rg.rotation.y = Math.PI;
    scene.add(rg);
    add(rg, rbox(0.42, 0.26, 0.2, 0.03), MAT.gWood, 0, 0.13, 0);
    const dial = add(
      rg,
      new THREE.CircleGeometry(0.06, 16),
      new THREE.MeshBasicMaterial({
        color: 15249504,
      }),
      0.1,
      0.14,
      0.101,
    );
    add(
      rg,
      new THREE.PlaneGeometry(0.18, 0.16),
      std({
        color: 3811864,
        roughness: 1,
      }),
      -0.08,
      0.13,
      0.101,
    );
    WORLD.radio = {
      x: 19.5,
      y: 0.9,
      z: 5.1,
      dial: dial,
    };
  }
  const board = new THREE.Mesh(
    new THREE.PlaneGeometry(1.2, 0.8),
    std({
      map: textCanvas(300, 200, (g, w, h) => {
        g.fillStyle = '#6a4a2c';
        g.fillRect(0, 0, w, h);
        ['#e8dcc4', '#d8c89c', '#c8d8c0'].forEach((c, i) => {
          g.fillStyle = c;
          g.save();
          g.translate(40 + i * 85, 50 + (i % 2) * 30);
          g.rotate((i - 1) * 0.08);
          g.fillRect(0, 0, 70, 90);
          g.fillStyle = '#333';
          g.font = '9px "Special Elite"';
          ['NOTICE', 'Night shift', 'report all', 'sick workers', 'to foreman'].forEach((l, j) =>
            g.fillText(l, 6, 16 + j * 13),
          );
          g.restore();
        });
      }),
    }),
  );
  board.position.set(16.5, 1.7, 6 - T / 2 - 0.01);
  board.rotation.y = Math.PI;
  scene.add(board);
  for (const zr of [-6.2, -0.5]) {
    sbox(-18.5, 3.5, zr, 10, 0.08, 0.08, MAT.steel, {
      col: false,
      solid: false,
    });
    for (let x = -23; x <= -14; x += 2.2) {
      buildCarcass(x + (R() - 0.5) * 0.4, zr, R);
    }
  }
  sbox(-15.2, 0.45, 2.6, 2, 0.06, 0.9, MAT.steel, {
    uv: 1,
    surf: 'metal',
  });
  sbox(-15.2, 0.22, 2.6, 1.8, 0.44, 0.8, MAT.steel, {
    col: false,
    solid: false,
    uv: 1,
  });
  rack(-22, -10.5, 13.5, 14.5, R);
  rack(-4, 6, 13.5, 14.5, R);
  rack(-20, -6, 18, 19, R);
  rack(2, 14, 18, 19, R);
  buildTruck(-17.5, -11, 8.2, 10.5);
  crateBox(16, 0.45, 12, 1.1, 0.9, 1.1, 0.2);
  crateBox(17.2, 0.45, 12.3, 1.1, 0.9, 1.1, -0.1);
  crateBox(16.5, 1.3, 12.1, 0.9, 0.8, 0.9, 0.5);
  barrel(-24.5, 8, MAT.metal);
  barrel(-23.9, 7.5, MAT.redPaint);
  M.wallbuys.forEach((a) => buildWallBuy(...a));
  M.sodas.forEach((a) => buildSoda(...a));
  buildCrate(M.crates);
  buildPower(...M.power);
  buildPowerFixtures();
  buildPress(...M.press);
  buildCandy(...M.candy);
  buildExterior(M.bounds);
  finalizeStatic();
  applyShadowSetting();
  gridBuild();
}

let lightningT = 15;

function updateLights(dt, t) {
  const P = WORLD.power;
  if (P && P.anim) {
    P.anim += dt;
    const k = Math.min(1, P.anim / 0.75);
    const e = k < 1 ? 1 - Math.pow(1 - k, 3) * Math.cos(k * 7) : 1;
    P.lever.rotation.x = lerp(0.9, -1.1, e);
    if (k > 0.9 && !P.sparked) {
      P.sparked = true;
      spawnFX(P.x + 0.1, 1.9, P.z, 16, 'spark');
      spawnFX(P.x + 0.1, 1.9, P.z, 4, 'smoke');
    }
    if (k >= 1) {
      P.anim = 0;
      P.sparked = false;
    }
  }
  WORLD.powerLights.forEach((l, i) => {
    const flick = G.power && l.L.intensity < l.target * 0.95 ? (Math.random() < 0.3 ? 0 : 1) : 1;
    l.L.intensity = damp(l.L.intensity, l.target * flick, 3 + i, dt);
  });
  for (const l of WORLD.lamps) {
    const base = G.power ? (l.cold ? 2.1 : 2.6) : 0.45;
    let f = 1;
    if (!G.power) {
      const n = Math.sin(t * 13 + l.seed) * Math.sin(t * 3.1 + l.seed * 2);
      f = n > 0.82 ? 0.1 : 0.75 + Math.sin(t * 40 + l.seed) * 0.08;
      if (Math.sin(t * 0.7 + l.seed) > 0.97) {
        f = 0;
      }
    } else if (Math.random() < 0.002) {
      f = 0.3;
    }
    l.cur = damp(l.cur, base * f, 25, dt);
    l.L.intensity = l.cur;
    const k = l.cur / 2.6;
    l.bulbM.color.setRGB(0.2 + k * 0.8, 0.18 + k * 0.76, 0.12 + k * 0.66);
    l.cone.material.opacity = 0.012 + k * 0.045;
    l.glow.material.opacity = 0.15 + k * 0.6;
  }
  lightningT -= dt;
  if (lightningT <= 0) {
    lightningT = rand(18, 45);
    G.flashL = 1;
    setTimeout(
      () =>
        AU.play('thunder', {
          g: 0.9,
          bus: 'amb',
        }),
      rand(400, 1800),
    );
  }
  G.flashL = Math.max(0, (G.flashL || 0) - dt * 3);
  const fl = G.flashL > 0 ? (Math.sin(G.flashL * 30) > 0 ? G.flashL : G.flashL * 0.3) : 0;
  hemi.intensity = (hemi.userData.base || 0.3) + fl * 1.6;
  scene.fog.color.setRGB(0.031 + fl * 0.06, 0.035 + fl * 0.07, 0.043 + fl * 0.09);
  updateRain(dt);
}

const GR = {
  x0: -26,
  z0: -10,
  cs: 0.5,
  nx: 96,
  nz: 64,
};

let blocked,
  dist,
  queue,
  gridReady = false;

function cellOf(x, z) {
  const i = Math.floor((x - GR.x0) / GR.cs),
    j = Math.floor((z - GR.z0) / GR.cs);
  if (i < 0 || j < 0 || i >= GR.nx || j >= GR.nz) {
    return -1;
  }
  return j * GR.nx + i;
}

function gridBuild() {
  if (!blocked) {
    blocked = new Uint8Array(GR.nx * GR.nz);
    dist = new Uint16Array(GR.nx * GR.nz);
    queue = new Int32Array(GR.nx * GR.nz);
  }
  const m = 0.32;
  for (let j = 0; j < GR.nz; j++) {
    for (let i = 0; i < GR.nx; i++) {
      const x = GR.x0 + (i + 0.5) * GR.cs,
        z = GR.z0 + (j + 0.5) * GR.cs;
      let b = !roomAt(x, z);
      if (!b) {
        for (const c of WORLD.colliders) {
          if (!c.on) {
            continue;
          }
          if (x > c.minX - m && x < c.maxX + m && z > c.minZ - m && z < c.maxZ + m) {
            b = true;
            break;
          }
        }
      }
      blocked[j * GR.nx + i] = b ? 1 : 0;
    }
  }
  gridReady = true;
}

const N8 = [
  [1, 0],
  [-1, 0],
  [0, 1],
  [0, -1],
  [1, 1],
  [1, -1],
  [-1, 1],
  [-1, -1],
];

function flowField(sources) {
  dist.fill(65535);
  let h = 0,
    t = 0;
  for (const [sx, sz] of sources) {
    let s = cellOf(sx, sz);
    if (s < 0) {
      continue;
    }
    if (blocked[s]) {
      const si = s % GR.nx,
        sj = (s / GR.nx) | 0;
      for (const [a, b] of N8) {
        const k = (sj + b) * GR.nx + si + a;
        if (k >= 0 && k < blocked.length && !blocked[k]) {
          s = k;
          break;
        }
      }
    }
    if (dist[s] !== 0) {
      dist[s] = 0;
      queue[t++] = s;
    }
  }
  while (h < t) {
    const c = queue[h++],
      ci = c % GR.nx,
      cj = (c / GR.nx) | 0,
      d = dist[c] + 1;
    for (let n = 0; n < 8; n++) {
      const ni = ci + N8[n][0],
        nj = cj + N8[n][1];
      if (ni < 0 || nj < 0 || ni >= GR.nx || nj >= GR.nz) {
        continue;
      }
      const k = nj * GR.nx + ni;
      if (blocked[k] || dist[k] <= d) {
        continue;
      }
      if (n >= 4 && (blocked[cj * GR.nx + ni] || blocked[nj * GR.nx + ci])) {
        continue;
      }
      dist[k] = d;
      queue[t++] = k;
    }
  }
}

function losGrid(x0, z0, x1, z1) {
  const dx = x1 - x0,
    dz = z1 - z0,
    L = Math.hypot(dx, dz),
    n = Math.ceil(L / 0.25);
  for (let i = 1; i < n; i++) {
    const c = cellOf(x0 + (dx * i) / n, z0 + (dz * i) / n);
    if (c < 0 || blocked[c]) {
      return false;
    }
  }
  return true;
}

function freeAt(x, z) {
  const c = cellOf(x, z);
  return c >= 0 && !blocked[c];
}

function rayWorld(o, d, maxT) {
  let best = maxT,
    hit = null,
    nrm = [0, 0, 0];
  for (const s of WORLD.solids) {
    if (!s.on) {
      continue;
    }
    let t0 = 0,
      t1 = best,
      ax = -1,
      sg = 0;
    let ok = true;
    for (let a = 0; a < 3; a++) {
      const inv = 1 / (d[a] || 1e-9);
      let ta = (s.min[a] - o[a]) * inv,
        tb = (s.max[a] - o[a]) * inv;
      let sgn = -1;
      if (ta > tb) {
        const q = ta;
        ta = tb;
        tb = q;
        sgn = 1;
      }
      if (ta > t0) {
        t0 = ta;
        ax = a;
        sg = sgn;
      }
      if (tb < t1) {
        t1 = tb;
      }
      if (t0 > t1) {
        ok = false;
        break;
      }
    }
    if (ok && t0 < best && t0 > 0) {
      best = t0;
      hit = s;
      nrm = [0, 0, 0];
      if (ax >= 0) {
        nrm[ax] = sg * (d[ax] > 0 ? 1 : 1);
      }
      if (ax >= 0) {
        nrm[ax] = d[ax] > 0 ? -1 : 1;
      }
    }
  }
  return hit
    ? {
        t: best,
        s: hit,
        n: nrm,
      }
    : null;
}

(() => {
  const C = THREE.Color.prototype;
  const sh = C.setHex,
    shsl = C.setHSL;
  C.setHex = function (h) {
    sh.call(this, h);
    return this.convertSRGBToLinear();
  };
  C.setHSL = function (h, s, l) {
    shsl.call(this, h, s, l);
    return this.convertSRGBToLinear();
  };
})();

const canvas = $('#c');

const renderer = new THREE.WebGLRenderer({
  canvas: canvas,
  antialias: false,
  powerPreference: 'high-performance',
  stencil: false,
});

renderer.autoClear = false;

renderer.shadowMap.enabled = true;

renderer.shadowMap.type = THREE.PCFSoftShadowMap;

const FOGC = 526603;

const scene = new THREE.Scene();

scene.background = new THREE.Color(FOGC);

scene.fog = new THREE.FogExp2(FOGC, 0.03);

const camera = new THREE.PerspectiveCamera(80, 1, 0.05, 260);

camera.rotation.order = 'YXZ';

scene.add(camera);

const vmScene = new THREE.Scene();

const vmCam = new THREE.PerspectiveCamera(54, 1, 0.01, 10);

const vmAmb = new THREE.HemisphereLight(10133674, 3812900, 0.95);

vmScene.add(vmAmb);

const vmKey = new THREE.DirectionalLight(16770756, 1.05);

vmKey.position.set(0.4, 1, 0.5);

vmScene.add(vmKey);

const vmRim = new THREE.DirectionalLight(10466512, 0.25);

vmRim.position.set(-1, 0.2, -1);

vmScene.add(vmRim);

const vmFlash = new THREE.PointLight(16756832, 0, 2.5, 2);

vmFlash.position.set(0, 0, -0.7);

vmScene.add(vmFlash);

const POST = {
  scene: new THREE.Scene(),
  cam: new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1),
  mat: new THREE.ShaderMaterial({
    uniforms: {
      tDiffuse: {
        value: null,
      },
      time: {
        value: 0,
      },
      grain: {
        value: 0.05,
      },
      chroma: {
        value: 1,
      },
      hurt: {
        value: 0,
      },
      bright: {
        value: 1,
      },
      flash: {
        value: 0,
      },
      res: {
        value: new THREE.Vector2(1, 1),
      },
      desat: {
        value: 0,
      },
      blur: {
        value: 0,
      },
      tBloom: {
        value: null,
      },
      bloom: {
        value: 0,
      },
      exposure: {
        value: 1,
      },
    },
    vertexShader: 'varying vec2 vUv; void main(){ vUv=uv; gl_Position=vec4(position.xy,0.,1.); }',
    fragmentShader: `\n      uniform sampler2D tDiffuse, tBloom; uniform float time, grain, chroma, hurt, bright, flash, desat, blur, bloom, exposure; uniform vec2 res; varying vec2 vUv;\n      vec3 aces(vec3 x){ return clamp((x*(2.51*x+.03))/(x*(2.43*x+.59)+.14),0.,1.); }\n      float rnd(vec2 p){ return fract(sin(dot(p, vec2(12.9898,78.233)) + time*37.1) * 43758.5453); }\n      void main(){\n        vec2 uv=vUv; vec2 c=uv-.5; float d=length(c*vec2(res.x/res.y,1.)); float dd=length(c);\n        float ca=chroma*(.0012+hurt*.007)*dd;\n        vec3 col=vec3(texture2D(tDiffuse,uv-c*ca).r, texture2D(tDiffuse,uv).g, texture2D(tDiffuse,uv+c*ca).b);\n        if(blur>0.){ vec2 px=blur/res; col=(col*2.+texture2D(tDiffuse,uv+vec2(px.x,0.)).rgb+texture2D(tDiffuse,uv-vec2(px.x,0.)).rgb+texture2D(tDiffuse,uv+vec2(0.,px.y)).rgb+texture2D(tDiffuse,uv-vec2(0.,px.y)).rgb)/6.; }\n        if(bloom>0.) col+=texture2D(tBloom,uv).rgb*bloom;\n        col=aces(col*exposure*bright*1.6);\n        col=pow(col,vec3(1./2.2));\n        float l=dot(col,vec3(.299,.587,.114));\n        col=mix(col,vec3(l),.22+desat*.7);\n        col*=vec3(1.05,1.0,.9);\n        col=mix(col, col*col*(3.-2.*col), .35);\n        col=mix(col, vec3(l*1.3,l*.12,l*.08), hurt*.45*smoothstep(.15,.75,dd));\n        col*=1.-.72*smoothstep(.32,.95,d);\n        col+=(rnd(uv*res)-.5)*grain;\n        col=mix(col,vec3(1.,.96,.88),flash);\n        gl_FragColor=vec4(max(col,0.),1.);\n      }`,
    depthTest: false,
    depthWrite: false,
  }),
};

POST.quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), POST.mat);

POST.scene.add(POST.quad);

const BLOOM = {
  a: null,
  b: null,
  bright: new THREE.ShaderMaterial({
    uniforms: {
      t: {
        value: null,
      },
      th: {
        value: 0.9,
      },
    },
    vertexShader: 'varying vec2 vUv; void main(){ vUv=uv; gl_Position=vec4(position.xy,0.,1.); }',
    fragmentShader:
      'uniform sampler2D t; uniform float th; varying vec2 vUv; void main(){ vec3 c=texture2D(t,vUv).rgb; float l=max(max(c.r,c.g),c.b); float k=smoothstep(th, th*2.2, l); gl_FragColor=vec4(c*k,1.); }',
    depthTest: false,
    depthWrite: false,
  }),
  blur: new THREE.ShaderMaterial({
    uniforms: {
      t: {
        value: null,
      },
      dir: {
        value: new THREE.Vector2(1, 0),
      },
    },
    vertexShader: 'varying vec2 vUv; void main(){ vUv=uv; gl_Position=vec4(position.xy,0.,1.); }',
    fragmentShader:
      'uniform sampler2D t; uniform vec2 dir; varying vec2 vUv; void main(){ vec3 c=texture2D(t,vUv).rgb*.227; c+=texture2D(t,vUv+dir*1.385).rgb*.316; c+=texture2D(t,vUv-dir*1.385).rgb*.316; c+=texture2D(t,vUv+dir*3.231).rgb*.07; c+=texture2D(t,vUv-dir*3.231).rgb*.07; gl_FragColor=vec4(c,1.); }',
    depthTest: false,
    depthWrite: false,
  }),
};

const QUALITY = {
  low: {
    scale: 0.6,
    shadows: 'off',
    aa: false,
    bloom: false,
    pr: 1,
    shadowRes: 512,
    shadowEvery: 3,
    lampShadows: 0,
  },
  medium: {
    scale: 0.8,
    shadows: 'low',
    aa: true,
    bloom: false,
    pr: 1.25,
    shadowRes: 1024,
    shadowEvery: 2,
    lampShadows: 0,
  },
  high: {
    scale: 1,
    shadows: 'high',
    aa: true,
    bloom: true,
    pr: 1.5,
    shadowRes: 1024,
    shadowEvery: 2,
    lampShadows: 3,
  },
  ultra: {
    scale: 1,
    shadows: 'high',
    aa: true,
    bloom: true,
    pr: 2,
    shadowRes: 2048,
    shadowEvery: 1,
    lampShadows: 6,
  },
};

const qual = () => QUALITY[SET.video.quality] || QUALITY.high;

let RT = null;

function setupRT() {
  const pr = Math.min(window.devicePixelRatio || 1, qual().pr);
  const sc = SET.video.scale * (DYN.k || 1);
  const w = Math.max(320, Math.floor(innerWidth * pr * sc)),
    h = Math.max(200, Math.floor(innerHeight * pr * sc));
  if (RT) {
    RT.dispose();
  }
  const hf = renderer.capabilities.isWebGL2 || renderer.extensions.has('OES_texture_half_float');
  const opts = {
    minFilter: THREE.LinearFilter,
    magFilter: THREE.LinearFilter,
    format: THREE.RGBAFormat,
    depthBuffer: true,
    type: hf ? THREE.HalfFloatType : THREE.UnsignedByteType,
  };
  if (SET.video.aa && renderer.capabilities.isWebGL2 && THREE.WebGLMultisampleRenderTarget) {
    RT = new THREE.WebGLMultisampleRenderTarget(w, h, opts);
    RT.samples = 4;
  } else {
    RT = new THREE.WebGLRenderTarget(w, h, opts);
  }
  POST.mat.uniforms.tDiffuse.value = RT.texture;
  POST.mat.uniforms.res.value.set(w, h);
  if (BLOOM.a) {
    BLOOM.a.dispose();
    BLOOM.b.dispose();
  }
  const bw = Math.max(64, w >> 2),
    bh = Math.max(40, h >> 2),
    bo = {
      minFilter: THREE.LinearFilter,
      magFilter: THREE.LinearFilter,
      format: THREE.RGBAFormat,
      depthBuffer: false,
      type: opts.type,
    };
  BLOOM.a = new THREE.WebGLRenderTarget(bw, bh, bo);
  BLOOM.b = new THREE.WebGLRenderTarget(bw, bh, bo);
  BLOOM.px = [1 / bw, 1 / bh];
  POST.mat.uniforms.tBloom.value = BLOOM.a.texture;
}

const DYN = {
  k: 1,
  acc: 0,
  n: 0,
  cool: 0,
};

function dynRes(dt) {
  if (!SET.video.dynres) {
    if (DYN.k !== 1) {
      DYN.k = 1;
      setupRT();
    }
    return;
  }
  DYN.acc += dt;
  DYN.n++;
  DYN.cool -= dt;
  if (DYN.acc < 1) {
    return;
  }
  const fps = DYN.n / DYN.acc;
  DYN.acc = 0;
  DYN.n = 0;
  if (DYN.cool > 0) {
    return;
  }
  let k = DYN.k;
  if (fps < 48) {
    k = Math.max(0.55, k - 0.08);
  } else if (fps > 58 && k < 1) {
    k = Math.min(1, k + 0.04);
  }
  if (k !== DYN.k) {
    DYN.k = k;
    DYN.cool = 1.5;
    setupRT();
  }
}

function resizeAll() {
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, qual().pr));
  renderer.setSize(innerWidth, innerHeight, false);
  camera.aspect = vmCam.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  vmCam.updateProjectionMatrix();
  setupRT();
}

function applyVideo() {
  const v = SET.video;
  renderer.shadowMap.enabled = v.shadows !== 'off';
  renderer.shadowMap.autoUpdate = false;
  renderer.shadowMap.needsUpdate = true;
  POST.mat.uniforms.bloom.value = v.bloom ? 0.85 : 0;
  const mx = renderer.capabilities.getMaxAnisotropy();
  Object.values(TX).forEach((t) => {
    if (t && t.isTexture) {
      t.anisotropy = Math.min(v.quality === 'ultra' ? 16 : v.quality === 'low' ? 2 : 8, mx);
      t.needsUpdate = true;
    }
  });
  POST.mat.uniforms.grain.value = v.grain ? 0.055 : 0;
  POST.mat.uniforms.chroma.value = v.chroma ? 1 : 0;
  POST.mat.uniforms.bright.value = v.bright;
  POST.mat.uniforms.exposure.value = 1;
  resizeAll();
  if (typeof applyShadowSetting === 'function') {
    applyShadowSetting();
  }
}

let shadowFrame = 0;

function renderFrame(showVM) {
  if (renderer.shadowMap.enabled && ++shadowFrame % qual().shadowEvery === 0) {
    renderer.shadowMap.needsUpdate = true;
  }
  renderer.setRenderTarget(RT);
  renderer.clear();
  renderer.render(scene, camera);
  if (showVM) {
    renderer.clearDepth();
    renderer.render(vmScene, vmCam);
  }
  if (SET.video.bloom) {
    POST.quad.material = BLOOM.bright;
    BLOOM.bright.uniforms.t.value = RT.texture;
    renderer.setRenderTarget(BLOOM.a);
    renderer.render(POST.scene, POST.cam);
    POST.quad.material = BLOOM.blur;
    for (let i = 0; i < 2; i++) {
      BLOOM.blur.uniforms.t.value = BLOOM.a.texture;
      BLOOM.blur.uniforms.dir.value.set(BLOOM.px[0] * (1 + i), 0);
      renderer.setRenderTarget(BLOOM.b);
      renderer.render(POST.scene, POST.cam);
      BLOOM.blur.uniforms.t.value = BLOOM.b.texture;
      BLOOM.blur.uniforms.dir.value.set(0, BLOOM.px[1] * (1 + i));
      renderer.setRenderTarget(BLOOM.a);
      renderer.render(POST.scene, POST.cam);
    }
    POST.quad.material = POST.mat;
  }
  renderer.setRenderTarget(null);
  renderer.clear();
  renderer.render(POST.scene, POST.cam);
}

window.addEventListener('resize', () => resizeAll());

function mkC(w, h) {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  return [c, c.getContext('2d')];
}

function toTex(c, rep = true, clampT = false) {
  const t = new THREE.CanvasTexture(c);
  t.encoding = THREE.sRGBEncoding;
  t.wrapS = rep ? THREE.RepeatWrapping : THREE.ClampToEdgeWrapping;
  t.wrapT = rep && !clampT ? THREE.RepeatWrapping : THREE.ClampToEdgeWrapping;
  t.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
  return t;
}

function blotch(g, w, h, n, col, r0, r1, R = Math.random) {
  for (let i = 0; i < n; i++) {
    const x = R() * w,
      y = R() * h,
      r = r0 + R() * (r1 - r0);
    const gr = g.createRadialGradient(x, y, 0, x, y, r);
    gr.addColorStop(0, col);
    gr.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = gr;
    g.fillRect(x - r, y - r, r * 2, r * 2);
  }
}

function speck(g, w, h, n, cols, sz, a0 = 0.03, a1 = 0.18) {
  for (let i = 0; i < n; i++) {
    g.globalAlpha = rand(a0, a1);
    g.fillStyle = pick(cols);
    g.fillRect(Math.random() * w, Math.random() * h, rand(1, sz), rand(1, sz));
  }
  g.globalAlpha = 1;
}

function crack(gs, x, y, n, len, col, lw = 1) {
  gs.forEach((g) => {
    g.strokeStyle = col;
    g.lineWidth = lw;
  });
  let px = x,
    py = y;
  for (let i = 0; i < n; i++) {
    const nx = px + rand(-len, len),
      ny = py + rand(-len, len);
    gs.forEach((g) => {
      g.beginPath();
      g.moveTo(px, py);
      g.lineTo(nx, ny);
      g.stroke();
    });
    px = nx;
    py = ny;
  }
}

function pair(w, h, bumpBase = '#808080') {
  const [c, g] = mkC(w, h);
  const [cb, gb] = mkC(w, h);
  gb.fillStyle = bumpBase;
  gb.fillRect(0, 0, w, h);
  return {
    c: c,
    g: g,
    cb: cb,
    gb: gb,
  };
}

function grain(g, w, h, lines, dir, col) {
  for (let i = 0; i < lines; i++) {
    g.strokeStyle = col();
    g.lineWidth = rand(0.5, 1.8);
    g.beginPath();
    const o = Math.random() * (dir ? w : h);
    if (dir) {
      g.moveTo(o, 0);
      for (let y = 0; y <= h; y += 12) {
        g.lineTo(o + Math.sin(y * 0.04 + i) * 2, y);
      }
    } else {
      g.moveTo(0, o);
      for (let x = 0; x <= w; x += 12) {
        g.lineTo(x, o + Math.sin(x * 0.04 + i) * 2);
      }
    }
    g.stroke();
  }
}

const TX = {};

function normalFromHeight(src, strength = 2) {
  const w = src.width,
    h = src.height,
    [c, g] = mkC(w, h);
  const d = src.getContext('2d').getImageData(0, 0, w, h).data;
  const out = g.createImageData(w, h);
  const o = out.data;
  const H = (x, y) => d[(((y + h) % h) * w + ((x + w) % w)) * 4] / 255;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const dx = (H(x + 1, y) - H(x - 1, y)) * strength,
        dy = (H(x, y + 1) - H(x, y - 1)) * strength;
      const L = Math.hypot(dx, dy, 1);
      const i = (y * w + x) * 4;
      o[i] = ((-dx / L) * 0.5 + 0.5) * 255;
      o[i + 1] = ((dy / L) * 0.5 + 0.5) * 255;
      o[i + 2] = ((1 / L) * 0.5 + 0.5) * 255;
      o[i + 3] = 255;
    }
  }
  g.putImageData(out, 0, 0);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.anisotropy = 8;
  return t;
}

function buildTextures() {
  {
    const S = 512,
      { c: c, g: g, cb: cb, gb: gb } = pair(S, S);
    g.fillStyle = '#5c5850';
    g.fillRect(0, 0, S, S);
    blotch(g, S, S, 50, 'rgba(30,28,24,.25)', 20, 110);
    blotch(g, S, S, 30, 'rgba(150,145,130,.12)', 20, 90);
    blotch(g, S, S, 7, 'rgba(8,7,6,.55)', 15, 60);
    speck(g, S, S, 7e3, ['#2a2825', '#8a857a', '#403c36'], 3);
    speck(gb, S, S, 5e3, ['#606060', '#a0a0a0'], 3, 0.2, 0.5);
    for (let i = 0; i < 5; i++) {
      crack([g, gb], rand(0, S), rand(0, S), 10, 22, 'rgba(15,14,12,.6)');
    }
    [g, gb].forEach((x) => {
      x.fillStyle = 'rgba(12,11,10,.8)';
      x.fillRect(0, 0, S, 3);
      x.fillRect(0, 0, 3, S);
    });
    TX.concrete = toTex(c);
    TX.concreteB = toTex(cb);
  }
  {
    const S = 512,
      { c: c, g: g, cb: cb, gb: gb } = pair(S, S);
    const wy = S - 154;
    g.fillStyle = '#a0977f';
    g.fillRect(0, 0, S, wy);
    g.fillStyle = '#3c4a3a';
    g.fillRect(0, wy, S, S - wy);
    g.fillStyle = '#1d1a16';
    g.fillRect(0, wy - 5, S, 6);
    blotch(g, S, wy, 35, 'rgba(60,50,35,.22)', 15, 80);
    blotch(g, S, S, 20, 'rgba(20,24,18,.25)', 15, 60);
    gb.fillStyle = '#6a6a6a';
    for (let y = S; y > 8; y -= 25.6) {
      const row = Math.round((S - y) / 25.6);
      g.fillStyle = 'rgba(30,26,20,.35)';
      g.fillRect(0, y - 2, S, 2);
      gb.fillRect(0, y - 2, S, 2);
      for (let x = (row % 2) * 25.6; x < S; x += 51.2) {
        g.fillRect(x, y - 25.6, 2, 25.6);
        gb.fillRect(x, y - 25.6, 2, 25.6);
      }
    }
    for (let i = 0; i < 26; i++) {
      const x = rand(0, S),
        y = rand(0, wy * 0.7),
        h = rand(40, 260);
      const gr = g.createLinearGradient(0, y, 0, y + h);
      gr.addColorStop(0, 'rgba(55,40,20,.3)');
      gr.addColorStop(1, 'rgba(55,40,20,0)');
      g.fillStyle = gr;
      g.fillRect(x, y, rand(2, 8), h);
    }
    for (let i = 0; i < 9; i++) {
      const x = rand(0, S),
        y = rand(20, S - 30),
        w = rand(15, 60),
        h = rand(10, 40);
      g.fillStyle = '#6d6a62';
      g.beginPath();
      g.ellipse(x, y, w / 2, h / 2, rand(0, 3), 0, TAU);
      g.fill();
      gb.strokeStyle = '#b0b0b0';
      gb.lineWidth = 2;
      gb.beginPath();
      gb.ellipse(x, y, w / 2, h / 2, 0, 0, TAU);
      gb.stroke();
    }
    const gr = g.createLinearGradient(0, S - 60, 0, S);
    gr.addColorStop(0, 'rgba(0,0,0,0)');
    gr.addColorStop(1, 'rgba(10,8,6,.6)');
    g.fillStyle = gr;
    g.fillRect(0, S - 60, S, 60);
    speck(g, S, S, 3e3, ['#222', '#999'], 2);
    g.fillStyle = '#a0977f';
    g.fillRect(0, 0, S, 8);
    gb.fillStyle = '#808080';
    gb.fillRect(0, 0, S, 8);
    TX.paint = toTex(c, true, true);
    TX.paintB = toTex(cb, true, true);
  }
  {
    const S = 512,
      { c: c, g: g, cb: cb, gb: gb } = pair(S, S);
    for (let x = 0; x < S; x += 25.6) {
      g.fillStyle = `hsl(${rand(24, 32)},${rand(40, 52)}%,${rand(24, 33)}%)`;
      g.fillRect(x, 0, 25.6, S);
      g.fillStyle = 'rgba(15,8,3,.8)';
      g.fillRect(x, 0, 2, S);
      gb.fillStyle = '#505050';
      gb.fillRect(x, 0, 2, S);
    }
    grain(g, S, S, 120, true, () => `rgba(40,20,5,${rand(0.08, 0.25)})`);
    for (let i = 0; i < 22; i++) {
      const x = rand(0, S),
        y = rand(0, S);
      g.fillStyle = 'rgba(40,20,8,.7)';
      g.beginPath();
      g.ellipse(x, y, rand(3, 6), rand(5, 10), 0, 0, TAU);
      g.fill();
    }
    g.fillStyle = '#231710';
    g.fillRect(0, S - 16, S, 16);
    g.fillStyle = '#231710';
    g.fillRect(0, 0, S, 8);
    blotch(g, S, S, 12, 'rgba(0,0,0,.3)', 20, 80);
    TX.panel = toTex(c, true, true);
    TX.panelB = toTex(cb, true, true);
  }
  {
    const S = 512,
      { c: c, g: g, cb: cb, gb: gb } = pair(S, S);
    g.fillStyle = '#b9bab2';
    g.fillRect(0, 0, S, S);
    const t = 19.2;
    for (let y = 0; y < S; y += t) {
      for (let x = 0; x < S; x += t) {
        g.fillStyle = `rgba(${rand(0, 40)},${rand(0, 40)},${rand(0, 30)},${rand(0, 0.12)})`;
        g.fillRect(x, y, t, t);
      }
    }
    g.fillStyle = '#6b6b63';
    gb.fillStyle = '#505050';
    for (let v = 0; v < S; v += t) {
      g.fillRect(0, v, S, 1.5);
      g.fillRect(v, 0, 1.5, S);
      gb.fillRect(0, v, S, 2);
      gb.fillRect(v, 0, 2, S);
    }
    const gr = g.createLinearGradient(0, S * 0.55, 0, S);
    gr.addColorStop(0, 'rgba(40,35,25,0)');
    gr.addColorStop(1, 'rgba(40,35,25,.6)');
    g.fillStyle = gr;
    g.fillRect(0, S * 0.55, S, S);
    for (let i = 0; i < 7; i++) {
      const x = rand(0, S),
        y = rand(S * 0.3, S * 0.8);
      g.fillStyle = 'rgba(95,8,6,.55)';
      for (let k = 0; k < 10; k++) {
        g.fillRect(x + rand(-12, 12), y + k * rand(3, 8), rand(3, 9), rand(10, 40));
      }
    }
    blotch(g, S, S, 10, 'rgba(90,10,6,.3)', 10, 40);
    for (let i = 0; i < 6; i++) {
      crack([g, gb], rand(0, S), rand(0, S), 5, 10, 'rgba(40,40,35,.7)');
    }
    TX.tile = toTex(c);
    TX.tileB = toTex(cb);
  }
  {
    const S = 512,
      { c: c, g: g, cb: cb, gb: gb } = pair(S, S);
    const t = S / 12;
    for (let y = 0; y < 12; y++) {
      for (let x = 0; x < 12; x++) {
        g.fillStyle = (x + y) % 2 ? '#5a1d1b' : '#c9bea3';
        g.fillRect(x * t, y * t, t, t);
      }
    }
    blotch(g, S, S, 40, 'rgba(20,15,10,.3)', 20, 90);
    speck(g, S, S, 3e3, ['#000', '#fff'], 2);
    for (let i = 0; i < 30; i++) {
      g.strokeStyle = 'rgba(0,0,0,.25)';
      g.lineWidth = rand(1, 3);
      g.beginPath();
      const x = rand(0, S),
        y = rand(0, S);
      g.moveTo(x, y);
      g.lineTo(x + rand(-50, 50), y + rand(-20, 20));
      g.stroke();
    }
    TX.checker = toTex(c);
    TX.checkerB = toTex(cb);
  }
  {
    const S = 512,
      { c: c, g: g, cb: cb, gb: gb } = pair(S, S);
    g.fillStyle = '#4d5559';
    g.fillRect(0, 0, S, S);
    const t = 64;
    g.fillStyle = '#2a3033';
    gb.fillStyle = '#505050';
    for (let v = 0; v < S; v += t) {
      g.fillRect(0, v, S, 2);
      g.fillRect(v, 0, 2, S);
      gb.fillRect(0, v, S, 3);
      gb.fillRect(v, 0, 3, S);
    }
    blotch(g, S, S, 30, 'rgba(15,20,22,.4)', 20, 90);
    blotch(g, S, S, 8, 'rgba(70,6,5,.5)', 15, 50);
    speck(g, S, S, 4e3, ['#222', '#899'], 2);
    TX.cold = toTex(c);
    TX.coldB = toTex(cb);
  }
  {
    const S = 512,
      { c: c, g: g, cb: cb, gb: gb } = pair(S, S, '#707070');
    g.fillStyle = '#3a3230';
    g.fillRect(0, 0, S, S);
    const bw = 25.6,
      bh = 8.53;
    for (let r = 0, y = 0; y < S; r++, y += bh) {
      for (let x = (-(r % 2) * bw) / 2; x < S; x += bw) {
        g.fillStyle = `hsl(${rand(5, 16)},${rand(30, 45)}%,${rand(16, 26)}%)`;
        g.fillRect(x + 1, y + 1, bw - 2, bh - 2);
        gb.fillStyle = '#a0a0a0';
        gb.fillRect(x + 1, y + 1, bw - 2, bh - 2);
      }
    }
    blotch(g, S, S, 25, 'rgba(0,0,0,.35)', 20, 100);
    TX.brick = toTex(c);
    TX.brickB = toTex(cb);
  }
  {
    const S = 512,
      { c: c, g: g, cb: cb, gb: gb } = pair(S, S);
    g.fillStyle = '#1f1f20';
    g.fillRect(0, 0, S, S);
    speck(g, S, S, 9e3, ['#000', '#444', '#2a2a2a'], 2, 0.2, 0.6);
    const [cr, gr] = mkC(S, S);
    gr.fillStyle = '#d0d0d0';
    gr.fillRect(0, 0, S, S);
    blotch(gr, S, S, 18, 'rgba(10,10,10,.9)', 20, 90);
    blotch(g, S, S, 18, 'rgba(0,0,0,.35)', 20, 90);
    for (let i = 0; i < 6; i++) {
      crack([g, gb], rand(0, S), rand(0, S), 8, 20, 'rgba(0,0,0,.7)');
    }
    TX.asphalt = toTex(c);
    TX.asphaltB = toTex(cb);
    TX.asphaltR = toTex(cr);
  }
  {
    const S = 256,
      { c: c, g: g, cb: cb, gb: gb } = pair(S, S);
    for (let y = 0; y < S; y += 42.7) {
      g.fillStyle = `hsl(${rand(28, 34)},${rand(35, 45)}%,${rand(32, 40)}%)`;
      g.fillRect(0, y, S, 42.7);
      g.fillStyle = 'rgba(20,12,5,.8)';
      g.fillRect(0, y, S, 2);
      gb.fillStyle = '#404040';
      gb.fillRect(0, y, S, 3);
    }
    grain(g, S, S, 60, false, () => `rgba(60,35,10,${rand(0.08, 0.22)})`);
    blotch(g, S, S, 10, 'rgba(0,0,0,.25)', 10, 40);
    g.fillStyle = 'rgba(30,30,30,.9)';
    for (let y = 20; y < S; y += 42.7) {
      g.fillRect(10, y, 4, 4);
      g.fillRect(S - 14, y, 4, 4);
    }
    TX.pine = toTex(c);
    TX.pineB = toTex(cb);
  }
  {
    const S = 256,
      { c: c, g: g, cb: cb, gb: gb } = pair(S, S);
    g.fillStyle = '#44524a';
    g.fillRect(0, 0, S, S);
    blotch(g, S, S, 12, 'rgba(0,0,0,.25)', 10, 50);
    for (let i = 0; i < 40; i++) {
      const x = rand(0, S),
        y = rand(0, S),
        r = rand(2, 9);
      g.fillStyle = '#6a6660';
      g.beginPath();
      g.arc(x, y, r, 0, TAU);
      g.fill();
      g.fillStyle = 'rgba(110,50,18,.7)';
      g.beginPath();
      g.arc(x, y, r * 0.6, 0, TAU);
      g.fill();
      gb.fillStyle = '#5a5a5a';
      gb.beginPath();
      gb.arc(x, y, r, 0, TAU);
      gb.fill();
    }
    for (let i = 0; i < 12; i++) {
      const x = rand(0, S);
      const gr = g.createLinearGradient(0, 0, 0, S);
      gr.addColorStop(0, 'rgba(110,50,15,.35)');
      gr.addColorStop(1, 'rgba(110,50,15,0)');
      g.fillStyle = gr;
      g.fillRect(x, rand(0, S / 2), rand(1, 4), rand(30, 150));
    }
    TX.metal = toTex(c);
    TX.metalB = toTex(cb);
  }
  {
    const S = 256,
      { c: c, g: g, cb: cb, gb: gb } = pair(S, S);
    for (let x = 0; x < S; x++) {
      const v = Math.sin((x / S) * TAU * 26);
      const l = 30 + v * 8;
      g.fillStyle = `rgb(${l + 8},${l + 6},${l + 4})`;
      g.fillRect(x, 0, 1, S);
      const b = 128 + v * 90;
      gb.fillStyle = `rgb(${b},${b},${b})`;
      gb.fillRect(x, 0, 1, S);
    }
    blotch(g, S, S, 16, 'rgba(90,40,12,.35)', 10, 50);
    blotch(g, S, S, 10, 'rgba(0,0,0,.4)', 20, 60);
    TX.corr = toTex(c);
    TX.corrB = toTex(cb);
  }
  {
    const [c, g] = mkC(512, 128);
    g.fillStyle = '#4a2a16';
    g.fillRect(0, 0, 512, 128);
    for (let i = 0; i < 10; i++) {
      g.fillStyle = `rgba(${randi(80, 120)},${randi(40, 60)},${randi(15, 30)},.25)`;
      g.fillRect(0, rand(0, 128), 512, rand(4, 14));
    }
    grain(g, 512, 128, 110, false, () => `rgba(${rand(15, 40)},${rand(5, 15)},0,${rand(0.2, 0.55)})`);
    for (let i = 0; i < 40; i++) {
      g.strokeStyle = 'rgba(150,95,45,.18)';
      g.lineWidth = 1;
      g.beginPath();
      const x = rand(0, 512),
        y = rand(0, 128);
      g.moveTo(x, y);
      g.lineTo(x + rand(6, 16), y + rand(-2, 2));
      g.stroke();
    }
    blotch(g, 512, 128, 10, 'rgba(120,70,30,.25)', 10, 40);
    blotch(g, 512, 128, 8, 'rgba(10,5,0,.35)', 8, 30);
    speck(g, 512, 128, 400, ['#000', '#a86'], 2);
    TX.walnut = toTex(c);
  }
  {
    const S = 256,
      [c, g] = mkC(S, S);
    g.fillStyle = '#6a6e72';
    g.fillRect(0, 0, S, S);
    blotch(g, S, S, 30, 'rgba(20,22,26,.35)', 10, 50);
    blotch(g, S, S, 14, 'rgba(200,205,210,.18)', 6, 30);
    for (let i = 0; i < 180; i++) {
      g.strokeStyle = `rgba(${Math.random() < 0.5 ? '230,232,235' : '20,20,22'},${rand(0.05, 0.25)})`;
      g.lineWidth = rand(0.3, 1);
      g.beginPath();
      const x = rand(0, S),
        y = rand(0, S),
        a = rand(-0.3, 0.3);
      g.moveTo(x, y);
      g.lineTo(x + Math.cos(a) * rand(4, 30), y + Math.sin(a) * rand(4, 30));
      g.stroke();
    }
    speck(g, S, S, 1500, ['#222', '#aaa'], 1.5);
    TX.gunmetal = toTex(c);
  }
  {
    const S = 128,
      [c, g] = mkC(S, S);
    g.fillStyle = '#2a170c';
    g.fillRect(0, 0, S, S);
    g.strokeStyle = 'rgba(0,0,0,.7)';
    g.lineWidth = 1.2;
    for (let i = -S; i < S * 2; i += 6) {
      g.beginPath();
      g.moveTo(i, 0);
      g.lineTo(i + S, S);
      g.stroke();
      g.beginPath();
      g.moveTo(i, S);
      g.lineTo(i + S, 0);
      g.stroke();
    }
    g.strokeStyle = 'rgba(160,100,50,.25)';
    for (let i = -S; i < S * 2; i += 6) {
      g.beginPath();
      g.moveTo(i + 2, 0);
      g.lineTo(i + 2 + S, S);
      g.stroke();
    }
    TX.checkerGrip = toTex(c);
  }
  TX.skins = [];
  TX.faces = [];
  for (let v = 0; v < 3; v++) {
    const S = 256,
      [c, g] = mkC(S, S);
    g.fillStyle = '#cfcdc0';
    g.fillRect(0, 0, S, S);
    blotch(g, S, S, 30, 'rgba(70,85,60,.35)', 8, 40);
    blotch(g, S, S, 10, 'rgba(90,40,80,.3)', 8, 30);
    blotch(g, S, S, 10, 'rgba(110,8,6,.6)', 4, 22);
    blotch(g, S, S, 8, 'rgba(30,25,15,.5)', 6, 25);
    for (let i = 0; i < 25; i++) {
      g.strokeStyle = 'rgba(40,60,70,.35)';
      g.lineWidth = 1;
      g.beginPath();
      let x = rand(0, S),
        y = rand(0, S);
      g.moveTo(x, y);
      for (let k = 0; k < 5; k++) {
        x += rand(-12, 12);
        y += rand(-12, 12);
        g.lineTo(x, y);
      }
      g.stroke();
    }
    speck(g, S, S, 900, ['#222', '#553'], 2);
    TX.skins.push(toTex(c));
    const [fc, fg] = mkC(S, S);
    fg.drawImage(c, 0, 0);
    const cx = S * 0.25,
      cy = S * 0.43;
    [
      [-15, 0],
      [15, 0],
    ].forEach(([dx]) => {
      const gr = fg.createRadialGradient(cx + dx, cy, 1, cx + dx, cy, 11);
      gr.addColorStop(0, 'rgba(10,2,2,.95)');
      gr.addColorStop(1, 'rgba(30,20,20,0)');
      fg.fillStyle = gr;
      fg.beginPath();
      fg.ellipse(cx + dx, cy, 11, 8, 0, 0, TAU);
      fg.fill();
    });
    fg.fillStyle = 'rgba(25,5,5,.9)';
    fg.beginPath();
    fg.ellipse(cx, cy + 42, 12, 5 + v * 2, 0, 0, TAU);
    fg.fill();
    fg.fillStyle = '#9a8f70';
    for (let i = -2; i <= 2; i++) {
      fg.fillRect(cx + i * 4 - 1.5, cy + 38, 3, 4);
    }
    fg.fillStyle = 'rgba(110,8,6,.8)';
    for (let i = 0; i < 5; i++) {
      fg.fillRect(cx + rand(-14, 14), cy + 52, rand(2, 4), rand(10, 40));
    }
    fg.fillStyle = 'rgba(60,50,40,.6)';
    fg.fillRect(cx - 4, cy + 12, 8, 18);
    if (v !== 1) {
      fg.fillStyle = 'rgba(20,16,12,.85)';
      fg.fillRect(0, 0, S, 40);
      blotch(fg, S, 60, 20, 'rgba(20,16,12,.7)', 8, 25);
    }
    TX.faces.push(toTex(c === c ? fc : fc));
  }
  const cloth = (base, fn) => {
    const S = 128,
      [c, g] = mkC(S, S);
    g.fillStyle = base;
    g.fillRect(0, 0, S, S);
    fn && fn(g, S);
    for (let y = 0; y < S; y += 2) {
      g.fillStyle = `rgba(0,0,0,${rand(0.02, 0.08)})`;
      g.fillRect(0, y, S, 1);
    }
    blotch(g, S, S, 10, 'rgba(40,30,15,.45)', 5, 25);
    blotch(g, S, S, 6, 'rgba(100,8,6,.65)', 4, 20);
    for (let i = 0; i < 6; i++) {
      g.fillStyle = 'rgba(0,0,0,.8)';
      g.fillRect(rand(0, S), rand(0, S), rand(2, 7), rand(2, 6));
    }
    return toTex(c);
  };
  const plaid = (a, b) => (g, S) => {
    g.globalAlpha = 0.55;
    g.fillStyle = b;
    for (let x = 0; x < S; x += 32) {
      g.fillRect(x, 0, 12, S);
      g.fillRect(0, x, S, 12);
    }
    g.globalAlpha = 0.3;
    g.fillStyle = '#000';
    for (let x = 16; x < S; x += 32) {
      g.fillRect(x, 0, 3, S);
      g.fillRect(0, x, S, 3);
    }
    g.globalAlpha = 1;
  };
  TX.cloth = {
    flannelR: cloth('#7a1f18', plaid('#7a1f18', '#1a1010')),
    flannelG: cloth('#2f4a2e', plaid('#2f4a2e', '#101a10')),
    denim: cloth('#3b4a5e', (g, S) => {
      for (let i = 0; i < 400; i++) {
        g.fillStyle = 'rgba(200,210,230,.08)';
        g.fillRect(rand(0, S), rand(0, S), 1, 3);
      }
      g.fillStyle = 'rgba(210,150,60,.5)';
      g.fillRect(0, S * 0.5, S, 1);
    }),
    white: cloth('#b8b2a2'),
    apron: cloth('#c4bfb0', (g, S) => blotch(g, S, S, 14, 'rgba(110,6,4,.75)', 6, 26)),
    navy: cloth('#1f2433'),
    suit: cloth('#4a4a48', (g, S) => {
      g.fillStyle = '#6a1616';
      g.fillRect(0, 0, 8, S);
      g.fillRect(S - 8, 0, 8, S);
    }),
    khaki: cloth('#6b6247'),
    grey: cloth('#46443f'),
    jacket: cloth('#5a4a30'),
  };
  {
    const [c, g] = mkC(64, 64);
    const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
    gr.addColorStop(0, 'rgba(255,255,255,1)');
    gr.addColorStop(0.35, 'rgba(255,255,255,.45)');
    gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr;
    g.fillRect(0, 0, 64, 64);
    TX.glow = toTex(c, false);
  }
  {
    const [c, g] = mkC(64, 64);
    const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
    gr.addColorStop(0, 'rgba(255,255,255,.9)');
    gr.addColorStop(0.6, 'rgba(255,255,255,.35)');
    gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr;
    g.fillRect(0, 0, 64, 64);
    blotch(g, 64, 64, 6, 'rgba(0,0,0,.3)', 4, 12);
    TX.smoke = toTex(c, false);
  }
  {
    const [c, g] = mkC(128, 128);
    const gr = g.createRadialGradient(64, 64, 0, 64, 64, 64);
    gr.addColorStop(0, 'rgba(255,248,220,1)');
    gr.addColorStop(0.2, 'rgba(255,190,90,.95)');
    gr.addColorStop(1, 'rgba(255,110,20,0)');
    g.fillStyle = gr;
    g.fillRect(0, 0, 128, 128);
    g.strokeStyle = 'rgba(255,220,150,.85)';
    for (let i = 0; i < 7; i++) {
      const a = (i / 7) * TAU + rand(-0.2, 0.2);
      g.lineWidth = rand(3, 6);
      g.beginPath();
      g.moveTo(64, 64);
      g.lineTo(64 + Math.cos(a) * 62, 64 + Math.sin(a) * 62);
      g.stroke();
    }
    TX.flash = toTex(c, false);
  }
  {
    const [c, g] = mkC(64, 64);
    g.fillStyle = 'rgba(55,3,2,.9)';
    for (let i = 0; i < 14; i++) {
      g.beginPath();
      g.arc(32 + rand(-16, 16), 32 + rand(-16, 16), rand(3, 12), 0, TAU);
      g.fill();
    }
    TX.blood = toTex(c, false);
  }
  {
    const [c, g] = mkC(32, 32);
    const gr = g.createRadialGradient(16, 16, 0, 16, 16, 16);
    gr.addColorStop(0, 'rgba(0,0,0,.95)');
    gr.addColorStop(0.35, 'rgba(10,10,10,.8)');
    gr.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = gr;
    g.fillRect(0, 0, 32, 32);
    TX.hole = toTex(c, false);
  }
  {
    const [c, g] = mkC(8, 128);
    const gr = g.createLinearGradient(0, 0, 0, 128);
    gr.addColorStop(0, 'rgba(255,255,255,.9)');
    gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr;
    g.fillRect(0, 0, 8, 128);
    TX.cone = toTex(c, false);
  }
}

const MAT = {};

function std(o) {
  return new THREE.MeshStandardMaterial(
    Object.assign(
      {
        roughness: 0.85,
        metalness: 0,
        envMapIntensity: 0.35,
      },
      o,
    ),
  );
}

function buildEnvironment() {
  const es = new THREE.Scene();
  const room = new THREE.Mesh(
    new THREE.BoxGeometry(20, 8, 20),
    new THREE.MeshBasicMaterial({
      color: 1315344,
      side: THREE.BackSide,
    }),
  );
  es.add(room);
  const lamp = (x, y, z, w, h, col, k) => {
    const m = new THREE.Mesh(
      new THREE.PlaneGeometry(w, h),
      new THREE.MeshBasicMaterial({
        color: col,
      }),
    );
    m.material.color.multiplyScalar(k);
    m.position.set(x, y, z);
    m.lookAt(0, 0, 0);
    es.add(m);
  };
  lamp(0, 3.9, 0, 6, 1, 16767136, 3);
  lamp(-6, 3.9, 5, 3, 0.6, 16767136, 2);
  lamp(7, 2, -9.9, 4, 3, 6978192, 0.8);
  lamp(-9.9, 1.5, 0, 3, 2, 3160648, 0.8);
  const floor = new THREE.Mesh(
    new THREE.PlaneGeometry(20, 20),
    new THREE.MeshBasicMaterial({
      color: 2762274,
    }),
  );
  floor.rotation.x = -Math.PI / 2;
  floor.position.y = -3.9;
  es.add(floor);
  const pm = new THREE.PMREMGenerator(renderer);
  const env = pm.fromScene(es, 0.04).texture;
  pm.dispose();
  scene.environment = env;
}

function buildMaterials() {
  for (const n of [
    'concrete',
    'paint',
    'panel',
    'tile',
    'checker',
    'cold',
    'brick',
    'asphalt',
    'pine',
    'metal',
    'corr',
  ]) {
    TX[n + 'N'] = normalFromHeight(
      TX[n + 'B'].image,
      n === 'corr' ? 6 : n === 'brick' || n === 'tile' ? 4 : 3,
    );
    if (n === 'paint' || n === 'panel') {
      TX[n + 'N'].wrapT = THREE.ClampToEdgeWrapping;
    }
  }
  MAT.concrete = std({
    map: TX.concrete,
    normalMap: TX.concreteN,
    normalScale: new THREE.Vector2(1, 1),
    roughness: 0.88,
  });
  MAT.paint = std({
    map: TX.paint,
    normalMap: TX.paintN,
    normalScale: new THREE.Vector2(0.8, 0.8),
    roughness: 0.8,
  });
  MAT.panel = std({
    map: TX.panel,
    normalMap: TX.panelN,
    normalScale: new THREE.Vector2(0.8, 0.8),
    roughness: 0.6,
  });
  MAT.tile = std({
    map: TX.tile,
    normalMap: TX.tileN,
    normalScale: new THREE.Vector2(1, 1),
    roughness: 0.35,
  });
  MAT.checker = std({
    map: TX.checker,
    normalMap: TX.checkerN,
    normalScale: new THREE.Vector2(0.5, 0.5),
    roughness: 0.45,
  });
  MAT.cold = std({
    map: TX.cold,
    normalMap: TX.coldN,
    normalScale: new THREE.Vector2(0.8, 0.8),
    roughness: 0.3,
  });
  MAT.brick = std({
    map: TX.brick,
    normalMap: TX.brickN,
    normalScale: new THREE.Vector2(1.2, 1.2),
    roughness: 0.9,
  });
  MAT.asphalt = std({
    map: TX.asphalt,
    normalMap: TX.asphaltN,
    normalScale: new THREE.Vector2(1, 1),
    roughness: 1,
    roughnessMap: TX.asphaltR,
  });
  MAT.pine = std({
    map: TX.pine,
    normalMap: TX.pineN,
    normalScale: new THREE.Vector2(0.8, 0.8),
    roughness: 0.75,
  });
  MAT.pineDark = std({
    map: TX.pine,
    normalMap: TX.pineN,
    normalScale: new THREE.Vector2(0.8, 0.8),
    color: 9075302,
    roughness: 0.8,
  });
  MAT.metal = std({
    map: TX.metal,
    normalMap: TX.metalN,
    normalScale: new THREE.Vector2(0.7, 0.7),
    roughness: 0.6,
    metalness: 0.35,
  });
  MAT.rack = std({
    map: TX.metal,
    color: 12615760,
    roughness: 0.55,
    metalness: 0.4,
  });
  MAT.corr = std({
    map: TX.corr,
    normalMap: TX.corrN,
    normalScale: new THREE.Vector2(1, 1),
    roughness: 0.5,
    metalness: 0.5,
  });
  MAT.steel = std({
    color: 2894376,
    roughness: 0.5,
    metalness: 0.6,
  });
  MAT.dark = std({
    color: 1381396,
    roughness: 0.9,
  });
  MAT.ceilTile = std({
    map: TX.concrete,
    color: 9078136,
    roughness: 0.95,
  });
  MAT.board = std({
    map: TX.pine,
    normalMap: TX.pineN,
    normalScale: new THREE.Vector2(0.8, 0.8),
    color: 12298380,
    roughness: 0.8,
  });
  MAT.chrome = std({
    color: 14211288,
    roughness: 0.18,
    metalness: 1,
  });
  MAT.rubber = std({
    color: 1315860,
    roughness: 0.9,
  });
  MAT.redPaint = std({
    color: 8002066,
    roughness: 0.5,
    metalness: 0.2,
  });
  MAT.yellowPaint = std({
    color: 11043872,
    roughness: 0.55,
    metalness: 0.2,
  });
  MAT.meat = std({
    color: 8006178,
    roughness: 0.45,
  });
  MAT.fat = std({
    color: 14207152,
    roughness: 0.5,
  });
  MAT.bulb = new THREE.MeshBasicMaterial({
    color: 16773320,
  });
  MAT.bulbOff = std({
    color: 3814960,
    roughness: 0.3,
  });
  MAT.glass = std({
    color: 2240568,
    roughness: 0.1,
    metalness: 0.2,
    transparent: true,
    opacity: 0.45,
  });
  MAT.window = new THREE.MeshBasicMaterial({
    color: 14268528,
  });
  MAT.gBlue = std({
    color: 3817286,
    map: TX.gunmetal,
    roughnessMap: TX.gunmetal,
    bumpMap: TX.gunmetal,
    bumpScale: 6e-4,
    roughness: 0.55,
    metalness: 0.85,
  });
  MAT.gPark = std({
    color: 5922134,
    map: TX.gunmetal,
    roughnessMap: TX.gunmetal,
    roughness: 0.85,
    metalness: 0.6,
  });
  MAT.gWood = std({
    map: TX.walnut,
    bumpMap: TX.walnut,
    bumpScale: 8e-4,
    roughness: 0.42,
  });
  MAT.gGrip = std({
    map: TX.checkerGrip,
    bumpMap: TX.checkerGrip,
    bumpScale: 0.0015,
    roughness: 0.6,
  });
  MAT.gSteel = std({
    color: 9080466,
    roughness: 0.3,
    metalness: 1,
  });
  {
    const S = 256,
      [c, g] = mkC(S, S);
    g.fillStyle = '#3a0610';
    g.fillRect(0, 0, S, S);
    for (let i = 0; i < 60; i++) {
      g.strokeStyle = `rgba(${randi(200, 255)},${randi(150, 200)},${randi(40, 90)},${rand(0.25, 0.7)})`;
      g.lineWidth = rand(0.6, 2.2);
      g.beginPath();
      let x = rand(0, S),
        y = rand(0, S);
      g.moveTo(x, y);
      for (let k = 0; k < 6; k++) {
        x += rand(-40, 40);
        y += rand(-40, 40);
        g.quadraticCurveTo(x + rand(-20, 20), y + rand(-20, 20), x, y);
      }
      g.stroke();
    }
    blotch(g, S, S, 20, 'rgba(120,10,30,.4)', 10, 50);
    TX.pap = toTex(c);
  }
  MAT.papMetal = std({
    map: TX.pap,
    emissiveMap: TX.pap,
    emissive: 16777215,
    emissiveIntensity: 0.55,
    roughness: 0.3,
    metalness: 0.8,
  });
  MAT.papWood = std({
    map: TX.pap,
    color: 5910592,
    roughness: 0.45,
  });
  MAT.gBake = std({
    color: 2758672,
    roughness: 0.35,
  });
  MAT.gBrass = std({
    color: 11897404,
    roughness: 0.3,
    metalness: 1,
  });
  MAT.gCopper = std({
    color: 11559994,
    roughness: 0.35,
    metalness: 1,
  });
  MAT.gGlow = new THREE.MeshBasicMaterial({
    color: 16742954,
  });
  MAT.gGlass = new THREE.MeshBasicMaterial({
    color: 16752720,
    transparent: true,
    opacity: 0.55,
  });
  MAT.skinHand = std({
    color: 11041374,
    roughness: 0.65,
  });
  MAT.watch = std({
    color: 3811868,
    roughness: 0.6,
  });
  MAT.watchFace = std({
    color: 15260864,
    roughness: 0.3,
    emissive: 1710096,
  });
  MAT.sleeve = std({
    map: TX.cloth.khaki,
    color: 6972496,
    roughness: 0.95,
  });
  MAT.hammerHead = std({
    color: 3815994,
    roughness: 0.4,
    metalness: 0.8,
  });
  MAT.blade = std({
    color: 10133668,
    roughness: 0.25,
    metalness: 1,
  });
}

function worldUV(g, s) {
  const p = g.attributes.position,
    n = g.attributes.normal,
    uv = g.attributes.uv;
  for (let i = 0; i < p.count; i++) {
    const ax = Math.abs(n.getX(i)),
      ay = Math.abs(n.getY(i)),
      az = Math.abs(n.getZ(i));
    let u, v;
    if (ay > ax && ay > az) {
      u = p.getX(i);
      v = p.getZ(i);
    } else if (ax > az) {
      u = p.getZ(i) * Math.sign(n.getX(i) || 1);
      v = p.getY(i);
    } else {
      u = -p.getX(i) * Math.sign(n.getZ(i) || 1);
      v = p.getY(i);
    }
    uv.setXY(i, u / s, v / s);
  }
  uv.needsUpdate = true;
}

function mergeGeos(geos) {
  let vc = 0,
    ic = 0;
  for (const g of geos) {
    vc += g.attributes.position.count;
    ic += g.index ? g.index.count : g.attributes.position.count;
  }
  const pos = new Float32Array(vc * 3),
    nor = new Float32Array(vc * 3),
    uv = new Float32Array(vc * 2),
    idx = new Uint32Array(ic);
  let vo = 0,
    io = 0;
  for (const g of geos) {
    const n = g.attributes.position.count;
    pos.set(g.attributes.position.array, vo * 3);
    nor.set(g.attributes.normal.array, vo * 3);
    if (g.attributes.uv) {
      uv.set(g.attributes.uv.array, vo * 2);
    }
    if (g.index) {
      const a = g.index.array;
      for (let i = 0; i < a.length; i++) {
        idx[io++] = a[i] + vo;
      }
    } else {
      for (let i = 0; i < n; i++) {
        idx[io++] = vo + i;
      }
    }
    vo += n;
  }
  const m = new THREE.BufferGeometry();
  m.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  m.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
  m.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  m.setIndex(new THREE.BufferAttribute(idx, 1));
  m.computeBoundingSphere();
  return m;
}

function glowSprite(color, size, opacity = 1, fog = false) {
  const s = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: TX.glow,
      color: color,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      transparent: true,
      opacity: opacity,
      fog: fog,
    }),
  );
  s.scale.set(size, size, 1);
  return s;
}

function textCanvas(w, h, draw) {
  const [c, g] = mkC(w, h);
  draw(g, w, h);
  return toTex(c, false);
}

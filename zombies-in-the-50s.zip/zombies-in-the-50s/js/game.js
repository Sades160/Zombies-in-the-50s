const CRATE_COST = 900;

const PU_TYPES = ['resupply', 'overkill', 'doublepay', 'blackout', 'carpenter'];

const PU_INFO = {
  resupply: {
    name: 'Resupply',
    say: 'Resupply',
  },
  overkill: {
    name: 'Overkill',
    say: 'Overkill',
  },
  doublepay: {
    name: 'Double Pay',
    say: 'Double pay',
  },
  blackout: {
    name: 'Blackout',
    say: 'Blackout',
  },
  carpenter: {
    name: 'Carpenter',
    say: 'Carpenter',
  },
};

const G = {
  mode: 'menu',
  net: 'solo',
  map: 'depot',
  diff: 'normal',
  round: 0,
  toSpawn: 0,
  spawnT: 0,
  inter: 0,
  time: 0,
  power: false,
  boards: [],
  crate: {
    state: 'idle',
    t: 0,
    spot: 0,
    result: null,
    owner: null,
    uses: 0,
  },
  pus: [],
  instakill: 0,
  doublepay: 0,
  over: false,
  drops: 0,
  repairPts: 0,
  flowT: 0,
  puid: 1,
  gameId: 0,
  roundShown: -1,
};

const ME = {
  x: 0,
  z: 0,
  y: 0,
  vy: 0,
  vx: 0,
  vz: 0,
  yaw: 0,
  pitch: 0,
  hp: 150,
  maxHp: 150,
  lastHurt: -99,
  pts: 500,
  weapons: [],
  cur: 0,
  nades: 2,
  perks: new Set(),
  adsK: 0,
  sprinting: false,
  crouch: 0,
  prone: 0,
  stance: 0,
  down: false,
  dead: false,
  bleed: 0,
  secondUsed: false,
  moveK: 0,
  stepAcc: 0,
  shots: 0,
  stats: {
    kills: 0,
    heads: 0,
    downs: 0,
    revives: 0,
    earned: 0,
  },
  flashOn: true,
  holdT: 0,
  holdTarget: null,
  selfRevT: 0,
};

const IN = {
  f: 0,
  b: 0,
  l: 0,
  r: 0,
  fire: false,
  aim: false,
  aimT: false,
  sprint: false,
  sprintT: false,
  crouch: false,
  crouchHT: 0,
  use: false,
  usePressed: false,
  jump: false,
  lookDX: 0,
  lookDY: 0,
  scores: false,
};

const W = {
  cool: 0,
  reload: null,
  cycleT: 0,
  cycleDur: 1,
  switchT: 0,
  switchDur: 0.5,
  switchTo: null,
  knifeT: 0,
  knifeDur: 0.55,
  nadeT: 0,
  nadeDur: 0.65,
  drinkT: 0,
  drinkDur: 2.4,
  drinkId: null,
  repairing: false,
  hammerPh: 0,
  flashT: 0,
  fired: false,
  spreadAdd: 0,
  autoReloadT: 0,
};

function K(action) {
  if (typeof PAD !== 'undefined' && PAD.active) {
    return '<span class="k">X</span>';
  }
  return TOUCH
    ? '<span class="k">USE</span>'
    : `<span class="k">${escapeHTML(keyLabel(SET.keys[action]))}</span>`;
}

function curW() {
  return ME.weapons[ME.cur];
}

const PAP_CACHE = {};

function wdef(w) {
  const base = GUNS[w.id];
  if (!w.pap) {
    return base;
  }
  if (PAP_CACHE[w.id]) {
    return PAP_CACHE[w.id];
  }
  const d = Object.assign({}, base, {
    name: base.pap,
    papd: true,
    dmg: base.dmg * (base.wonder ? 1.8 : 2.4),
    res: base.res * 2,
    pen: base.pen + 1,
    rpm: base.rpm * (base.cycle === 'bolt' ? 1.25 : 1.1),
  });
  if (base.rtype === 'mag') {
    d.mag = Math.round(base.mag * 1.5);
  } else if (base.rtype === 'shell') {
    d.mag = base.mag + 2;
  } else {
    d.mag = base.mag;
  }
  if (base.splash) {
    d.splash = base.splash * 1.8;
    d.radius = base.radius * 1.3;
  }
  if (base.blast) {
    d.blast = {
      range: base.blast.range * 1.35,
      cone: base.blast.cone * 1.15,
    };
  }
  if (base.arc) {
    d.arc = {
      hops: base.arc.hops + 6,
      reach: base.arc.reach * 1.3,
    };
  }
  return (PAP_CACHE[w.id] = d);
}

function ownSlot(id) {
  return ME.weapons.find((w) => w.id === id);
}

const isAuth = () => G.net !== 'client';

function addPoints(n, silent) {
  if (G.doublepay > 0 && n > 0) {
    n *= 2;
  }
  ME.pts += n;
  if (n > 0) {
    ME.stats.earned += n;
  }
  if (!silent) {
    popPts(n);
  }
}

function spend(n) {
  if (ME.pts >= n) {
    ME.pts -= n;
    popPts(-n);
    AU.play('register', {
      g: 0.7,
    });
    return true;
  }
  AU.play('denied', {
    g: 0.7,
  });
  const p = $('#promptText');
  p.classList.add('no');
  setTimeout(() => p.classList.remove('no'), 350);
  return false;
}

function popPts(n) {
  const el = document.createElement('div');
  el.className = 'pop' + (n < 0 ? ' neg' : '');
  el.textContent = (n > 0 ? '+' : '') + n;
  el.style.right = rand(0, 40) + 'px';
  el.style.bottom = rand(-6, 6) + 'px';
  $('#pops').appendChild(el);
  setTimeout(() => el.remove(), 1100);
}

function sendEvent(ev) {
  if (isAuth()) {
    handleEvent(NET.me, ev);
  } else {
    NET.push(ev);
  }
}

function broadcast(ev) {
  handleBroadcast(ev);
  if (G.net === 'host') {
    NET.push(ev);
  }
}

function handleEvent(peer, ev) {
  const [ty, a, b, c, d] = ev;
  switch (ty) {
    case 'hit':
      zHitHost(a, b, c, d, peer);
      break;

    case 'door': {
      const dr = WORLD.doors[a];
      if (dr && !dr.open) {
        G.doorsOpen = G.doorsOpen || [];
        setDoorOpen(dr, true, true);
      }
      break;
    }

    case 'board': {
      const w = WORLD.windows[a];
      if (w && G.boards[a] < 6) {
        G.boards[a]++;
        broadcast(['brd', a]);
      }
      break;
    }

    case 'power':
      if (!G.power) {
        setPower(true, true);
        broadcast(['pow']);
      }
      break;

    case 'crate':
      if (G.crate.state === 'idle') {
        const c0 = G.crate;
        c0.state = 'rolling';
        c0.t = 0;
        c0.owner = peer;
        c0.uses++;
        const owned = playerWeapons(peer);
        const pool = CRATE_POOL.filter((id) => !owned.includes(id));
        c0.result = pick(pool.length ? pool : CRATE_POOL);
        c0.moving = c0.uses >= 4 && Math.random() < 0.22;
        broadcast(['crroll']);
      }
      break;

    case 'crtake':
      if (G.crate.state === 'ready' && G.crate.owner === peer) {
        G.crate.state = 'closing';
        G.crate.t = 0;
      }
      break;

    case 'pu': {
      const i = G.pus.findIndex((p) => p.id === a);
      if (i >= 0) {
        const p = G.pus[i];
        G.pus.splice(i, 1);
        applyPUHost(p.type);
        broadcast(['pwr', p.type, p.id]);
      }
      break;
    }

    case 'rev':
      handleRevive(peer, a);
      break;

    case 'candypu':
      if (typeof a === 'number' && typeof b === 'number') {
        spawnPU(a, b);
      }
      break;

    case 'gx':
      if (peer !== NET.me) {
        explodeFX(a, b, c);
      }
      break;
  }
}

function handleBroadcast(ev) {
  const [ty, a, b, c, d, e] = ev;
  switch (ty) {
    case 'k': {
      const z = zById(a);
      if (z) {
        zStartDeath(z, c, e);
      }
      if (b === NET.me) {
        ME.stats.kills++;
        if (c === 'head') {
          ME.stats.heads++;
        }
        addPoints(
          d === 'knife' ? 120 : d === 'exp' || d === 'gale' || d === 'volt' ? 40 : c === 'head' ? 90 : 50,
        );
        if (ME.candy && ME.candy.id === 'cherry' && ME.candy.n > 0 && z) {
          ME.candy.n--;
          explode(z.x, 1, z.z, 3.5, 99999, false, true);
          if (ME.candy.n <= 0) {
            ME.candy = null;
          }
        }
        hitmark(true);
      }
      break;
    }

    case 'rip': {
      const w = WORLD.windows[a];
      if (!w) {
        break;
      }
      if (!isAuth()) {
        break;
      }
      syncBoards(w, G.boards[a], true);
      AU.play('rip', {
        pos: [w.x, 1.4, w.z],
        wet: 0.3,
      });
      const z = zById(b);
      if (z) {
        z.pullT = 0.35;
      }
      break;
    }

    case 'brd': {
      const w = WORLD.windows[a];
      if (!w) {
        break;
      }
      if (isAuth()) {
        syncBoards(w, G.boards[a], true);
      }
      AU.play('hammer', {
        pos: [w.inner.x, 1.4, w.inner.z],
      });
      break;
    }

    case 'dm':
      if (a === NET.me) {
        damageMe(b, c, d);
      }
      break;

    case 'wave':
      onWaveStart(a);
      break;

    case 'wend':
      onWaveEnd();
      break;

    case 'pwr':
      onPowerup(a);
      break;

    case 'refund':
      if (a === NET.me) {
        addPoints(b, false);
      }
      showCenter('The crate is empty. It moved.', 2.2);
      break;

    case 'pow':
      if (!isAuth()) {
        setPower(true, true);
      }
      showCenter('Main power restored', 2.5);
      break;

    case 'crroll':
      AU.play('lid', {
        pos: [WORLD.crate.grp.position.x, 1, WORLD.crate.grp.position.z],
      });
      AU.play('crate_music', {
        pos: [WORLD.crate.grp.position.x, 1, WORLD.crate.grp.position.z],
        ref: 3,
        wet: 0.3,
      });
      break;

    case 'over':
      gameOver();
      break;
  }
}

function playersAll() {
  const list = [
    {
      peer: NET.me,
      x: ME.x,
      z: ME.z,
      down: ME.down,
      dead: ME.dead,
      hidden: candyActive('ghost'),
      me: true,
    },
  ];
  if (G.net === 'host') {
    for (const rp of NET.remotes()) {
      list.push({
        peer: rp.peer,
        x: rp.x,
        z: rp.z,
        down: rp.down,
        dead: rp.dead,
        hidden: rp.hidden,
      });
    }
  }
  return list;
}

function playerWeapons(peer) {
  if (peer === NET.me) {
    return ME.weapons.map((w) => w.id);
  }
  const rp = NET.remote(peer);
  return rp ? rp.wp : [];
}

function hurtPlayer(p, amt, z) {
  if (p.me) {
    damageMe(amt, z.x, z.z);
  } else {
    broadcast(['dm', p.peer, amt, z.x, z.z]);
  }
}

function waveCount(r) {
  const base = r <= 4 ? [6, 8, 13, 18][r - 1] : Math.floor(18 + (r - 4) * 5.5 + Math.max(0, r - 10) * 2);
  const n = playersAll().length;
  return Math.min(160, Math.round(base * (1 + 0.55 * (n - 1))));
}

function updateRounds(dt) {
  if (G.over) {
    return;
  }
  if (G.inter > 0) {
    G.inter -= dt;
    if (G.inter <= 0) {
      G.round++;
      G.toSpawn = waveCount(G.round);
      G.spawnT = 2;
      G.drops = 0;
      broadcast(['wave', G.round]);
    }
    return;
  }
  if (G.toSpawn > 0) {
    G.spawnT -= dt;
    const alive = ZBS.filter((z) => !z.dead).length;
    if (G.spawnT <= 0 && alive < 24) {
      if (spawnZombieHost()) {
        G.toSpawn--;
      }
      G.spawnT = Math.max(0.55, 2.2 - G.round * 0.1) * rand(0.7, 1.2);
    }
  } else if (!ZBS.some((z) => !z.dead)) {
    G.inter = 10;
    broadcast(['wend']);
  }
  const pl = playersAll();
  if (pl.length && pl.every((p) => p.down || p.dead)) {
    G.over = true;
    broadcast(['over']);
  }
}

function onWaveStart(n) {
  G.round = n;
  G.repairPts = 0;
  G.candyUses = 0;
  if (n > 1) {
    ME.nades = Math.min(4, ME.nades + 2);
  }
  AU.play('mus_round', {
    bus: 'mus',
  });
  const el = $('#round');
  renderRound(n, true);
  el.classList.remove('pulse');
  el.classList.add('fresh');
  setTimeout(() => el.classList.remove('fresh'), 60);
  if (ME.dead) {
    respawnMe();
  }
}

function onWaveEnd() {
  AU.play('mus_end', {
    bus: 'mus',
  });
  $('#round').classList.add('pulse');
  setTimeout(() => $('#round').classList.remove('pulse'), 8e3);
}

function updateCrateHost(dt) {
  const c = G.crate;
  c.t += dt;
  if (c.state === 'rolling' && c.t >= 4.6) {
    if (c.moving) {
      c.state = 'moving';
      c.t = 0;
      let n;
      do {
        n = (Math.random() * WORLD.crate.spots.length) | 0;
      } while (n === c.spot);
      c.spot = n;
      c.uses = 0;
      broadcast(['refund', c.owner, CRATE_COST]);
    } else {
      c.state = 'ready';
      c.t = 0;
    }
  } else if (c.state === 'ready' && c.t > 12) {
    c.state = 'closing';
    c.t = 0;
  } else if (c.state === 'closing' && c.t > 0.6) {
    c.state = 'idle';
    c.owner = null;
    c.result = null;
  } else if (c.state === 'moving' && c.t > 4.2) {
    c.state = 'idle';
    c.owner = null;
    c.result = null;
  }
}

const PU_VIS = new Map();

const PU_TEX = {};

function puTex(type) {
  if (PU_TEX[type]) {
    return PU_TEX[type];
  }
  const draw = {
    resupply: (g) => {
      for (let i = 0; i < 3; i++) {
        const x = 38 + i * 20;
        g.fillStyle = '#e8c070';
        g.fillRect(x, 50, 12, 38);
        g.beginPath();
        g.moveTo(x, 50);
        g.lineTo(x + 6, 34);
        g.lineTo(x + 12, 50);
        g.fill();
        g.fillStyle = '#8a6a2a';
        g.fillRect(x, 82, 12, 7);
      }
    },
    overkill: (g) => {
      g.fillStyle = '#efe6d2';
      g.beginPath();
      g.arc(64, 56, 27, 0, TAU);
      g.fill();
      g.fillRect(50, 70, 28, 20);
      g.fillStyle = '#1a1210';
      g.beginPath();
      g.arc(54, 57, 7, 0, TAU);
      g.arc(74, 57, 7, 0, TAU);
      g.fill();
      for (let i = 0; i < 4; i++) {
        g.fillRect(53 + i * 6, 82, 3, 8);
      }
    },
    doublepay: (g) => {
      g.fillStyle = '#ffd27a';
      g.font = 'bold 50px Oswald, Impact, sans-serif';
      g.textAlign = 'center';
      g.textBaseline = 'middle';
      g.fillText('x2', 64, 66);
    },
    blackout: (g) => {
      g.fillStyle = '#ff9a3a';
      g.beginPath();
      for (let i = 0; i < 16; i++) {
        const a = (i / 16) * TAU,
          r = i % 2 ? 13 : 34;
        g.lineTo(64 + Math.cos(a) * r, 64 + Math.sin(a) * r);
      }
      g.fill();
    },
    carpenter: (g) => {
      g.save();
      g.translate(64, 64);
      g.rotate(-0.6);
      g.fillStyle = '#b98a55';
      g.fillRect(-5, -8, 10, 44);
      g.fillStyle = '#bfc6cc';
      g.fillRect(-20, -22, 40, 15);
      g.restore();
    },
  };
  const [c, g] = mkC(128, 128);
  g.fillStyle = 'rgba(18,12,8,.92)';
  g.beginPath();
  g.arc(64, 64, 58, 0, TAU);
  g.fill();
  g.strokeStyle = '#d0281c';
  g.lineWidth = 5;
  g.stroke();
  draw[type](g);
  PU_TEX[type] = {
    tex: toTex(c, false),
    url: c.toDataURL(),
  };
  return PU_TEX[type];
}

function spawnPU(x, z) {
  const p = {
    id: G.puid++,
    type: pick(PU_TYPES),
    x: x,
    z: z,
    t: 0,
  };
  G.pus.push(p);
}

function updatePUHost(dt) {
  for (let i = G.pus.length - 1; i >= 0; i--) {
    const p = G.pus[i];
    p.t += dt;
    if (p.t > 30) {
      G.pus.splice(i, 1);
    }
  }
}

function syncPUVisuals(dt) {
  const ids = new Set(G.pus.map((p) => p.id));
  for (const [id, v] of PU_VIS) {
    if (!ids.has(id)) {
      scene.remove(v.grp);
      PU_VIS.delete(id);
    }
  }
  for (const p of G.pus) {
    let v = PU_VIS.get(p.id);
    if (!v) {
      const grp = new THREE.Group();
      const disc = new THREE.Mesh(
        new THREE.PlaneGeometry(0.7, 0.7),
        new THREE.MeshBasicMaterial({
          map: puTex(p.type).tex,
          transparent: true,
          side: THREE.DoubleSide,
        }),
      );
      grp.add(disc);
      const halo = glowSprite(16734762, 1.9, 0.7, false);
      grp.add(halo);
      grp.position.set(p.x, 1, p.z);
      scene.add(grp);
      v = {
        grp: grp,
        disc: disc,
        t: 0,
      };
      PU_VIS.set(p.id, v);
      AU.play('pw_spawn', {
        pos: [p.x, 1, p.z],
      });
    }
    v.t += dt;
    v.disc.rotation.y += dt * 2;
    v.grp.position.y = 1 + Math.sin(v.t * 2) * 0.12;
    v.grp.visible = (p.t || 0) < 22 || Math.sin(v.t * ((p.t || 0) > 26 ? 26 : 12)) > 0;
    if (!ME.dead && Math.hypot(ME.x - p.x, ME.z - p.z) < 1.15 && !v.claimed) {
      v.claimed = true;
      sendEvent(['pu', p.id]);
    }
  }
}

function applyPUHost(type) {
  if (type === 'overkill') {
    G.instakill = 30;
  }
  if (type === 'doublepay') {
    G.doublepay = 30;
  }
  if (type === 'blackout') {
    for (const z of ZBS) {
      if (!z.dead) {
        if (z.win && z.win.busy === z) {
          z.win.busy = null;
        }
        broadcast(['k', z.id, null, 'body', 'exp', 1]);
      }
    }
  }
  if (type === 'carpenter') {
    WORLD.windows.forEach((w) => {
      G.boards[w.i] = 6;
      syncBoards(w, 6, true);
    });
  }
}

function onPowerup(type) {
  AU.play('pw_get');
  AU.say(PU_INFO[type].say);
  showCenter(PU_INFO[type].name, 2);
  if (type === 'resupply') {
    ME.weapons.forEach((w) => (w.res = wdef(w).res));
    ME.nades = 4;
  }
  if (type === 'blackout') {
    flashScreen(0.9);
    addPoints(400);
  }
  if (type === 'carpenter') {
    addPoints(200);
    AU.play('hammer');
  }
  if (!isAuth()) {
    if (type === 'overkill') {
      G.instakill = 30;
    }
    if (type === 'doublepay') {
      G.doublepay = 30;
    }
  }
}

function resetMe(slot = 0) {
  ME.candy = null;
  if (typeof renderCandy === 'function') {
    renderCandy();
  }
  const sp = WORLD.spawns[slot % WORLD.spawns.length];
  Object.assign(ME, {
    x: sp[0],
    z: sp[1],
    y: 0,
    vy: 0,
    vx: 0,
    vz: 0,
    yaw: 0,
    pitch: 0,
    hp: 150,
    maxHp: 150,
    lastHurt: -99,
    pts: 500,
    weapons: [
      {
        id: 'warden',
        mag: 8,
        res: 64,
      },
    ],
    cur: 0,
    nades: 2,
    perks: new Set(),
    adsK: 0,
    crouch: 0,
    prone: 0,
    stance: 0,
    down: false,
    dead: false,
    bleed: 0,
    secondUsed: false,
    shots: 0,
    stats: {
      kills: 0,
      heads: 0,
      downs: 0,
      revives: 0,
      earned: 0,
    },
    holdT: 0,
    selfRevT: 0,
  });
  Object.assign(W, {
    cool: 0,
    reload: null,
    cycleT: 0,
    switchT: 0.5,
    switchDur: 0.5,
    switchTo: null,
    knifeT: 0,
    nadeT: 0,
    drinkT: 0,
    repairing: false,
    flashT: 0,
    fired: false,
    spreadAdd: 0,
    autoReloadT: 0,
  });
  VM.set('warden');
  renderPerks();
}

function respawnMe() {
  const pts = ME.pts,
    st = ME.stats;
  resetMe(randi(0, 3));
  ME.pts = pts;
  ME.stats = st;
  showCenter('Back on your feet', 2);
}

function giveWeapon(id, pap) {
  const own = ownSlot(id);
  if (own && !pap) {
    const d = wdef(own);
    own.mag = d.mag;
    own.res = d.res;
    return;
  }
  const slot = {
    id: id,
    pap: !!pap,
  };
  const d = wdef(slot);
  slot.mag = d.mag;
  slot.res = d.res;
  if (own) {
    Object.assign(own, slot);
    ME.cur = ME.weapons.indexOf(own);
    W.reload = null;
    W.switchT = W.switchDur = 0.5;
    VM.set(id, own.pap);
    AU.play('raise');
    return;
  }
  if (ME.weapons.length < 2) {
    ME.weapons.push(slot);
    ME.cur = ME.weapons.length - 1;
  } else {
    ME.weapons[ME.cur] = slot;
  }
  W.reload = null;
  W.cycleT = 0;
  W.cool = 0;
  W.switchT = W.switchDur = 0.5;
  VM.set(id, slot.pap);
  AU.play('raise');
}

function switchWeapon(to) {
  if (ME.weapons.length < 2 || W.switchT > 0 || W.drinkT > 0) {
    return;
  }
  if (to == null && ME.weapons.some((w) => w.inPress)) {
    return;
  }
  const n = to == null ? (ME.cur + 1) % ME.weapons.length : to;
  if (n === ME.cur || !ME.weapons[n]) {
    return;
  }
  ME.cur = n;
  W.reload = null;
  W.cycleT = 0;
  W.cool = 0;
  W.switchT = W.switchDur = 0.5;
  VM.set(curW().id, curW().pap);
  AU.play('raise');
}

function drinkPerk(id) {
  W.drinkT = W.drinkDur = 3;
  W.drinkId = id;
  W.reload = null;
  VM.setBottle(PERKS[id].bottle);
  const s = WORLD.sodas.find((s) => s.id === id);
  AU.play('vend', {
    pos: [s.x, 1, s.z],
  });
  AU.play('jingle_' + id, {
    pos: [s.x, 1.5, s.z],
    ref: 3,
    bus: 'mus',
    g: 1.2,
  });
  setTimeout(() => AU.play('pop'), 600);
  setTimeout(() => AU.play('gulp'), 1050);
  setTimeout(
    () =>
      AU.play('smash', {
        g: 0.5,
      }),
    2650,
  );
}

function finishDrink(id) {
  ME.perks.add(id);
  if (id === 'titan') {
    ME.maxHp = 250;
    ME.hp = 250;
  }
  renderPerks(id);
}

function renderPerks(fresh) {
  $('#perks').innerHTML = [...ME.perks]
    .map(
      (id) =>
        `<span class="cap${id === fresh ? ' fresh' : ''}"><img alt="${escapeHTML(PERKS[id].name)}" title="${escapeHTML(PERKS[id].name)}" src="${perkIcon(id)}"></span>`,
    )
    .join('');
}

function damageMe(n, fx, fz) {
  if (G.mode !== 'play' || ME.down || ME.dead) {
    return;
  }
  if (candyActive('iron')) {
    AU.play('metal', {
      g: 0.4,
    });
    return;
  }
  ME.hp -= n;
  ME.lastHurt = G.time;
  AU.play('p_grunt');
  AU.play('flesh', {
    g: 0.8,
  });
  ME.shake = Math.max(ME.shake || 0, 0.35);
  bloodSplat(3 + randi(0, 3));
  if (fx != null) {
    dmgDir(fx, fz);
  }
  if (ME.hp <= 0) {
    goDown();
  }
}

function goDown() {
  ME.hp = 0;
  ME.stats.downs++;
  AU.play('p_down');
  if (G.net === 'solo') {
    if (ME.perks.has('second') && !ME.secondUsed) {
      ME.secondUsed = true;
      ME.down = true;
      ME.selfRevT = 3.5;
      ME.perks.clear();
      renderPerks();
      ME.maxHp = 150;
      showCenter('Second Chance', 2);
      return;
    }
    G.over = true;
    gameOver();
    return;
  }
  ME.down = true;
  ME.bleed = 30;
  ME.maxHp = 150;
  const hadSecond = ME.perks.has('second');
  ME.perks.clear();
  renderPerks();
  if (hadSecond && !ME.secondUsed) {
    ME.secondUsed = true;
    ME.selfRevT = 6;
  }
  const pistol = ME.weapons.findIndex((w) => w.id === 'warden');
  if (pistol >= 0 && pistol !== ME.cur) {
    ME.cur = pistol;
    VM.set('warden');
  }
  W.reload = null;
}

function getUp(byPeer) {
  ME.down = false;
  ME.hp = ME.maxHp * 0.5;
  ME.lastHurt = G.time;
  ME.selfRevT = 0;
  showCenter(byPeer ? `${NET.nameOf(byPeer)} got you up` : 'Back on your feet', 2);
}

function handleRevive(from, target) {
  if (target === NET.me && ME.down && !ME.dead) {
    getUp(from);
  }
}

function collideMe() {
  const r = 0.34;
  for (let pass = 0; pass < 2; pass++) {
    for (const c of WORLD.colliders) {
      if (!c.on) {
        continue;
      }
      const cx = clamp(ME.x, c.minX, c.maxX),
        cz = clamp(ME.z, c.minZ, c.maxZ);
      const dx = ME.x - cx,
        dz = ME.z - cz,
        d2 = dx * dx + dz * dz;
      if (d2 < r * r) {
        if (d2 > 1e-9) {
          const d = Math.sqrt(d2);
          ME.x += (dx / d) * (r - d);
          ME.z += (dz / d) * (r - d);
        } else {
          const l = ME.x - c.minX,
            rr = c.maxX - ME.x,
            t = ME.z - c.minZ,
            b = c.maxZ - ME.z,
            m = Math.min(l, rr, t, b);
          if (m === l) {
            ME.x = c.minX - r;
          } else if (m === rr) {
            ME.x = c.maxX + r;
          } else if (m === t) {
            ME.z = c.minZ - r;
          } else {
            ME.z = c.maxZ + r;
          }
        }
      }
    }
  }
  for (const z of ZBS) {
    if (z.dead || z.anim === 3) {
      continue;
    }
    const dx = ME.x - z.x,
      dz = ME.z - z.z,
      d = Math.hypot(dx, dz);
    if (d < 0.55 && d > 0.001) {
      ME.x += (dx / d) * (0.55 - d) * 0.5;
      ME.z += (dz / d) * (0.55 - d) * 0.5;
    }
  }
}

function updatePlayer(dt) {
  const fx = -Math.sin(ME.yaw),
    fz = -Math.cos(ME.yaw),
    rx = Math.cos(ME.yaw),
    rz = -Math.sin(ME.yaw);
  let mf = IN.f - IN.b,
    ms = IN.r - IN.l;
  if (touchMove.active) {
    mf = -touchMove.y;
    ms = touchMove.x;
  }
  const ml = Math.hypot(mf, ms);
  if (ml > 1) {
    mf /= ml;
    ms /= ml;
  }
  if (ME.dead) {
    mf = ms = 0;
  }
  const wantSprint =
    (SET.controls.sprintToggle ? IN.sprintT : IN.sprint) ||
    (touchMove.active && Math.hypot(touchMove.x, touchMove.y) > 0.92);
  if (!wantSprint || mf < 0.3) {
    IN.sprintT = false;
  }
  if (IN.crouch) {
    IN.crouchHT += dt;
    if (IN.crouchHT > 0.45 && ME.stance === 1 && !IN.proneLock) {
      ME.stance = 2;
      IN.proneLock = true;
    }
  }
  if (wantSprint && mf > 0.3 && ME.stance > 0) {
    ME.stance = 0;
  }
  if (ME.down || ME.dead) {
    ME.stance = 0;
  }
  ME.crouch = damp(ME.crouch, ME.stance === 1 ? 1 : 0, 10, dt);
  ME.prone = damp(ME.prone, ME.stance === 2 ? 1 : 0, 6, dt);
  ME.stanceBusy = Math.abs(ME.prone - (ME.stance === 2 ? 1 : 0)) > 0.25;
  ME.sprinting =
    wantSprint &&
    mf > 0.3 &&
    ME.adsK < 0.3 &&
    !W.reload &&
    !ME.down &&
    W.drinkT <= 0 &&
    !W.repairing &&
    ME.prone < 0.2 &&
    ME.crouch < 0.5;
  const aimWant =
    (SET.controls.aimToggle ? IN.aimT : IN.aim) &&
    !ME.sprinting &&
    W.switchT <= 0 &&
    W.drinkT <= 0 &&
    W.knifeT <= 0 &&
    !W.repairing;
  ME.adsK = damp(ME.adsK, aimWant ? 1 : 0, 14, dt);
  const def = GUNS[curW().id];
  let spd =
    (ME.sprinting ? 6.1 : 4.1) *
    (ME.perks.has('jet') ? 1.15 : 1) *
    (candyActive('pinwheel') ? 1.25 : 1) *
    def.move *
    (1 - ME.adsK * 0.45) *
    (1 - ME.crouch * 0.45) *
    (1 - ME.prone * 0.78);
  if (ME.down) {
    spd = 0.8;
  }
  const wx = (fx * mf + rx * ms) * spd,
    wz = (fz * mf + rz * ms) * spd;
  const acc = Math.min(1, dt * (ME.y > 0 ? 3 : 11));
  ME.vx = lerp(ME.vx, wx, acc);
  ME.vz = lerp(ME.vz, wz, acc);
  ME.x += ME.vx * dt;
  ME.z += ME.vz * dt;
  collideMe();
  if (IN.jump && ME.y <= 0 && !ME.down) {
    if (ME.stance > 0) {
      ME.stance--;
    } else {
      ME.vy = 4.5;
    }
  }
  IN.jump = false;
  const wasAir = ME.y > 0;
  ME.vy -= 14 * dt;
  ME.y = Math.max(0, ME.y + ME.vy * dt);
  if (ME.y === 0) {
    if (wasAir && ME.vy < -3) {
      AU.play('land', {
        g: 0.7,
      });
      VM.st.land = 1;
    }
    ME.vy = 0;
  }
  const sp = Math.hypot(ME.vx, ME.vz);
  ME.moveK = clamp(sp / 4.1, 0, 1.5) * (ME.y > 0 ? 0.2 : 1);
  if (ME.y === 0 && !ME.down) {
    ME.stepAcc += sp * dt;
    if (ME.stepAcc > (ME.sprinting ? 2.2 : ME.prone > 0.5 ? 0.7 : 1.8)) {
      ME.stepAcc = 0;
      if (ME.prone > 0.5) {
        AU.play('crawl', {
          g: 0.5,
          rr: 0.1,
        });
      } else {
        AU.play('step', {
          g: ME.crouch > 0.5 ? 0.25 : 0.55,
          rr: 0.08,
        });
      }
    }
  }
  if (!ME.down && G.time - ME.lastHurt > 4 && ME.hp < ME.maxHp) {
    ME.hp = Math.min(ME.maxHp, ME.hp + 120 * dt);
  }
  const hurtK = ME.down ? 1 : clamp(1 - ME.hp / ME.maxHp, 0, 1);
  POST.mat.uniforms.hurt.value = damp(POST.mat.uniforms.hurt.value, hurtK, 6, dt);
  POST.mat.uniforms.desat.value = damp(
    POST.mat.uniforms.desat.value,
    ME.down || ME.dead ? 0.8 : hurtK > 0.5 ? hurtK - 0.5 : 0,
    4,
    dt,
  );
  POST.mat.uniforms.blur.value = ME.down ? 1.5 : 0;
  if (hurtK > 0.5 && !ME.dead) {
    ME.heartT = (ME.heartT || 0) - dt;
    if (ME.heartT <= 0) {
      AU.play('heart', {
        g: 0.9,
      });
      ME.heartT = 0.9;
    }
  }
  if (ME.down) {
    if (ME.selfRevT > 0) {
      ME.selfRevT -= dt;
      if (ME.selfRevT <= 0) {
        getUp(null);
      }
    } else if (G.net !== 'solo') {
      ME.bleed -= dt;
      if (ME.bleed <= 0) {
        ME.down = false;
        ME.dead = true;
        showCenter('You bled out. Back next wave.', 3);
      }
    }
  }
  if (!ME.down && !ME.dead && ME.hp <= 0) {
    goDown();
  }
  ME.pitch = clamp(ME.pitch, -1.45, 1.45);
  W.spreadAdd = Math.max(0, W.spreadAdd - dt * 0.15);
  ME.shake = Math.max(0, (ME.shake || 0) - dt * 1.6);
  const sh = REDUCED ? 0 : ME.shake;
  const bob =
    ME.y === 0 && SET.video.bob ? Math.sin(VM.st.bob) * 0.03 * Math.min(1, sp / 4) * (1 - ME.adsK * 0.8) : 0;
  const eye = ME.dead ? 0.3 : ME.down ? 0.45 : lerp(lerp(1.62, 1.1, ME.crouch), 0.38, ME.prone);
  camera.position.set(ME.x + rand(-1, 1) * sh * 0.03, eye + ME.y + bob + rand(-1, 1) * sh * 0.03, ME.z);
  camera.rotation.y = ME.yaw;
  camera.rotation.x = ME.pitch + (ME.drinkLean || 0) * 0.32 + rand(-1, 1) * sh * 0.006;
  camera.rotation.z = ME.down ? 0.15 : 0;
  camera.fov = lerp(SET.video.fov, def.adsFov || SET.video.fov * 0.72, ME.adsK) + (ME.sprinting ? 5 : 0);
  camera.updateProjectionMatrix();
  AU.setListener(camera.position.x, camera.position.y, camera.position.z, ME.yaw, ME.pitch);
  $('#scope').hidden = !(def.scope && ME.adsK > 0.92);
}

function startReload() {
  const w = curW(),
    d = wdef(w);
  if (w.inPress) {
    return;
  }
  if (candyActive('licorice') && w.mag < d.mag && w.res > 0) {
    const t = Math.min(d.mag - w.mag, w.res);
    w.mag += t;
    w.res -= t;
    AU.play('magin');
    return;
  }
  if (
    W.reload ||
    W.switchT > 0 ||
    W.drinkT > 0 ||
    W.knifeT > 0 ||
    w.mag >= d.mag ||
    w.res <= 0 ||
    W.repairing
  ) {
    return;
  }
  const q = ME.perks.has('quick') ? 0.5 : 1;
  const empty = w.mag === 0;
  if (d.rtype === 'shell') {
    W.reload = {
      type: 'shell',
      stage: 'in',
      st: 0,
      sd: 0.3 * q,
      empty: empty,
      q: q,
      t: 0,
      dur: 1,
    };
  } else {
    const dur = d.reload * q * (empty && d.rtype === 'mag' ? 1.15 : 1);
    W.reload = {
      type: d.rtype,
      t: 0,
      dur: dur,
      empty: empty,
      sfx: 0,
    };
  }
}

function tickReload(dt) {
  const R = W.reload;
  if (!R) {
    return;
  }
  const w = curW(),
    d = wdef(w);
  if (R.type === 'shell') {
    R.st += dt;
    if (R.stage === 'in' && R.st >= R.sd) {
      R.stage = 'load';
      R.st = 0;
      R.sd = d.reload * R.q;
    } else if (R.stage === 'load' && R.st >= R.sd) {
      if (w.res > 0 && w.mag < d.mag) {
        w.mag++;
        w.res--;
        AU.play('shell', {
          rr: 0.05,
        });
      }
      R.st = 0;
      if (w.mag >= d.mag || w.res <= 0) {
        R.stage = 'out';
        R.sd = (R.empty ? 0.55 : 0.3) * R.q;
        if (R.empty) {
          setTimeout(() => AU.play('pump'), 60);
        }
      }
    } else if (R.stage === 'out' && R.st >= R.sd) {
      W.reload = null;
    }
    return;
  }
  R.t += dt;
  const k = R.t / R.dur;
  const cue = (at, fn) => {
    if (k >= at && !(R.sfx & (1 << Math.round(at * 20)))) {
      R.sfx |= 1 << Math.round(at * 20);
      fn();
    }
  };
  if (R.type === 'mag') {
    cue(0.2, () => AU.play('magout'));
    cue(0.58, () => AU.play('magin'));
    if (R.empty) {
      cue(0.7, () => {
        if (d.cycle === 'slide') {
          AU.play('slidefwd');
        } else {
          AU.play('boltback');
          setTimeout(() => AU.play('boltfwd'), 90);
        }
      });
    }
  }
  if (R.type === 'clip') {
    cue(0.1, () => AU.play('boltback'));
    cue(0.45, () => AU.play('clipin'));
    cue(0.82, () => AU.play('boltfwd'));
  }
  if (k >= (R.type === 'mag' ? 0.62 : 0.6) && !R.filled) {
    R.filled = true;
    const take = Math.min(d.mag - w.mag, w.res);
    w.mag += take;
    w.res -= take;
  }
  if (R.t >= R.dur) {
    W.reload = null;
  }
}

const _ray = new THREE.Raycaster();

const _v1 = new THREE.Vector3(),
  _v2 = new THREE.Vector3(),
  _v3 = new THREE.Vector3();

function zombieHitList() {
  const out = [];
  for (const z of ZBS) {
    if (!z.dead) {
      for (const m of z.rig.hits) {
        out.push(m);
      }
    }
  }
  return out;
}

function fire() {
  const w = curW(),
    d = wdef(w);
  if (w.inPress) {
    return;
  }
  if (W.reload && W.reload.type === 'shell' && w.mag > 0) {
    W.reload.stage = 'out';
    W.reload.st = 0;
    W.reload.sd = 0.15;
    return;
  }
  if (w.mag <= 0) {
    if (!W.fired) {
      AU.play('dry');
    }
    if (w.res > 0) {
      startReload();
    }
    return;
  }
  w.mag--;
  ME.shots++;
  W.cool = 60 / d.rpm / (ME.perks.has('rapid') ? 1.35 : 1);
  if (d.cycle === 'bolt' || d.cycle === 'pump') {
    W.cycleDur = (d.cycleDur || 0.7) / (ME.perks.has('rapid') ? 1.2 : 1);
    W.cycleT = W.cycleDur;
    W.cool = Math.max(W.cool, W.cycleDur);
    if (w.mag > 0) {
      if (d.cycle === 'bolt') {
        setTimeout(() => AU.play('boltback'), 150);
        setTimeout(() => AU.play('boltfwd'), 420);
      } else {
        setTimeout(() => AU.play('pump'), 120);
      }
    }
  }
  if (d.cycle === 'slide') {
    W.cycleDur = 0.09;
    W.cycleT = 0.09;
  }
  if (d.blast || d.arc) {
  } else if (!d.proj) {
    if (d.cycle === 'bolt') {
      setTimeout(() => ejectCasing(d), 330);
    } else if (d.cycle === 'pump') {
      setTimeout(() => ejectCasing(d), 200);
    } else {
      ejectCasing(d);
    }
  }
  AU.play('gun_' + d.snd, {
    g: 1,
    rr: 0.04,
    wet: 0.45,
  });
  if (d.papd) {
    AU.play('pap_layer', {
      g: 0.5,
      rr: 0.06,
    });
  }
  W.flashT = 0.05;
  VM.st.kick = Math.min(1.6, VM.st.kick + 1);
  VM.st.roll = rand(-0.04, 0.04);
  muzzleLight.intensity = 3;
  setTimeout(() => (muzzleLight.intensity = 0), 45);
  if (Math.random() < 0.5) {
    camera.updateMatrixWorld();
    const mp = new THREE.Vector3(0.08 * (1 - ME.adsK), -0.06, -0.9).applyMatrix4(camera.matrixWorld);
    spawnFX(mp.x, mp.y, mp.z, 1, 'wisp');
  }
  const rec = d.recoil * (1 - ME.adsK * 0.45) * (1 - ME.crouch * 0.3) * (1 - ME.prone * 0.5);
  ME.pitch += rec;
  ME.yaw += rand(-1, 1) * rec * 0.35;
  ME.shake = Math.max(ME.shake || 0, rec * 1.5);
  const moving = Math.hypot(ME.vx, ME.vz) > 1;
  const sp =
    d.spread *
      lerp(1, d.pellets ? 0.7 : 0.22, ME.adsK) *
      (moving ? 1.5 : 1) *
      (ME.y > 0.05 ? 2 : 1) *
      (1 - ME.crouch * 0.25) *
      (1 - ME.prone * 0.5) +
    W.spreadAdd;
  W.spreadAdd = Math.min(0.05, W.spreadAdd + d.spread * 0.3);
  camera.updateMatrixWorld();
  camera.getWorldDirection(_v1);
  _v2.set(1, 0, 0).applyQuaternion(camera.quaternion);
  _v3.set(0, 1, 0).applyQuaternion(camera.quaternion);
  const hits = zombieHitList();
  if (d.blast) {
    galeBlast(d);
    if (w.mag === 0 && w.res > 0) {
      W.autoReloadT = 0.5;
    }
    return;
  }
  if (d.arc) {
    voltArc(_v1.clone(), d);
    if (w.mag === 0 && w.res > 0) {
      W.autoReloadT = 0.5;
    }
    return;
  }
  for (let i = 0; i < (d.pellets || 1); i++) {
    const a = rand(0, TAU),
      r = Math.sqrt(Math.random()) * sp;
    const dir = _v1
      .clone()
      .addScaledVector(_v2, Math.cos(a) * r)
      .addScaledVector(_v3, Math.sin(a) * r)
      .normalize();
    if (d.proj) {
      spawnBolt(dir, d);
    } else {
      shootRay(dir, d, hits);
    }
  }
  if (w.mag === 0 && w.res > 0) {
    W.autoReloadT = 0.35;
  }
}

function shootRay(dir, d, hitMeshes) {
  const o = camera.position;
  const wh = rayWorld([o.x, o.y, o.z], [dir.x, dir.y, dir.z], 120);
  const maxT = wh ? wh.t : 120;
  _ray.set(o, dir);
  _ray.far = maxT;
  const hs = _ray.intersectObjects(hitMeshes, false);
  const done = new Set();
  let pen = d.pen || 1;
  for (const h of hs) {
    const z = h.object.userData.z;
    if (!z || done.has(z) || z.dead) {
      continue;
    }
    done.add(z);
    const part = h.object.userData.part;
    let dmg = d.dmg * (part === 'head' ? d.head : part === 'limb' ? 0.75 : 1);
    if (d.pellets) {
      dmg *= clamp(1.5 - h.distance / 10, 0.3, 1);
    }
    if (done.size > 1) {
      dmg *= 0.6;
    }
    hitZombieLocal(z, dmg, part, h.point, 'gun');
    if (--pen <= 0) {
      return;
    }
  }
  if (wh) {
    const p = o.clone().addScaledVector(dir, wh.t);
    const surf = wh.s.surf;
    spawnFX(
      p.x,
      p.y,
      p.z,
      surf === 'metal' ? 6 : 3,
      surf === 'metal' ? 'spark' : surf === 'wood' ? 'splinter' : 'dust',
    );
    if (surf === 'flesh') {
      spawnFX(p.x, p.y, p.z, 5, 'blood');
    } else {
      bulletHole(p, wh.n);
    }
    if (Math.random() < 0.5) {
      AU.play(surf === 'metal' ? 'metal' : surf === 'wood' ? 'wood' : 'conc', {
        pos: [p.x, p.y, p.z],
        g: 0.5,
      });
    }
  }
}

function hitZombieLocal(z, dmg, part, point, src) {
  z.flinch = Math.min(1.2, z.flinch + (src === 'exp' ? 0.8 : 0.45));
  if (part === 'head') {
    z.hflinch = 1;
  }
  if (point) {
    spawnFX(point.x, point.y, point.z, part === 'head' ? 8 : 5, 'blood');
    spawnFX(point.x, point.y, point.z, 1, 'mist');
  }
  if (src !== 'exp' && src !== 'gale' && src !== 'volt') {
    addPoints(10);
    hitmark(false);
    AU.play(part === 'head' ? 'headshot' : 'flesh', {
      g: 0.6,
      rr: 0.1,
    });
  }
  sendEvent(['hit', z.id, Math.round(dmg), part, src]);
}

function doKnife() {
  if (W.knifeT > 0 || W.switchT > 0 || W.drinkT > 0 || ME.dead) {
    return;
  }
  W.knifeT = W.knifeDur;
  W.reload = null;
  AU.play('whoosh');
  setTimeout(() => {
    if (G.mode !== 'play') {
      return;
    }
    let best = null,
      bd = 2;
    const fx = -Math.sin(ME.yaw),
      fz = -Math.cos(ME.yaw);
    for (const z of ZBS) {
      if (z.dead) {
        continue;
      }
      const dx = z.x - ME.x,
        dz = z.z - ME.z,
        d = Math.hypot(dx, dz);
      if (d < bd && (dx * fx + dz * fz) / (d || 1) > 0.45) {
        bd = d;
        best = z;
      }
    }
    if (best) {
      AU.play('knifehit');
      hitZombieLocal(best, 150 + G.round * 8, 'body', new THREE.Vector3(best.x, 1.3, best.z), 'knife');
      if (bd > 1.1) {
        ME.x += (best.x - ME.x) * 0.25;
        ME.z += (best.z - ME.z) * 0.25;
      }
    }
  }, 150);
}

const nades = [];

function throwNade() {
  if (ME.nades <= 0 || W.nadeT > 0 || W.drinkT > 0 || ME.down || ME.dead) {
    return;
  }
  ME.nades--;
  W.nadeT = W.nadeDur;
  W.reload = null;
  AU.play('pin');
  setTimeout(() => {
    if (G.mode !== 'play') {
      return;
    }
    AU.play('whoosh', {
      g: 0.6,
    });
    camera.getWorldDirection(_v1);
    const m = buildGrenade();
    m.scale.setScalar(1.3);
    m.position.copy(camera.position).addScaledVector(_v1, 0.5);
    scene.add(m);
    nades.push({
      m: m,
      vx: _v1.x * 13 + ME.vx * 0.5,
      vy: _v1.y * 13 + 3,
      vz: _v1.z * 13 + ME.vz * 0.5,
      t: 0.35,
    });
  }, 330);
}

function updateNades(dt) {
  for (let i = nades.length - 1; i >= 0; i--) {
    const n = nades[i];
    n.t += dt;
    n.vy -= 16 * dt;
    const p = n.m.position;
    const nx = p.x + n.vx * dt,
      nz = p.z + n.vz * dt;
    let ny = p.y + n.vy * dt;
    let hx = false,
      hz = false;
    for (const c of WORLD.colliders) {
      if (!c.on) {
        continue;
      }
      if (nx > c.minX && nx < c.maxX && p.z > c.minZ && p.z < c.maxZ) {
        hx = true;
      }
      if (p.x > c.minX && p.x < c.maxX && nz > c.minZ && nz < c.maxZ) {
        hz = true;
      }
    }
    if (hx) {
      n.vx *= -0.45;
      AU.play('clink', {
        pos: [p.x, p.y, p.z],
      });
    } else {
      p.x = nx;
    }
    if (hz) {
      n.vz *= -0.45;
      AU.play('clink', {
        pos: [p.x, p.y, p.z],
      });
    } else {
      p.z = nz;
    }
    if (ny < 0.06) {
      ny = 0.06;
      if (n.vy < -2) {
        AU.play('clink', {
          pos: [p.x, p.y, p.z],
        });
      }
      n.vy *= -0.35;
      n.vx *= 0.65;
      n.vz *= 0.65;
    }
    p.y = ny;
    n.m.rotation.x += dt * 8;
    if (n.t > 2.1) {
      scene.remove(n.m);
      nades.splice(i, 1);
      explode(p.x, p.y, p.z, 5, 350 + G.round * 110, true);
    }
  }
}

function explodeFX(x, y, z) {
  AU.play('boom', {
    pos: [x, y, z],
    wet: 0.6,
    ref: 4,
  });
  spawnFX(x, y + 0.2, z, 26, 'fire');
  spawnFX(x, y + 0.4, z, 16, 'smoke');
  spawnFX(x, y + 0.2, z, 12, 'spark');
  boomLight.position.set(x, y + 0.6, z);
  boomLight.intensity = 6;
  const d = Math.hypot(ME.x - x, ME.z - z);
  ME.shake = Math.max(ME.shake || 0, clamp(0.8 - d * 0.06, 0, 0.8));
}

function explode(x, y, z, r, dmg, hurtsMe, quiet) {
  explodeFX(x, y, z);
  if (G.net !== 'solo') {
    sendEvent(['gx', x, y, z]);
  }
  for (const zb of ZBS) {
    if (zb.dead) {
      continue;
    }
    const d = Math.hypot(zb.x - x, zb.z - z, zb.y + 1 - y);
    if (d < r) {
      hitZombieLocal(zb, dmg * (1 - (d / r) * 0.55), 'body', null, 'exp');
    }
  }
  const pd = Math.hypot(ME.x - x, ME.z - z);
  if (hurtsMe && pd < 3.2) {
    damageMe(80 * (1 - pd / 3.2), x, z);
  }
}

const casings = [];

let casingGeo = {},
  hullMat;

function ejectCasing(d) {
  if (G.mode !== 'play') {
    return;
  }
  const shot = !!d.pellets,
    rifle = d.snd === 'rifle' || d.snd === 'semi' || d.snd === 'ar' || d.snd === 'lmg';
  const key = shot ? 's' : rifle ? 'r' : 'p';
  if (!casingGeo[key]) {
    casingGeo[key] = shot
      ? new THREE.CylinderGeometry(0.0095, 0.0095, 0.065, 10)
      : new THREE.CylinderGeometry(rifle ? 0.0055 : 0.0058, rifle ? 0.006 : 0.0058, rifle ? 0.058 : 0.022, 8);
  }
  if (!hullMat) {
    hullMat = std({
      color: 9050644,
      roughness: 0.5,
    });
  }
  let c = casings.length > 40 ? casings.shift() : null;
  if (c) {
    scene.remove(c.m);
  }
  const m = new THREE.Mesh(casingGeo[key], shot ? hullMat : MAT.gBrass);
  camera.updateMatrixWorld();
  _v1.set(0.13, -0.09, -0.32).applyMatrix4(camera.matrixWorld);
  m.position.copy(_v1);
  scene.add(m);
  _v2.set(1, 0, 0).applyQuaternion(camera.quaternion);
  _v3.set(0, 1, 0).applyQuaternion(camera.quaternion);
  c = {
    m: m,
    vx: _v2.x * rand(1.6, 2.6) + _v3.x * rand(1, 2) + ME.vx,
    vy: _v2.y * 2 + _v3.y * rand(1.2, 2.2),
    vz: _v2.z * rand(1.6, 2.6) + _v3.z * rand(1, 2) + ME.vz,
    sx: rand(-20, 20),
    sz: rand(-20, 20),
    t: 0,
    b: 0,
    shot: shot,
  };
  casings.push(c);
}

function updateCasings(dt) {
  for (let i = casings.length - 1; i >= 0; i--) {
    const c = casings[i];
    c.t += dt;
    const p = c.m.position;
    if (c.b < 3) {
      c.vy -= 11 * dt;
      p.x += c.vx * dt;
      p.y += c.vy * dt;
      p.z += c.vz * dt;
      c.m.rotation.x += c.sx * dt;
      c.m.rotation.z += c.sz * dt;
      if (p.y < 0.008) {
        p.y = 0.008;
        c.b++;
        if (c.b <= 2) {
          AU.play(c.shot ? 'hull' : 'casing', {
            pos: [p.x, p.y, p.z],
            g: 0.5 / c.b,
            rr: 0.15,
          });
        }
        c.vy = -c.vy * 0.35;
        c.vx *= 0.5;
        c.vz *= 0.5;
        c.sx *= 0.4;
        c.sz *= 0.4;
        if (c.b >= 3) {
          c.m.rotation.x = Math.PI / 2;
        }
      }
    }
    if (c.t > 8) {
      scene.remove(c.m);
      casings.splice(i, 1);
    }
  }
}

const PRESS = {
  state: 'idle',
  t: 0,
  slot: null,
  id: null,
  sfx: 0,
};

const PRESS_COST = 5e3;

function pressLabel() {
  const P = PRESS,
    w = curW();
  if (!G.power) {
    return 'The overhaul press needs power';
  }
  if (P.state === 'ready') {
    return `Press ${K('use')} to take the ${escapeHTML(
      wdef(
        Object.assign({}, P.slot, {
          pap: true,
        }),
      ).name,
    )}`;
  }
  if (P.state !== 'idle') {
    return '';
  }
  if (w.pap) {
    return 'This weapon has already been overhauled';
  }
  return `Press ${K('use')} to overhaul the ${escapeHTML(wdef(w).name)} <span class="c">${PRESS_COST}</span>`;
}

function pressUse() {
  const P = PRESS;
  if (!G.power) {
    AU.play('denied');
    return;
  }
  if (P.state === 'idle') {
    const w = curW();
    if (!w || w.pap || w.inPress || W.drinkT > 0) {
      return;
    }
    if (!spend(PRESS_COST)) {
      return;
    }
    w.inPress = true;
    W.reload = null;
    P.state = 'working';
    P.t = 0;
    P.slot = w;
    P.id = w.id;
    P.sfx = 0;
    pressDisplay(null);
    const other = ME.weapons.findIndex((x) => x !== w);
    if (other >= 0) {
      ME.cur = other;
      W.switchT = W.switchDur = 0.5;
      VM.set(curW().id, curW().pap);
    }
    AU.play('press_start', {
      pos: [WORLD.press.x, 1.2, WORLD.press.z],
    });
  } else if (P.state === 'ready') {
    const w = P.slot;
    w.inPress = false;
    w.pap = true;
    const d = wdef(w);
    w.mag = d.mag;
    w.res = d.res;
    ME.cur = ME.weapons.indexOf(w);
    W.reload = null;
    W.switchT = W.switchDur = 0.5;
    VM.set(w.id, true);
    AU.play('raise');
    P.state = 'idle';
    P.slot = null;
    pressDisplay(null);
  }
}

function updatePress(dt) {
  const P = PRESS;
  P.t += dt;
  const M = WORLD.press;
  if (!M) {
    return;
  }
  if (P.state === 'working') {
    const beat = Math.floor(P.t / 0.8);
    const ph = (P.t % 0.8) / 0.8;
    M.platen.position.y = M.platenY - Math.max(0, Math.sin(ph * Math.PI)) * 0.42;
    if (beat > P.sfx) {
      P.sfx = beat;
      AU.play('press_stamp', {
        pos: [M.x, 1.2, M.z],
        rr: 0.05,
      });
      spawnFX(M.x, 1.05, M.z, 8, 'spark');
      spawnFX(M.x, 1.6, M.z, 3, 'steam');
    }
    M.lamp.material.color.setHSL(0.02, 1, 0.35 + Math.abs(Math.sin(P.t * 8)) * 0.3);
    M.beacon.rotation.y += dt * 8;
    if (P.t >= 4) {
      P.state = 'ready';
      P.t = 0;
      M.platen.position.y = M.platenY;
      pressDisplay(P.id);
      AU.play('press_done', {
        pos: [M.x, 1.2, M.z],
      });
    }
  } else if (P.state === 'ready') {
    M.beacon.rotation.y += dt * 3;
    if (M.disp) {
      M.disp.rotation.y = Math.sin(P.t) * 0.3 + Math.PI / 2;
    }
    if (P.t > 12) {
      const i = ME.weapons.indexOf(P.slot);
      if (i >= 0) {
        ME.weapons.splice(i, 1);
      }
      if (!ME.weapons.length) {
        ME.weapons.push({
          id: 'warden',
          mag: 8,
          res: 64,
        });
      }
      ME.cur = Math.min(ME.cur, ME.weapons.length - 1);
      VM.set(curW().id, curW().pap);
      P.state = 'idle';
      P.slot = null;
      pressDisplay(null);
      showCenter('The press kept your weapon', 2.2);
    }
  } else if (M) {
    M.lamp.material.color.set(G.power ? 3398997 : 3349012);
  }
}

function pressDisplay(id) {
  const M = WORLD.press;
  if (M.disp) {
    M.grp.remove(M.disp);
    M.disp = null;
  }
  if (!id) {
    return;
  }
  const r = GUNS[id].build();
  r.g.traverse((m) => {
    if (m.isMesh) {
      const m0 = m.material;
      if (m0 === MAT.gBlue || m0 === MAT.gPark || m0 === MAT.gSteel) {
        m.material = MAT.papMetal;
      } else if (m0 === MAT.gWood || m0 === MAT.gBake || m0 === MAT.gGrip) {
        m.material = MAT.papWood;
      }
    }
  });
  r.g.scale.setScalar(1.3);
  r.g.position.set(0, 1.12, 0.2);
  r.g.rotation.y = Math.PI / 2;
  M.grp.add(r.g);
  M.disp = r.g;
}

const CANDIES = {
  cherry: {
    name: 'Cherry Bomb',
    desc: 'Your next 5 kills explode',
    color: '#c0202a',
    n: 5,
  },
  ghost: {
    name: 'Ghost Mint',
    desc: 'Zombies ignore you for 12 seconds',
    color: '#bfe8d8',
    dur: 12,
  },
  iron: {
    name: 'Iron Jawbreaker',
    desc: 'No damage for 15 seconds',
    color: '#8a9098',
    dur: 15,
  },
  licorice: {
    name: 'Quick Licorice',
    desc: 'Instant reloads for 30 seconds',
    color: '#3a1a22',
    dur: 30,
  },
  penny: {
    name: 'Lucky Penny',
    desc: '1000 points, right now',
    color: '#b8732c',
  },
  barrel: {
    name: 'Root Beer Barrel',
    desc: 'A power-up drops at your feet',
    color: '#7a4020',
  },
  lemon: {
    name: 'Lemon Drop',
    desc: 'Fills all your ammo',
    color: '#e8d040',
  },
  pinwheel: {
    name: 'Peppermint Pinwheel',
    desc: 'Move 25% faster for a minute',
    color: '#e84050',
    dur: 60,
  },
};

const CANDY_ICONS = {};

function candyIcon(id) {
  if (CANDY_ICONS[id]) {
    return CANDY_ICONS[id];
  }
  const c0 = CANDIES[id];
  const [c, g] = mkC(96, 96);
  g.fillStyle = c0.color;
  [[-1], [1]].forEach(([sx]) => {
    g.beginPath();
    g.moveTo(48 + sx * 24, 48);
    g.lineTo(48 + sx * 46, 32);
    g.lineTo(48 + sx * 42, 48);
    g.lineTo(48 + sx * 46, 64);
    g.closePath();
    g.globalAlpha = 0.75;
    g.fill();
  });
  g.globalAlpha = 1;
  const gr = g.createRadialGradient(40, 40, 3, 48, 48, 26);
  gr.addColorStop(0, '#fff');
  gr.addColorStop(0.3, c0.color);
  gr.addColorStop(1, '#111');
  g.fillStyle = gr;
  g.beginPath();
  g.arc(48, 48, 25, 0, TAU);
  g.fill();
  g.strokeStyle = 'rgba(255,255,255,.55)';
  g.lineWidth = 3;
  for (let i = 0; i < 3; i++) {
    g.beginPath();
    g.arc(48, 48, 8 + i * 6, i, i + 2);
    g.stroke();
  }
  return (CANDY_ICONS[id] = c.toDataURL());
}

function candyActive(id) {
  const c = ME.candy;
  return !!(c && c.id === id && ((c.t || 0) > 0 || (c.n || 0) > 0));
}

function candyCost() {
  return 500 * (1 + (G.candyUses || 0));
}

function candyLabel() {
  if (G.candyBusy) {
    return '';
  }
  if ((G.candyUses || 0) >= 3) {
    return 'The candy machine is empty until next wave';
  }
  return `Press ${K('use')} for a penny candy <span class="c">${candyCost()}</span>`;
}

function candyUse() {
  if (G.candyBusy || (G.candyUses || 0) >= 3) {
    return;
  }
  if (!spend(candyCost())) {
    return;
  }
  G.candyUses = (G.candyUses || 0) + 1;
  G.candyBusy = true;
  const M = WORLD.candy;
  AU.play('candy_crank', {
    pos: [M.x, 1, M.z],
  });
  M.spin = 1.2;
  setTimeout(() => {
    G.candyBusy = false;
    if (G.mode !== 'play') {
      return;
    }
    const id = pick(Object.keys(CANDIES));
    const c0 = CANDIES[id];
    AU.play('candy_get');
    ME.candy = {
      id: id,
      t: c0.dur || 0,
      n: c0.n || 0,
      max: c0.dur || c0.n || 1,
    };
    if (id === 'penny') {
      addPoints(1e3);
      ME.candy.t = 2;
      ME.candy.max = 2;
    }
    if (id === 'lemon') {
      ME.weapons.forEach((w) => {
        const d = wdef(w);
        w.mag = d.mag;
        w.res = d.res;
      });
      ME.nades = 4;
      ME.candy.t = 2;
      ME.candy.max = 2;
    }
    if (id === 'barrel') {
      const fx = -Math.sin(ME.yaw),
        fz = -Math.cos(ME.yaw);
      sendEvent(['candypu', ME.x + fx * 1.6, ME.z + fz * 1.6]);
      ME.candy.t = 2;
      ME.candy.max = 2;
    }
    showCenter(c0.name, 2);
    renderCandy(true);
  }, 1300);
}

function updateCandy(dt) {
  const M = WORLD.candy;
  if (M) {
    if (M.spin > 0) {
      M.spin -= dt;
      M.crank.rotation.z += dt * 9;
      M.globe.rotation.y += dt * 3;
    }
  }
  const c = ME.candy;
  if (!c) {
    return;
  }
  if (c.t > 0) {
    c.t -= dt;
    if (c.t <= 0 && !(c.n > 0)) {
      ME.candy = null;
      renderCandy();
      return;
    }
  }
  const bar = $('#candyBar');
  if (bar) {
    bar.style.width = clamp(c.n > 0 ? c.n / c.max : c.t / c.max, 0, 1) * 100 + '%';
  }
}

function renderCandy(fresh) {
  const el = $('#candy');
  const c = ME.candy;
  if (!c) {
    el.hidden = true;
    return;
  }
  const c0 = CANDIES[c.id];
  el.hidden = false;
  el.className = fresh ? 'fresh' : '';
  el.innerHTML = `<img alt="" src="${candyIcon(c.id)}"><div><b>${escapeHTML(c0.name)}</b><small>${escapeHTML(c0.desc)}</small><span class="cbar"><i id="candyBar"></i></span></div>`;
}

function sodaThemes(dt) {
  if (!G.power) {
    return;
  }
  for (const s of WORLD.sodas) {
    s.tt = (s.tt == null ? rand(25, 70) : s.tt) - dt;
    if (s.tt <= 0) {
      s.tt = rand(90, 170);
      if (Math.hypot(s.x - ME.x, s.z - ME.z) < 26) {
        AU.play('theme_' + s.id, {
          pos: [s.x, 1.6, s.z],
          ref: 3,
          roll: 1.2,
          bus: 'mus',
          g: 1.1,
        });
      }
    }
  }
}

function losTo(x, y, z) {
  const o = camera.position;
  const d = [x - o.x, y - o.y, z - o.z];
  const L = Math.hypot(...d);
  const h = rayWorld(
    [o.x, o.y, o.z],
    d.map((v) => v / L),
    L,
  );
  return !h;
}

let ringTex = null;

function galeBlast(d) {
  camera.getWorldDirection(_v1);
  const fx = _v1.x,
    fz = _v1.z,
    fl = Math.hypot(fx, fz) || 1,
    cc = Math.cos(d.blast.cone);
  for (const z of ZBS) {
    if (z.dead) {
      continue;
    }
    const dx = z.x - ME.x,
      dz = z.z - ME.z,
      dist = Math.hypot(dx, dz);
    if (dist > d.blast.range || dist < 0.01) {
      continue;
    }
    if ((dx * fx + dz * fz) / (dist * fl) < cc && dist > 1.2) {
      continue;
    }
    if (!losTo(z.x, 1.2, z.z)) {
      continue;
    }
    z.flyDir = [dx / dist, dz / dist];
    hitZombieLocal(z, 1e7, 'body', null, 'gale');
  }
  if (!ringTex) {
    ringTex = textCanvas(128, 128, (g) => {
      g.strokeStyle = 'rgba(255,255,255,.9)';
      g.lineWidth = 10;
      g.beginPath();
      g.arc(64, 64, 52, 0, TAU);
      g.stroke();
    });
  }
  for (let i = 0; i < 4; i++) {
    const s = new THREE.Sprite(
      new THREE.SpriteMaterial({
        map: ringTex,
        transparent: true,
        opacity: 0.35,
        depthWrite: false,
        color: 14214380,
      }),
    );
    s.position.copy(camera.position).addScaledVector(_v1, 1 + i * 1.6);
    s.scale.set(0.5, 0.5, 1);
    scene.add(s);
    const t0 = performance.now();
    const grow = () => {
      const k = (performance.now() - t0) / 450;
      if (k >= 1) {
        scene.remove(s);
        return;
      }
      s.scale.setScalar(0.5 + k * (2 + i));
      s.material.opacity = 0.35 * (1 - k);
      requestAnimationFrame(grow);
    };
    setTimeout(grow, i * 45);
  }
  for (let i = 0; i < 20; i++) {
    const p = camera.position.clone().addScaledVector(_v1, rand(1, d.blast.range));
    spawnFX(p.x + rand(-1, 1), rand(0.1, 1.8), p.z + rand(-1, 1), 1, 'dust');
  }
  ME.shake = Math.max(ME.shake || 0, 0.5);
}

const arcs = [];

function jagged(a, b, n = 10, amp = 0.35) {
  const pts = [a.clone()];
  for (let i = 1; i < n; i++) {
    const t = i / n;
    pts.push(
      a
        .clone()
        .lerp(b, t)
        .add(new THREE.Vector3(rand(-amp, amp), rand(-amp, amp), rand(-amp, amp))),
    );
  }
  pts.push(b.clone());
  return pts;
}

function drawArc(a, b) {
  const g = new THREE.BufferGeometry().setFromPoints(jagged(a, b));
  const l = new THREE.Line(
    g,
    new THREE.LineBasicMaterial({
      color: 12577023,
      transparent: true,
      opacity: 1,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    }),
  );
  scene.add(l);
  arcs.push({
    l: l,
    a: a.clone(),
    b: b.clone(),
    t: 0,
  });
}

function updateArcs(dt) {
  for (let i = arcs.length - 1; i >= 0; i--) {
    const A = arcs[i];
    A.t += dt;
    if (A.t > 0.35) {
      scene.remove(A.l);
      A.l.geometry.dispose();
      arcs.splice(i, 1);
      continue;
    }
    if (Math.random() < 0.5) {
      A.l.geometry.setFromPoints(jagged(A.a, A.b));
    }
    A.l.material.opacity = 1 - A.t / 0.35;
  }
}

function voltArc(dir, d) {
  const o = camera.position;
  let first = null,
    bd = 1e9;
  for (const z of ZBS) {
    if (z.dead) {
      continue;
    }
    const c = new THREE.Vector3(z.x, 1.3, z.z);
    const t = c.clone().sub(o).dot(dir);
    if (t < 0 || t > 30) {
      continue;
    }
    const off = c.clone().sub(o.clone().addScaledVector(dir, t)).length();
    if (off < 1.2 + t * 0.03 && t < bd && losTo(c.x, c.y, c.z)) {
      bd = t;
      first = z;
    }
  }
  const tip = new THREE.Vector3(0.1, -0.08, -0.7).applyMatrix4(camera.matrixWorld);
  if (!first) {
    drawArc(tip, o.clone().addScaledVector(dir, 12));
    return;
  }
  let cur = first,
    from = tip;
  const hit = new Set();
  for (let h = 0; h < d.arc.hops && cur; h++) {
    hit.add(cur);
    const to = new THREE.Vector3(cur.x, 1.3, cur.z);
    drawArc(from, to);
    spawnFX(to.x, to.y, to.z, 6, 'arc');
    AU.play('zap', {
      pos: [to.x, to.y, to.z],
      rr: 0.15,
      g: 0.7,
    });
    hitZombieLocal(cur, 1e7, 'body', null, 'volt');
    from = to;
    let nx = null,
      nd = d.arc.reach;
    for (const z of ZBS) {
      if (z.dead || hit.has(z)) {
        continue;
      }
      const dd = Math.hypot(z.x - cur.x, z.z - cur.z);
      if (dd < nd) {
        nd = dd;
        nx = z;
      }
    }
    cur = nx;
  }
  boomLight.color.setHex(10475775);
  boomLight.position.copy(o).addScaledVector(dir, 3);
  boomLight.intensity = 5;
  setTimeout(() => boomLight.color.setHex(16747056), 200);
}

const bolts = [];

function spawnBolt(dir, d) {
  const orb = d.proj === 'orb';
  const s = glowSprite(orb ? (d.papd ? 16736448 : 10510591) : 16742954, orb ? 0.42 : 0.55, 1, false);
  s.position.copy(camera.position).addScaledVector(dir, 0.6);
  scene.add(s);
  bolts.push({
    s: s,
    dir: dir.clone(),
    t: 0,
    d: d,
    speed: orb ? 58 : 40,
    orb: orb,
  });
}

function updateBolts(dt) {
  const hm = zombieHitList();
  for (let i = bolts.length - 1; i >= 0; i--) {
    const b = bolts[i];
    b.t += dt;
    const p = b.s.position;
    const step = b.speed * dt;
    const wh = rayWorld([p.x, p.y, p.z], [b.dir.x, b.dir.y, b.dir.z], step);
    _ray.set(p, b.dir);
    _ray.far = wh ? wh.t : step;
    const zh = _ray.intersectObjects(hm, false);
    let at = null;
    if (zh.length) {
      at = zh[0].point;
      const z = zh[0].object.userData.z;
      if (z) {
        hitZombieLocal(z, b.d.dmg, zh[0].object.userData.part, at, 'gun');
      }
    } else if (wh) {
      at = p.clone().addScaledVector(b.dir, wh.t);
    } else {
      p.addScaledVector(b.dir, step);
      if (p.y < 0 || b.t > 2) {
        at = p.clone();
      }
    }
    projLight.position.copy(p);
    projLight.color.setHex(b.orb ? 10510591 : 16742954);
    projLight.intensity = 2;
    if (Math.random() < 0.7) {
      spawnFX(p.x, p.y, p.z, 1, b.orb ? 'violet' : 'ember');
    }
    if (at) {
      spawnFX(at.x, at.y, at.z, 18, b.orb ? 'violet' : 'fire');
      AU.play(b.orb ? 'orb_hit' : 'boom', {
        pos: [at.x, at.y, at.z],
        g: 0.6,
        rate: b.orb ? 1 : 1.5,
      });
      for (const z of ZBS) {
        if (z.dead) {
          continue;
        }
        const d = Math.hypot(z.x - at.x, z.z - at.z);
        if (d < b.d.radius && !(zh.length && zh[0].object.userData.z === z)) {
          hitZombieLocal(z, b.d.splash * (1 - (d / b.d.radius) * 0.5), 'body', null, 'exp');
        }
      }
      scene.remove(b.s);
      bolts.splice(i, 1);
      if (!bolts.length) {
        projLight.intensity = 0;
      }
    }
  }
}

function updateWeapon(dt) {
  W.cool -= dt;
  W.cycleT = Math.max(0, W.cycleT - dt);
  if (W.switchT > 0) {
    W.switchT = Math.max(0, W.switchT - dt);
  }
  if (W.knifeT > 0) {
    W.knifeT -= dt;
  }
  if (W.nadeT > 0) {
    W.nadeT -= dt;
  }
  if (W.drinkT > 0) {
    W.drinkT -= dt;
    if (W.drinkT <= 0) {
      finishDrink(W.drinkId);
    }
  }
  if (W.autoReloadT > 0) {
    W.autoReloadT -= dt;
    if (W.autoReloadT <= 0) {
      startReload();
    }
  }
  tickReload(dt);
  const d = wdef(curW());
  const can =
    !curW().inPress &&
    !ME.sprinting &&
    W.switchT <= 0 &&
    W.knifeT <= 0 &&
    W.nadeT <= 0 &&
    W.drinkT <= 0 &&
    !W.repairing &&
    !ME.dead &&
    !ME.stanceBusy &&
    W.cool <= 0 &&
    !(W.reload && W.reload.type !== 'shell');
  if (IN.fire && can) {
    if (d.auto || !W.fired) {
      fire();
      W.fired = true;
    }
  }
  if (!IN.fire) {
    W.fired = false;
  }
}

let focus = null;

function updateInteract(dt) {
  focus = null;
  let best = 1e9;
  const fx = -Math.sin(ME.yaw),
    fz = -Math.cos(ME.yaw);
  const pt = $('#promptText');
  let txt = '',
    prog = -1;
  if (!ME.down && !ME.dead) {
    for (const it of WORLD.inter) {
      if (it.enabled && !it.enabled()) {
        continue;
      }
      const dx = it.x - ME.x,
        dz = it.z - ME.z,
        d = Math.hypot(dx, dz);
      if (d > it.r) {
        continue;
      }
      const dot = (dx * fx + dz * fz) / (d || 1);
      if (d > 0.8 && dot < 0.25) {
        continue;
      }
      if (d < best) {
        best = d;
        focus = it;
      }
    }
    let reviveT = null;
    for (const rp of NET.remotes()) {
      if (rp.down && !rp.dead && Math.hypot(rp.x - ME.x, rp.z - ME.z) < 2) {
        reviveT = rp;
      }
    }
    if (reviveT) {
      focus = {
        kind: 'revive',
        ref: reviveT,
        hold: true,
        label: () => `Hold ${K('use')} to revive ${escapeHTML(reviveT.name)}`,
      };
    }
  }
  W.repairing = false;
  if (focus) {
    txt = focus.label();
    if (focus.kind === 'window') {
      const w = focus.ref;
      if (IN.use && G.boards[w.i] < 6) {
        W.repairing = true;
        W.reload = null;
        ME.holdT += dt;
        W.hammerPh += dt * 2.2;
        prog = ME.holdT / 1;
        if (ME.holdT >= 1) {
          ME.holdT = 0;
          sendEvent(['board', w.i]);
          if (G.repairPts < 500) {
            addPoints(10);
            G.repairPts += 10;
          }
        }
      } else {
        ME.holdT = 0;
      }
    } else if (focus.kind === 'revive') {
      const need = ME.perks.has('second') ? 2 : 4;
      if (IN.use) {
        ME.holdT += dt;
        prog = ME.holdT / need;
        if (ME.holdT >= need) {
          ME.holdT = 0;
          sendEvent(['rev', focus.ref.peer]);
          NET.push(['rev', focus.ref.peer]);
          ME.stats.revives++;
        }
      } else {
        ME.holdT = 0;
      }
    } else {
      ME.holdT = 0;
      if (IN.usePressed && focus.use) {
        focus.use();
      }
    }
  } else {
    ME.holdT = 0;
  }
  IN.usePressed = false;
  if (pt._t !== txt) {
    pt.innerHTML = txt;
    pt._t = txt;
  }
  const pr = $('#prog');
  pr.hidden = prog < 0;
  if (prog >= 0) {
    pr.firstElementChild.style.width = clamp(prog, 0, 1) * 100 + '%';
  }
}

const FX = [],
  fxPool = [];

const FXDEF = {
  blood: {
    col: 6948870,
    add: false,
    sp: 2.2,
    up: 0.8,
    grav: 9,
    life: [0.35, 0.7],
    size: [0.05, 0.12],
    grow: 0,
  },
  mist: {
    col: 5899780,
    add: false,
    sp: 0.6,
    up: 0.2,
    grav: 0.5,
    life: [0.4, 0.7],
    size: [0.3, 0.5],
    grow: 1.2,
  },
  spark: {
    col: 16765056,
    add: true,
    sp: 4,
    up: 1,
    grav: 9,
    life: [0.15, 0.35],
    size: [0.03, 0.06],
    grow: 0,
  },
  dust: {
    col: 9078136,
    add: false,
    sp: 1.2,
    up: 0.8,
    grav: 1,
    life: [0.5, 1.1],
    size: [0.15, 0.35],
    grow: 1.3,
  },
  splinter: {
    col: 9071168,
    add: false,
    sp: 2.5,
    up: 1,
    grav: 9,
    life: [0.4, 0.8],
    size: [0.03, 0.07],
    grow: 0,
  },
  smoke: {
    col: 3815478,
    add: false,
    sp: 0.8,
    up: 1.2,
    grav: -0.4,
    life: [1.5, 2.6],
    size: [0.6, 1],
    grow: 1.4,
  },
  fire: {
    col: 16747056,
    add: true,
    sp: 4.5,
    up: 1,
    grav: 0,
    life: [0.25, 0.55],
    size: [0.5, 0.9],
    grow: 0.7,
  },
  wisp: {
    col: 9078144,
    add: false,
    sp: 0.15,
    up: 0.6,
    grav: -0.2,
    life: [0.6, 1.1],
    size: [0.08, 0.14],
    grow: 2.2,
  },
  steam: {
    col: 14212319,
    add: false,
    sp: 0.5,
    up: 1.4,
    grav: -0.8,
    life: [0.8, 1.4],
    size: [0.3, 0.5],
    grow: 2,
  },
  violet: {
    col: 11563263,
    add: true,
    sp: 2.5,
    up: 0.8,
    grav: 0,
    life: [0.2, 0.45],
    size: [0.15, 0.4],
    grow: 0.8,
  },
  arc: {
    col: 10475775,
    add: true,
    sp: 3,
    up: 1,
    grav: 0,
    life: [0.1, 0.25],
    size: [0.06, 0.14],
    grow: 0,
  },
  ember: {
    col: 16742954,
    add: true,
    sp: 0.3,
    up: 0.3,
    grav: 0,
    life: [0.2, 0.4],
    size: [0.08, 0.14],
    grow: 0,
  },
};

function spawnFX(x, y, z, n, type) {
  const D = FXDEF[type];
  for (let i = 0; i < n; i++) {
    if (FX.length > 320) {
      break;
    }
    let s = fxPool.pop();
    if (!s) {
      s = new THREE.Sprite(
        new THREE.SpriteMaterial({
          map: TX.smoke,
          transparent: true,
          depthWrite: false,
        }),
      );
    }
    s.material.color.setHex(D.col);
    s.material.blending = D.add ? THREE.AdditiveBlending : THREE.NormalBlending;
    s.material.map = D.add ? TX.glow : TX.smoke;
    s.material.opacity = 1;
    s.position.set(x, y, z);
    scene.add(s);
    const f = {
      s: s,
      vx: rand(-1, 1) * D.sp,
      vy: rand(0, 1) * D.sp * D.up + (type === 'smoke' ? 0.5 : 0),
      vz: rand(-1, 1) * D.sp,
      life: 0,
      max: rand(...D.life),
      grav: D.grav,
      size: rand(...D.size),
      grow: D.grow,
    };
    s.scale.set(f.size, f.size, 1);
    FX.push(f);
  }
}

function updateFX(dt) {
  for (let i = FX.length - 1; i >= 0; i--) {
    const f = FX[i];
    f.life += dt;
    const k = f.life / f.max;
    if (k >= 1) {
      scene.remove(f.s);
      fxPool.push(f.s);
      FX.splice(i, 1);
      continue;
    }
    f.vy -= f.grav * dt;
    f.s.position.x += f.vx * dt;
    f.s.position.y = Math.max(0.02, f.s.position.y + f.vy * dt);
    f.s.position.z += f.vz * dt;
    f.vx *= 0.95;
    f.vz *= 0.95;
    const sz = f.size * (1 + f.grow * k);
    f.s.scale.set(sz, sz, 1);
    f.s.material.opacity = 1 - k * k;
  }
  boomLight.intensity = Math.max(0, boomLight.intensity - dt * 14);
}

const decals = [];

let holeGeo, holeMat, poolMat;

function bulletHole(p, n) {
  if (!holeGeo) {
    holeGeo = new THREE.PlaneGeometry(0.09, 0.09);
    holeMat = new THREE.MeshBasicMaterial({
      map: TX.hole,
      transparent: true,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -2,
    });
  }
  const m = new THREE.Mesh(holeGeo, holeMat);
  m.position.set(p.x + n[0] * 0.01, p.y + n[1] * 0.01, p.z + n[2] * 0.01);
  m.lookAt(p.x + n[0], p.y + n[1], p.z + n[2]);
  m.rotation.z = rand(0, TAU);
  scene.add(m);
  decals.push(m);
  if (decals.length > 80) {
    scene.remove(decals.shift());
  }
}

const pools = [];

function bloodPool(x, z) {
  if (!poolMat) {
    poolMat = new THREE.MeshBasicMaterial({
      map: TX.blood,
      transparent: true,
      depthWrite: false,
      opacity: 0.9,
      polygonOffset: true,
      polygonOffsetFactor: -1,
    });
  }
  const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), poolMat);
  m.rotation.x = -Math.PI / 2;
  m.rotation.z = rand(0, TAU);
  const s = rand(1, 1.6);
  m.scale.set(s, s, 1);
  m.position.set(x, 0.015, z);
  scene.add(m);
  pools.push(m);
  if (pools.length > 40) {
    scene.remove(pools.shift());
  }
}

const hudC = {};

function setT(id, v) {
  if (hudC[id] !== v) {
    hudC[id] = v;
    document.getElementById(id).textContent = v;
  }
}

let hitTO = null;

function hitmark(kill) {
  if (!SET.game.hitmarkers) {
    return;
  }
  const h = $('#hitm');
  h.className = kill ? 'kill' : '';
  h.style.opacity = '1';
  clearTimeout(hitTO);
  hitTO = setTimeout(() => (h.style.opacity = '0'), kill ? 200 : 110);
  if (!kill) {
    AU.play('hitmark', {
      g: 0.35,
    });
  }
}

let centerTO = null;

function showCenter(t, s) {
  const c = $('#center');
  c.textContent = t;
  c.style.opacity = '1';
  clearTimeout(centerTO);
  centerTO = setTimeout(() => (c.style.opacity = '0'), s * 1e3);
}

function flashScreen(a) {
  POST.mat.uniforms.flash.value = a;
}

const bloodCtx = (() => {
  const c = $('#bloodc');
  return {
    c: c,
    g: c.getContext('2d'),
  };
})();

function sizeBlood() {
  bloodCtx.c.width = Math.max(1, innerWidth >> 1);
  bloodCtx.c.height = Math.max(1, innerHeight >> 1);
}

window.addEventListener('resize', sizeBlood);

sizeBlood();

function bloodSplat(n) {
  const { c: c, g: g } = bloodCtx;
  const w = c.width,
    h = c.height;
  for (let i = 0; i < n; i++) {
    const side = randi(0, 3);
    const x = side === 0 ? rand(0, w * 0.2) : side === 1 ? rand(w * 0.8, w) : rand(0, w);
    const y = side === 2 ? rand(0, h * 0.2) : side === 3 ? rand(h * 0.8, h) : rand(0, h);
    const r = rand(20, 70) * (w / 900);
    g.fillStyle = `rgba(${randi(90, 130)},0,0,${rand(0.5, 0.8)})`;
    for (let k = 0; k < 10; k++) {
      g.beginPath();
      g.arc(x + rand(-r, r), y + rand(-r, r), rand(r * 0.1, r * 0.5), 0, TAU);
      g.fill();
    }
    for (let k = 0; k < 4; k++) {
      g.fillRect(x + rand(-r, r), y, rand(2, 5), rand(r, r * 3));
    }
  }
}

function fadeBlood(dt) {
  const { c: c, g: g } = bloodCtx;
  g.globalCompositeOperation = 'destination-out';
  g.fillStyle = `rgba(0,0,0,${Math.min(1, dt * 0.7)})`;
  g.fillRect(0, 0, c.width, c.height);
  g.globalCompositeOperation = 'source-over';
}

function dmgDir(x, z) {
  const ang = Math.atan2(x - ME.x, z - ME.z);
  const rel = wrapA(ang - Math.atan2(-Math.sin(ME.yaw), -Math.cos(ME.yaw)));
  const el = document.createElement('div');
  el.className = 'ddir';
  el.style.transform = `rotate(${rel}rad)`;
  $('#dmgDir').appendChild(el);
  requestAnimationFrame(() => (el.style.opacity = '0'));
  setTimeout(() => el.remove(), 1e3);
}

function updateHUD(dt) {
  const w = curW(),
    d = wdef(w);
  setT('wname', w.inPress ? 'In the press…' : d.name);
  $('#wname').classList.toggle('pap', !!w.pap);
  setT('mag', String(w.mag));
  setT('res', String(w.res));
  $('#ammo').classList.toggle('low', w.mag <= Math.ceil(d.mag * 0.25));
  const rh = $('#reloadHint');
  const need = w.mag === 0 && !W.reload && !ME.dead;
  rh.style.opacity = need ? '1' : '0';
  if (need) {
    rh.textContent = w.res > 0 ? 'RELOAD' : 'NO AMMO';
  }
  if (hudC.nades !== ME.nades) {
    hudC.nades = ME.nades;
    $('#nades').innerHTML = '<i></i>'.repeat(ME.nades);
  }
  const pw = [];
  if (G.instakill > 0) {
    pw.push(['overkill', G.instakill]);
  }
  if (G.doublepay > 0) {
    pw.push(['doublepay', G.doublepay]);
  }
  const key = pw.map((p) => p[0] + Math.ceil(p[1])).join('|');
  if (hudC.pw !== key) {
    hudC.pw = key;
    $('#powers').innerHTML = pw
      .map(
        (p) =>
          `<div class="pw${p[1] < 6 ? ' blink' : ''}"><img alt="" src="${puTex(p[0]).url}"><span>${Math.ceil(p[1])}</span></div>`,
      )
      .join('');
  }
  const rows = [
    {
      name: SET.game.name,
      pts: ME.pts,
      me: true,
      down: ME.down || ME.dead,
    },
  ].concat(
    NET.remotes().map((r) => ({
      name: r.name,
      pts: r.pts,
      down: r.down || r.dead,
    })),
  );
  const tk = rows.map((r) => r.name + r.pts + r.down).join('|');
  if (hudC.team !== tk) {
    hudC.team = tk;
    $('#team').innerHTML = rows
      .map(
        (r) =>
          `<div class="sc${r.me ? ' me' : ''}${r.down ? ' down' : ''}">${rows.length > 1 ? `<em>${escapeHTML(r.name)}${r.down ? ' • down' : ''}</em>` : ''}<span>${r.pts}</span></div>`,
      )
      .join('');
  }
  if (G.roundShown !== G.round) {
    renderRound(G.round, false);
  }
  const moving = Math.hypot(ME.vx, ME.vz) > 1;
  const sp = (d.spread * (moving ? 1.5 : 1) + W.spreadAdd) * (1 - ME.adsK);
  const gap = 5 + sp * innerHeight * 0.9;
  const cr = $('#cross').children;
  cr[0].style.top = -gap - 8 + 'px';
  cr[1].style.top = gap + 'px';
  cr[2].style.left = -gap - 8 + 'px';
  cr[3].style.left = gap + 'px';
  $('#cross').style.opacity =
    !SET.game.crosshair || ME.adsK > 0.5 || ME.sprinting || W.drinkT > 0 || W.repairing ? '0' : '1';
  const dn = $('#downed');
  dn.hidden = !(ME.down || ME.dead);
  if (ME.down) {
    $('#downTxt').textContent =
      ME.selfRevT > 0
        ? 'Second Chance is kicking in…'
        : G.net === 'solo'
          ? ''
          : 'Crawl to safety. A teammate can revive you.';
    $('#downBar').firstElementChild.style.width = (ME.selfRevT > 0 ? 100 : (ME.bleed / 30) * 100) + '%';
    dn.firstElementChild.textContent = 'You’re down';
  }
  if (ME.dead) {
    dn.firstElementChild.textContent = 'Bled out';
    $('#downTxt').textContent = 'You come back when the next wave starts.';
    $('#downBar').firstElementChild.style.width = '0%';
  }
  const sc = $('#scores');
  sc.hidden = !IN.scores;
  if (IN.scores) {
    const all = [
      {
        name: SET.game.name,
        pts: ME.pts,
        st: ME.stats,
        me: true,
      },
    ].concat(
      NET.remotes().map((r) => ({
        name: r.name,
        pts: r.pts,
        st: r.st,
      })),
    );
    const html = `<table class="stats"><tr><th>Player</th><th>Points</th><th>Kills</th><th>Heads</th><th>Downs</th><th>Revives</th></tr>${all.map((p) => `<tr><td>${escapeHTML(p.name)}${p.me ? ' (you)' : ''}</td><td>${p.pts}</td><td>${p.st.kills}</td><td>${p.st.heads}</td><td>${p.st.downs}</td><td>${p.st.revives}</td></tr>`).join('')}</table>`;
    if (sc._h !== html) {
      sc.innerHTML = html;
      sc._h = html;
    }
  }
  POST.mat.uniforms.flash.value = Math.max(0, POST.mat.uniforms.flash.value - dt * 1.5);
}

function tallyPath(x0, y0, x1, y1, R, w) {
  const n = 9,
    L = [],
    Rr = [];
  const dx = x1 - x0,
    dy = y1 - y0,
    len = Math.hypot(dx, dy),
    nx = -dy / len,
    ny = dx / len;
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    const taper = Math.sin(Math.PI * (0.08 + t * 0.84));
    const hw = w * (0.55 + taper * 0.45) * (0.85 + R() * 0.3);
    const cx = x0 + dx * t + (R() - 0.5) * 2,
      cy = y0 + dy * t + (R() - 0.5) * 2;
    L.push([cx + nx * hw, cy + ny * hw]);
    Rr.push([cx - nx * hw * (0.8 + R() * 0.3), cy - ny * hw * (0.8 + R() * 0.3)]);
  }
  const pts = L.concat(Rr.reverse());
  return 'M' + pts.map((p) => p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' L') + ' Z';
}

function renderRound(n, fresh) {
  G.roundShown = n;
  const el = $('#round');
  if (!n) {
    el.innerHTML = '';
    return;
  }
  if (n > 5) {
    el.textContent = n;
    return;
  }
  const R = mulberry(n * 131 + 7);
  const W = 4 * 30 + 26,
    H = 112;
  let paths = '';
  const strokes = Math.min(n, 4);
  for (let i = 0; i < strokes; i++) {
    const x = 16 + i * 30 + (R() - 0.5) * 6;
    const d = tallyPath(x + (R() - 0.5) * 6, 10 + R() * 8, x + (R() - 0.5) * 10, H - 10 - R() * 8, R, 7);
    paths += `<path d="${d}" class="${fresh && i === strokes - 1 && n < 5 ? 'draw' : ''}"/>`;
    const dy = H - 14 - R() * 10;
    paths += `<path d="M${(x - 2).toFixed(1)} ${dy} q1 ${(10 + R() * 14).toFixed(1)} 2 ${(18 + R() * 16).toFixed(1)} q1 4 2 0 q-1-10 0-${(18 + R() * 16).toFixed(1)}Z" opacity=".85"/>`;
  }
  if (n === 5) {
    paths += `<path class="${fresh ? 'draw' : ''}" d="${tallyPath(4, H - 22, W - 4, 26, R, 7.5)}"/>`;
  }
  el.innerHTML = `<svg class="tally" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" role="img" aria-label="Wave ${n}"><g fill="currentColor">${paths}</g></svg>`;
}

let muzzleLight, boomLight, projLight;

function initGameLights() {
  ME.flashlight = new THREE.SpotLight(16773596, 1.6, 30, 0.48, 0.55, 1.2);
  ME.flashlight.position.set(0.2, -0.15, 0.1);
  camera.add(ME.flashlight);
  camera.add(ME.flashlight.target);
  ME.flashlight.target.position.set(0, -0.05, -1);
  ME.flashlight.shadow.mapSize.set(1024, 1024);
  ME.flashlight.shadow.bias = -6e-4;
  ME.flashlight.shadow.camera.near = 0.2;
  ME.flashlight.shadow.camera.far = 30;
  muzzleLight = new THREE.PointLight(16756832, 0, 9, 2);
  muzzleLight.position.set(0, 0, -0.8);
  camera.add(muzzleLight);
  boomLight = new THREE.PointLight(16747056, 0, 14, 2);
  scene.add(boomLight);
  projLight = new THREE.PointLight(16742954, 0, 7, 2);
  scene.add(projLight);
}

function gameUpdate(dt) {
  G.time += dt;
  if (G.instakill > 0) {
    G.instakill = Math.max(0, G.instakill - dt);
  }
  if (G.doublepay > 0) {
    G.doublepay = Math.max(0, G.doublepay - dt);
  }
  updatePlayer(dt);
  updateWeapon(dt);
  if (isAuth()) {
    zUpdateHost(dt);
    updateRounds(dt);
    updateCrateHost(dt);
    updatePUHost(dt);
  } else {
    zUpdateClient(dt);
  }
  for (const z of ZBS) {
    animZombie(z, dt);
    zSounds(z, dt);
  }
  updateNades(dt);
  updateBolts(dt);
  updateCasings(dt);
  updateArcs(dt);
  updatePress(dt);
  updateCandy(dt);
  sodaThemes(dt);
  syncPUVisuals(dt);
  updateCrateVisual(dt);
  updateBoards(dt);
  updateDoors(dt);
  updateFX(dt);
  updateLights(dt, G.time);
  updateInteract(dt);
  updateHUD(dt);
  fadeBlood(dt);
  updateRemotes(dt);
  NET.tick(dt);
  VM.update(dt);
  IN.lookDX = IN.lookDY = 0;
  ME.flashlight.intensity = ME.flashOn ? 1.6 : 0;
  if (WORLD.radio) {
    WORLD.radio.dial.material.color.setHSL(0.09, 0.8, G.power ? 0.6 : 0.3);
  }
}

const RP_VIS = new Map();

function updateRemotes(dt) {
  const list = NET.remotes();
  const seen = new Set();
  for (const r of list) {
    seen.add(r.peer);
    let v = RP_VIS.get(r.peer);
    if (!v) {
      const rig = buildRig({
        skinMat: ZM.playerSkin,
        faceMat: ZM.playerSkin,
        shirtMat: ZM.cloth.jacket,
        pantsMat: ZM.cloth.grey,
        cap: 'tweed',
        eyes: false,
      });
      scene.add(rig.root);
      const gun = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.1, 0.7), MAT.gBlue);
      gun.position.set(0, -0.28, 0.3);
      rig.sR.children[1] && rig.eR.add(gun);
      const tag = document.createElement('div');
      tag.className = 'tag3d';
      $('#tags').appendChild(tag);
      v = {
        rig: rig,
        x: r.x,
        z: r.z,
        y: 0,
        yaw: r.yaw,
        tag: tag,
        ph: 0,
        shots: r.shots,
      };
      RP_VIS.set(r.peer, v);
    }
    const px = v.x,
      pz = v.z;
    v.x = damp(v.x, r.x, 12, dt);
    v.z = damp(v.z, r.z, 12, dt);
    v.yaw += wrapA(r.yaw - v.yaw) * Math.min(1, dt * 12);
    const sp = Math.hypot(v.x - px, v.z - pz) / Math.max(dt, 1e-4);
    v.ph += dt * sp * 2.6;
    const s = Math.sin(v.ph),
      A = Math.min(0.7, sp * 0.15);
    const R = v.rig;
    R.hL.rotation.x = -s * A;
    R.hR.rotation.x = s * A;
    R.kL.rotation.x = Math.max(0, Math.sin(v.ph - 1.2)) * A * 1.5;
    R.kR.rotation.x = Math.max(0, Math.sin(v.ph + 1.9)) * A * 1.5;
    R.sR.rotation.set(-1.25 - r.pitch * 0.8, 0, -0.2);
    R.eR.rotation.x = -0.5;
    R.sL.rotation.set(-1.35 - r.pitch * 0.8, 0, 0.55);
    R.eL.rotation.x = -0.7;
    R.neck.rotation.x = -r.pitch * 0.6;
    R.root.rotation.x = r.down || r.dead ? -1.4 : r.prone ? 1.42 : 0;
    R.hips.position.y = r.crouch ? 0.7 : 0.95;
    R.root.position.set(v.x, r.down ? 0.2 : r.prone ? 0.12 : 0, v.z);
    R.root.rotation.y = v.yaw + Math.PI;
    if (r.shots !== v.shots) {
      const n = r.shots - v.shots;
      v.shots = r.shots;
      if (n > 0 && n < 20) {
        const g = GUNS[r.gun] || GUNS.warden;
        AU.play('gun_' + g.snd, {
          pos: [v.x, 1.4, v.z],
          wet: 0.5,
          ref: 4,
          rr: 0.04,
        });
      }
    }
    const p = new THREE.Vector3(v.x, r.down ? 0.7 : 2.05, v.z).project(camera);
    const vis = SET.game.tags && p.z < 1 && Math.abs(p.x) < 1.1 && Math.abs(p.y) < 1.1;
    v.tag.hidden = !vis;
    if (vis) {
      v.tag.style.left = ((p.x + 1) / 2) * innerWidth + 'px';
      v.tag.style.top = ((1 - p.y) / 2) * innerHeight + 'px';
      const t = r.name + (r.down ? ' • needs a revive' : r.dead ? ' • bled out' : '');
      if (v.tag.textContent !== t) {
        v.tag.textContent = t;
      }
      v.tag.classList.toggle('down', !!(r.down || r.dead));
    }
  }
  for (const [peer, v] of RP_VIS) {
    if (!seen.has(peer)) {
      scene.remove(v.rig.root);
      v.tag.remove();
      RP_VIS.delete(peer);
    }
  }
}

function clearRemotes() {
  for (const [, v] of RP_VIS) {
    scene.remove(v.rig.root);
    v.tag.remove();
  }
  RP_VIS.clear();
}

function resetWorld() {
  for (const z of ZBS.slice()) {
    zRemove(z);
  }
  ZID = 1;
  for (const n of nades) {
    scene.remove(n.m);
  }
  nades.length = 0;
  for (const c of casings) {
    scene.remove(c.m);
  }
  casings.length = 0;
  for (const b of bolts) {
    scene.remove(b.s);
  }
  bolts.length = 0;
  for (const f of FX) {
    scene.remove(f.s);
  }
  FX.length = 0;
  decals.forEach((d) => scene.remove(d));
  decals.length = 0;
  pools.forEach((p) => scene.remove(p));
  pools.length = 0;
  for (const [, v] of PU_VIS) {
    scene.remove(v.grp);
  }
  PU_VIS.clear();
  WORLD.rooms = JSON.parse(JSON.stringify(WORLD.map.rooms));
  WORLD.doors.forEach((d) => {
    d.open = true;
    setDoorOpen(d, false, false);
  });
  G.boards = WORLD.windows.map(() => 6);
  WORLD.windows.forEach((w) => {
    w.busy = null;
    w.n = 6;
    syncBoards(w, 6, false);
  });
  Object.assign(G, {
    round: 0,
    toSpawn: 0,
    spawnT: 0,
    inter: 4,
    time: 0,
    pus: [],
    instakill: 0,
    doublepay: 0,
    over: false,
    drops: 0,
    repairPts: 0,
    flowT: 0,
    puid: 1,
    roundShown: -1,
  });
  G.crate = {
    state: 'idle',
    t: 0,
    spot: 0,
    result: null,
    owner: null,
    uses: 0,
  };
  placeCrate(0);
  crateDisplay(null);
  Object.assign(PRESS, {
    state: 'idle',
    t: 0,
    slot: null,
    id: null,
  });
  if (WORLD.press) {
    pressDisplay(null);
    WORLD.press.platen.position.y = WORLD.press.platenY;
  }
  G.candyUses = 0;
  G.candyBusy = false;
  if (WORLD.candy) {
    WORLD.candy.grp.visible = G.diff === 'easy';
  }
  for (const sd of WORLD.sodas) {
    sd.tt = null;
  }
  setPower(false, false);
  gridBuild();
  const bc = bloodCtx;
  bc.g.clearRect(0, 0, bc.c.width, bc.c.height);
  POST.mat.uniforms.hurt.value = 0;
  POST.mat.uniforms.desat.value = 0;
  POST.mat.uniforms.blur.value = 0;
  for (const k in hudC) {
    delete hudC[k];
  }
}

function gameOver() {
  if (G.mode !== 'play') {
    return;
  }
  G.mode = 'over';
  G.over = true;
  G.overT = 0;
  AU.resume();
  AU.stopLoop('drone', 2);
  AU.play('mus_over', {
    bus: 'mus',
    g: 1.1,
  });
  setTimeout(
    () =>
      AU.play('laugh', {
        bus: 'mus',
        g: 1,
        wet: 0.8,
      }),
    1700,
  );
  if (document.exitPointerLock) {
    try {
      document.exitPointerLock();
    } catch (e) {}
  }
  const best = store.get('z50_best', 0);
  if (G.round > best) {
    store.set('z50_best', G.round);
  }
  $('#hud').hidden = true;
  $('#touch').hidden = true;
  document.body.classList.remove('playing');
  ZBS.forEach((z) => {
    if (!z.dead) {
      z.anim = 0;
      z.moveSpd = 0.5;
    }
  });
  setTimeout(() => {
    if (G.mode === 'over') {
      showOverScreen(best);
    }
  }, 3200);
}

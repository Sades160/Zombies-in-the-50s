// Address of a co-op relay (see README). Leave empty to play solo.
window.DEPOT9_SERVER = '';
window.Z50_SAME_ORIGIN_SERVER = false;

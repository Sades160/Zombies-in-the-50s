function rbox(w, h, d, r = 0.003) {
  r = Math.min(r, w / 2 - 1e-4, h / 2 - 1e-4, d / 2 - 1e-4);
  const bs = r * 0.6,
    ww = w - 2 * bs,
    hh = h - 2 * bs,
    x = -ww / 2,
    y = -hh / 2,
    rr = Math.min(r, ww / 2 - 1e-4, hh / 2 - 1e-4);
  const s = new THREE.Shape();
  s.moveTo(x + rr, y);
  s.lineTo(x + ww - rr, y);
  s.quadraticCurveTo(x + ww, y, x + ww, y + rr);
  s.lineTo(x + ww, y + hh - rr);
  s.quadraticCurveTo(x + ww, y + hh, x + ww - rr, y + hh);
  s.lineTo(x + rr, y + hh);
  s.quadraticCurveTo(x, y + hh, x, y + hh - rr);
  s.lineTo(x, y + rr);
  s.quadraticCurveTo(x, y, x + rr, y);
  const dep = Math.max(5e-4, d - 2 * r);
  const g = new THREE.ExtrudeGeometry(s, {
    depth: dep,
    bevelEnabled: true,
    bevelThickness: r,
    bevelSize: bs,
    bevelSegments: 2,
    curveSegments: 3,
  });
  g.translate(0, 0, -dep / 2);
  return g;
}

function prof(pts, th, bev = 0.003) {
  const s = new THREE.Shape();
  pts.forEach(([z, y], i) => (i ? s.lineTo(z, y) : s.moveTo(z, y)));
  const dep = th - 2 * bev;
  const g = new THREE.ExtrudeGeometry(s, {
    depth: dep,
    bevelEnabled: true,
    bevelThickness: bev,
    bevelSize: bev,
    bevelSegments: 2,
    curveSegments: 4,
  });
  g.rotateY(-Math.PI / 2);
  g.translate(dep / 2, 0, 0);
  return g;
}

function cyl(r, len, seg = 12, r2) {
  const g = new THREE.CylinderGeometry(r2 == null ? r : r2, r, len, seg);
  g.rotateX(Math.PI / 2);
  return g;
}

function add(p, geo, mat, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0) {
  const m = new THREE.Mesh(geo, mat);
  m.position.set(x, y, z);
  m.rotation.set(rx, ry, rz);
  p.add(m);
  return m;
}

function grp(p, x = 0, y = 0, z = 0) {
  const g = new THREE.Group();
  g.position.set(x, y, z);
  p.add(g);
  return g;
}

const GUNS = {
  warden: {
    name: 'M1911',
    pap: 'Dead Man’s Hand',
    cls: 'Pistol',
    dmg: 55,
    rpm: 400,
    auto: false,
    mag: 8,
    res: 64,
    reload: 1.6,
    rtype: 'mag',
    cycle: 'slide',
    spread: 0.011,
    head: 3,
    pen: 1,
    recoil: 0.022,
    snd: 'pistol',
    move: 1,
    build: mWarden,
  },
  karvel: {
    name: 'Kar98k',
    pap: 'The Long Goodnight',
    cls: 'Rifle',
    dmg: 190,
    rpm: 70,
    auto: false,
    mag: 5,
    res: 50,
    reload: 2.4,
    rtype: 'clip',
    cycle: 'bolt',
    cycleDur: 0.8,
    spread: 0.0025,
    head: 4,
    pen: 3,
    recoil: 0.07,
    snd: 'rifle',
    move: 0.94,
    wall: 200,
    build: mKarvel,
  },
  scatter: {
    name: 'M1897 Trench Gun',
    pap: 'The Undertaker',
    cls: 'Shotgun',
    dmg: 48,
    pellets: 8,
    rpm: 70,
    auto: false,
    mag: 6,
    res: 48,
    reload: 0.5,
    rtype: 'shell',
    cycle: 'pump',
    cycleDur: 0.6,
    spread: 0.07,
    head: 1.5,
    pen: 1,
    recoil: 0.085,
    snd: 'shotgun',
    move: 0.95,
    wall: 500,
    build: mScatter,
  },
  ridgeback: {
    name: 'Thompson M1A1',
    pap: 'Chicago Choir',
    cls: 'SMG',
    dmg: 48,
    rpm: 700,
    auto: true,
    mag: 30,
    res: 240,
    reload: 2.3,
    rtype: 'mag',
    cycle: null,
    spread: 0.026,
    head: 2.5,
    pen: 1,
    recoil: 0.013,
    snd: 'smg',
    move: 1,
    wall: 1e3,
    build: mRidgeback,
  },
  halberd: {
    name: 'BAR',
    pap: 'Iron Lung',
    cls: 'Automatic rifle',
    dmg: 88,
    rpm: 480,
    auto: true,
    mag: 20,
    res: 180,
    reload: 2.6,
    rtype: 'mag',
    cycle: null,
    spread: 0.016,
    head: 3,
    pen: 2,
    recoil: 0.02,
    snd: 'ar',
    move: 0.92,
    wall: 1200,
    build: mHalberd,
  },
  mercer: {
    name: 'M1 Garand',
    pap: 'Last Call',
    cls: 'Rifle',
    dmg: 135,
    rpm: 320,
    auto: false,
    mag: 8,
    res: 128,
    reload: 2.2,
    rtype: 'clip',
    cycle: null,
    spread: 0.006,
    head: 3.5,
    pen: 2,
    recoil: 0.045,
    snd: 'semi',
    move: 0.94,
    wall: 750,
    build: mMercer,
  },
  mp40: {
    name: 'MP40',
    pap: 'Night Shift',
    cls: 'SMG',
    dmg: 44,
    rpm: 550,
    auto: true,
    mag: 32,
    res: 256,
    reload: 2.1,
    rtype: 'mag',
    cycle: null,
    spread: 0.022,
    head: 2.5,
    pen: 1,
    recoil: 0.011,
    snd: 'smg',
    move: 1,
    build: mMP40,
  },
  stg44: {
    name: 'STG-44',
    pap: 'Graveyard Shift',
    cls: 'Assault rifle',
    dmg: 78,
    rpm: 560,
    auto: true,
    mag: 30,
    res: 240,
    reload: 2.4,
    rtype: 'mag',
    cycle: null,
    spread: 0.017,
    head: 3,
    pen: 2,
    recoil: 0.017,
    snd: 'ar',
    move: 0.95,
    build: mSTG,
  },
  longspear: {
    name: 'MG42',
    pap: 'Buzzsaw Betty',
    cls: 'Machine gun',
    dmg: 98,
    rpm: 900,
    auto: true,
    mag: 100,
    res: 400,
    reload: 5,
    rtype: 'mag',
    cycle: null,
    spread: 0.034,
    head: 2.5,
    pen: 2,
    recoil: 0.02,
    snd: 'lmg',
    move: 0.85,
    build: mLongspear,
  },
  riveter: {
    name: 'PPSh-41',
    pap: 'Red Hailstorm',
    cls: 'SMG',
    dmg: 42,
    rpm: 950,
    auto: true,
    mag: 71,
    res: 355,
    reload: 3.2,
    rtype: 'mag',
    cycle: null,
    spread: 0.03,
    head: 2.5,
    pen: 1,
    recoil: 0.01,
    snd: 'smg',
    move: 0.97,
    build: mRiveter,
  },
  marksman: {
    name: 'Springfield M1903',
    pap: 'Quiet Neighbor',
    cls: 'Scoped rifle',
    dmg: 520,
    rpm: 70,
    auto: false,
    mag: 5,
    res: 60,
    reload: 3,
    rtype: 'clip',
    cycle: 'bolt',
    cycleDur: 0.85,
    spread: 0.0012,
    head: 5,
    pen: 4,
    recoil: 0.08,
    snd: 'rifle',
    move: 0.9,
    scope: true,
    adsFov: 24,
    build: mMarksman,
  },
  ember: {
    name: 'Ember Projector',
    pap: 'Inferno Crown',
    cls: 'Wonder weapon',
    wonder: true,
    dmg: 1500,
    splash: 1e3,
    radius: 2.6,
    proj: 'ember',
    rpm: 170,
    auto: false,
    mag: 20,
    res: 160,
    reload: 3,
    rtype: 'mag',
    cycle: null,
    spread: 0.004,
    head: 1,
    pen: 1,
    recoil: 0.035,
    snd: 'ember',
    move: 0.95,
    build: mEmber,
  },
  nebula: {
    name: 'Nebula Pistol',
    pap: 'Supernova',
    cls: 'Wonder weapon',
    wonder: true,
    dmg: 1200,
    splash: 800,
    radius: 2.2,
    proj: 'orb',
    rpm: 220,
    auto: false,
    mag: 20,
    res: 160,
    reload: 2.4,
    rtype: 'mag',
    cycle: null,
    spread: 0.006,
    head: 1,
    pen: 1,
    recoil: 0.03,
    snd: 'nebula',
    move: 1,
    build: mNebula,
  },
  gale: {
    name: 'Gale Cannon',
    pap: 'Hurricane Hymn',
    cls: 'Wonder weapon',
    wonder: true,
    dmg: 1e6,
    blast: {
      range: 9,
      cone: 0.55,
    },
    rpm: 60,
    auto: false,
    mag: 2,
    res: 12,
    reload: 3.2,
    rtype: 'mag',
    cycle: null,
    spread: 0,
    head: 1,
    pen: 1,
    recoil: 0.12,
    snd: 'gale',
    move: 0.9,
    build: mGale,
  },
  volt: {
    name: 'Volt Coil Carbine',
    pap: 'Storm Choir',
    cls: 'Wonder weapon',
    wonder: true,
    dmg: 1e6,
    arc: {
      hops: 9,
      reach: 5.5,
    },
    rpm: 70,
    auto: false,
    mag: 3,
    res: 21,
    reload: 3,
    rtype: 'mag',
    cycle: null,
    spread: 0.004,
    head: 1,
    pen: 1,
    recoil: 0.05,
    snd: 'volt',
    move: 0.95,
    build: mVolt,
  },
};

const GUN_IDS = Object.keys(GUNS);

function screw(g, x, y, z, ax = 'x') {
  const m = add(g, new THREE.CylinderGeometry(0.0034, 0.0034, 0.0025, 10), MAT.gSteel, x, y, z);
  if (ax === 'x') {
    m.rotation.z = Math.PI / 2;
  } else if (ax === 'z') {
    m.rotation.x = Math.PI / 2;
  }
  add(m, new THREE.BoxGeometry(0.0048, 0.0028, 8e-4), MAT.dark, 0, 0, 0);
  return m;
}

function swivel(g, y, z) {
  const t = add(g, new THREE.TorusGeometry(0.009, 0.0018, 6, 14), MAT.gSteel, 0, y, z);
  t.rotation.y = Math.PI / 2;
  return t;
}

function crown(g, y, z, r) {
  add(g, new THREE.TorusGeometry(r, r * 0.22, 6, 16), MAT.gSteel, 0, y, z);
  add(g, new THREE.CircleGeometry(r * 0.55, 12), MAT.dark, 0, y, z - 0.001, 0, Math.PI);
}

function hood(g, y, z) {
  const t = add(g, new THREE.TorusGeometry(0.011, 0.0018, 6, 14, Math.PI), MAT.gBlue, 0, y, z);
}

const GUN_DETAIL = {
  warden: (r) => {
    const g = r.g;
    [
      [0.0175, -0.05, 0.045],
      [-0.0175, -0.05, 0.045],
      [0.0175, -0.1, 0.06],
      [-0.0175, -0.1, 0.06],
    ].forEach(([x, y, z]) => screw(g, x, y, z));
    add(
      g,
      prof(
        [
          [0.004, -0.016],
          [0.043, -0.016],
          [0.07, -0.112],
          [0.032, -0.119],
          [0.014, -0.022],
        ],
        0.036,
      ),
      MAT.gGrip,
      0,
      0,
      0,
    );
    add(r.slide, rbox(0.002, 0.012, 0.03), MAT.dark, 0.0155, 0.03, -0.04);
    add(r.slide, rbox(0.003, 0.004, 0.03), MAT.gSteel, 0.0158, 0.037, -0.02);
    add(g, rbox(0.012, 0.02, 0.02, 0.004), MAT.gBlue, 0, -0.008, 0.06);
  },
  karvel: (r) => {
    const g = r.g;
    swivel(g, -0.105, 0.42);
    swivel(g, 0.005, -0.36);
    crown(g, 0.03, -0.721, 0.0082);
    hood(g, 0.05, -0.708);
    [
      [0.024, 0.01, -0.09],
      [-0.024, 0.01, -0.09],
    ].forEach(([x, y, z]) => screw(g, x, y, z));
    add(g, rbox(0.02, 0.004, 0.07), MAT.gBlue, 0, -0.036, 0.02);
    screw(g, 0, -0.04, 0.08, 'y');
    screw(g, 0, -0.04, -0.03, 'y');
    add(g, cyl(0.012, 0.03), MAT.gPark, 0, 0.03, 0.13);
    add(g, rbox(0.02, 0.003, 0.04), MAT.gBlue, 0, 0.058, -0.105);
    add(g, rbox(0.003, 0.006, 0.003), MAT.dark, 0, 0.061, -0.105);
  },
  marksman: (r) => GUN_DETAIL.karvel(r),
  scatter: (r) => {
    const g = r.g;
    crown(g, 0.03, -0.661, 0.0105);
    [
      [0.022, 0, -0.01],
      [0.022, 0, -0.09],
      [-0.022, 0, -0.01],
      [-0.022, 0, -0.09],
    ].forEach(([x, y, z]) => screw(g, x, y, z));
    swivel(g, -0.1, 0.42);
    add(
      g,
      new THREE.TorusGeometry(0.016, 0.0035, 6, 16, Math.PI * 1.2),
      MAT.gBlue,
      0,
      -0.03,
      0.03,
      0,
      Math.PI / 2,
      Math.PI * 0.9,
    );
  },
  ridgeback: (r) => {
    const g = r.g;
    crown(g, 0.02, -0.381, 0.008);
    swivel(g, -0.09, 0.35);
    swivel(g, 0, -0.18);
    add(g, rbox(0.002, 0.008, 0.08), MAT.dark, 0.0205, 0.025, 0);
    screw(g, 0.021, 0, -0.15);
    screw(g, -0.021, 0, -0.15);
    add(
      g,
      prof(
        [
          [0.024, -0.004],
          [0.056, -0.004],
          [0.08, -0.086],
          [0.052, -0.09],
        ],
        0.032,
      ),
      MAT.gGrip,
    );
  },
  halberd: (r) => {
    const g = r.g;
    crown(g, 0.025, -0.865, 0.012);
    swivel(g, -0.105, 0.44);
    add(g, new THREE.TorusGeometry(0.007, 0.002, 6, 12), MAT.gBlue, 0, 0.07, 0.04);
    [
      [0.024, 0.03, -0.02],
      [0.024, 0.03, -0.16],
      [-0.024, 0.03, -0.16],
    ].forEach(([x, y, z]) => screw(g, x, y, z));
    add(g, rbox(0.002, 0.018, 0.07), MAT.dark, 0.024, 0.03, -0.08);
    add(g, cyl(0.013, 0.03), MAT.gPark, 0, 0, -0.52);
  },
  mercer: (r) => {
    const g = r.g;
    crown(g, 0.032, -0.821, 0.0095);
    swivel(g, -0.105, 0.42);
    swivel(g, 0.005, -0.6);
    hood(g, 0.058, -0.77);
    add(g, new THREE.TorusGeometry(0.0055, 0.0015, 6, 12), MAT.gBlue, 0, 0.07, 0.06);
    [
      [0.019, 0.03, -0.1],
      [-0.019, 0.03, -0.1],
    ].forEach(([x, y, z]) => screw(g, x, y, z));
    add(g, rbox(0.02, 0.004, 0.08), MAT.gBlue, 0, -0.036, 0.03);
  },
  longspear: (r) => {
    const g = r.g;
    crown(g, 0.03, -0.83, 0.014);
    [
      [0.033, 0.04, -0.2],
      [0.033, 0, -0.2],
      [-0.033, 0.04, -0.2],
      [0.033, 0.04, 0.02],
    ].forEach(([x, y, z]) => screw(g, x, y, z));
    add(g, rbox(0.002, 0.03, 0.09), MAT.dark, 0.032, 0.02, -0.08);
    add(g, cyl(0.004, 0.08), MAT.gSteel, 0, 0.1, -0.35);
  },
  riveter: (r) => {
    const g = r.g;
    crown(g, 0.035, -0.56, 0.016);
    for (let i = 0; i < 6; i++) {
      screw(g, 0.031, 0.045 - (i % 2) * 0.05, -0.02 - Math.floor(i / 2) * 0.08);
    }
    add(g, rbox(0.002, 0.025, 0.08), MAT.dark, 0.031, 0.03, -0.08);
  },
  ember: (r) => {
    const g = r.g;
    for (let i = 0; i < 8; i++) {
      add(
        g,
        new THREE.SphereGeometry(0.004, 6, 4),
        MAT.gBrass,
        i % 2 ? 0.036 : -0.036,
        0.045 - (i >> 2) * 0.06,
        -0.05 + ((i >> 1) % 2) * 0.16,
      );
    }
    const dial = add(
      g,
      new THREE.CircleGeometry(0.014, 16),
      new THREE.MeshBasicMaterial({
        color: 15257760,
      }),
      0.0361,
      0.02,
      0.1,
      0,
      Math.PI / 2,
    );
    add(g, rbox(0.001, 0.012, 0.002), MAT.dark, 0.037, 0.024, 0.1);
  },
};

for (const id in GUNS) {
  const base = GUNS[id].build;
  GUNS[id].build = () => {
    const r = base();
    if (GUN_DETAIL[id]) {
      GUN_DETAIL[id](r);
    }
    r.g.traverse((o) => {
      if (o.isMesh) {
        o.castShadow = false;
      }
    });
    return r;
  };
}

const CRATE_POOL = [
  'karvel',
  'scatter',
  'ridgeback',
  'halberd',
  'mercer',
  'mp40',
  'stg44',
  'longspear',
  'riveter',
  'marksman',
  'mp40',
  'stg44',
  'longspear',
  'riveter',
  'ember',
  'nebula',
  'gale',
  'volt',
];

const CRATE_WONDER_ODDS = 0.45;

function trig(g, y, z) {
  add(g, rbox(0.008, 0.005, 0.055), MAT.gBlue, 0, y - 0.012, z);
  add(g, rbox(0.008, 0.02, 0.005), MAT.gBlue, 0, y - 0.002, z - 0.026);
  add(g, rbox(0.004, 0.016, 0.005), MAT.gBlue, 0, y, z - 0.004, 0.3);
}

function mWarden() {
  const g = new THREE.Group(),
    r = {
      g: g,
    };
  add(g, rbox(0.028, 0.03, 0.19, 0.004), MAT.gBlue, 0, 0, -0.055);
  const sl = grp(g);
  add(sl, rbox(0.03, 0.028, 0.205, 0.004), MAT.gBlue, 0, 0.028, -0.058);
  add(sl, rbox(0.004, 0.012, 0.012), MAT.gBlue, 0, 0.047, -0.152);
  add(sl, rbox(0.02, 0.01, 0.01), MAT.gBlue, 0, 0.046, 0.035);
  add(sl, cyl(0.0075, 0.012), MAT.gPark, 0, 0.028, -0.163);
  for (let i = 0; i < 5; i++) {
    add(sl, rbox(0.031, 0.02, 0.002, 5e-4), MAT.gPark, 0, 0.028, 0.01 + i * 0.006);
  }
  add(
    g,
    prof(
      [
        [0, -0.012],
        [0.045, -0.012],
        [0.074, -0.116],
        [0.03, -0.123],
        [0.012, -0.02],
      ],
      0.034,
    ),
    MAT.gWood,
  );
  add(g, rbox(0.008, 0.015, 0.012), MAT.gBlue, 0, 0.036, 0.05, 0.5);
  trig(g, -0.014, -0.002);
  const mg = grp(g, 0, -0.066, 0.045);
  mg.rotation.x = -0.46;
  add(mg, rbox(0.021, 0.1, 0.03), MAT.gPark);
  add(mg, rbox(0.024, 0.008, 0.034), MAT.gBlue, 0, -0.052, 0);
  add(mg, cyl(0.0045, 0.02), MAT.gBrass, 0, 0.048, -0.003);
  r.slide = sl;
  r.mag = mg;
  r.magDir = [0, -0.9, 0.44];
  r.sight = [0.052, 0.035];
  r.muzzle = [0.028, -0.172];
  r.rh = [0, -0.06, 0.038];
  r.lh = [-0.014, -0.075, 0.03];
  return r;
}

function stockRifle(g, th = 0.044) {
  return add(
    g,
    prof(
      [
        [0.56, -0.115],
        [0.56, 0.03],
        [0.2, 0.022],
        [0.13, 0],
        [0.07, 0.013],
        [-0.43, 0.013],
        [-0.43, -0.028],
        [0, -0.034],
        [0.06, -0.068],
        [0.15, -0.058],
        [0.56, -0.115],
      ],
      th,
    ),
    MAT.gWood,
  );
}

function mKarvel() {
  const g = new THREE.Group(),
    r = {
      g: g,
    };
  stockRifle(g);
  add(g, rbox(0.046, 0.15, 0.01), MAT.gBlue, 0, -0.043, 0.565);
  add(g, cyl(0.0145, 0.22), MAT.gPark, 0, 0.03, 0);
  add(g, cyl(0.0082, 0.62, 12, 0.0105), MAT.gBlue, 0, 0.03, -0.41);
  add(g, rbox(0.028, 0.014, 0.28), MAT.gWood, 0, 0.044, -0.27);
  [-0.35, -0.42].forEach((z) => add(g, cyl(0.021, 0.012), MAT.gBlue, 0, 0.022, z));
  add(g, rbox(0.014, 0.012, 0.02), MAT.gBlue, 0, 0.042, -0.705);
  add(g, rbox(0.003, 0.014, 0.004), MAT.gBlue, 0, 0.054, -0.71);
  add(g, rbox(0.024, 0.012, 0.03), MAT.gBlue, 0, 0.05, -0.1);
  trig(g, -0.03, 0.06);
  const b = grp(g, 0, 0.03, 0.07);
  add(b, cyl(0.0092, 0.09), MAT.gPark, 0, 0, 0.01);
  add(b, rbox(0.05, 0.009, 0.009), MAT.gPark, 0.028, 0, 0.03);
  add(b, new THREE.SphereGeometry(0.009, 10, 8), MAT.gPark, 0.055, -0.006, 0.03);
  r.bolt = b;
  const clip = grp(g, 0, 0.07, 0.02);
  add(clip, rbox(0.012, 0.03, 0.045), MAT.gBrass);
  clip.visible = false;
  r.clip = clip;
  r.sight = [0.057, -0.1];
  r.muzzle = [0.03, -0.72];
  r.rh = [0, -0.05, 0.11];
  r.lh = [0, -0.038, -0.3];
  return r;
}

function mScatter() {
  const g = new THREE.Group(),
    r = {
      g: g,
    };
  add(
    g,
    prof(
      [
        [0.5, -0.105],
        [0.5, 0.03],
        [0.15, 0.02],
        [0.1, 0],
        [0.06, -0.005],
        [0.06, -0.03],
        [0.12, -0.062],
        [0.5, -0.11],
      ],
      0.044,
    ),
    MAT.gWood,
  );
  add(g, rbox(0.042, 0.058, 0.2, 0.005), MAT.gBlue, 0, 0.012, -0.045);
  add(g, rbox(0.002, 0.018, 0.05), MAT.dark, 0.022, 0.02, -0.05);
  add(g, cyl(0.0105, 0.52), MAT.gBlue, 0, 0.03, -0.4);
  add(g, cyl(0.0168, 0.3, 10), MAT.gPark, 0, 0.03, -0.32);
  for (let i = 0; i < 6; i++) {
    add(g, cyl(0.0172, 0.006, 10), MAT.dark, 0, 0.03, -0.2 - i * 0.045);
  }
  add(g, cyl(0.0085, 0.44), MAT.gBlue, 0, 0, -0.36);
  const pump = grp(g, 0, 0, -0.29);
  add(pump, cyl(0.019, 0.13, 12), MAT.gWood);
  for (let i = 0; i < 5; i++) {
    add(pump, cyl(0.0198, 0.006, 12), MAT.gBake, 0, 0, -0.05 + i * 0.025);
  }
  add(g, new THREE.SphereGeometry(0.0035, 8, 6), MAT.gBrass, 0, 0.043, -0.655);
  trig(g, -0.024, 0.03);
  const sh = grp(g);
  add(sh, cyl(0.009, 0.05), MAT.redPaint, 0, 0, -0.01);
  add(sh, cyl(0.0095, 0.016), MAT.gBrass, 0, 0, 0.025);
  sh.visible = false;
  r.shell = sh;
  r.pump = pump;
  r.sight = [0.043, -0.1];
  r.muzzle = [0.03, -0.66];
  r.rh = [0, -0.045, 0.085];
  r.lh = [0, -0.022, -0.29];
  return r;
}

function mRidgeback() {
  const g = new THREE.Group(),
    r = {
      g: g,
    };
  add(
    g,
    prof(
      [
        [0.4, -0.085],
        [0.4, 0.02],
        [0.12, 0.018],
        [0.085, -0.01],
        [0.12, -0.065],
        [0.4, -0.095],
      ],
      0.04,
    ),
    MAT.gWood,
  );
  add(g, cyl(0.02, 0.3, 14), MAT.gBlue, 0, 0.02, -0.06);
  add(g, cyl(0.0175, 0.13, 10), MAT.gPark, 0, 0.02, -0.27);
  for (let i = 0; i < 4; i++) {
    add(g, cyl(0.018, 0.008, 10), MAT.dark, 0, 0.02, -0.22 - i * 0.03);
  }
  add(g, cyl(0.008, 0.05), MAT.gBlue, 0, 0.02, -0.355);
  add(
    g,
    prof(
      [
        [0.02, 0],
        [0.06, 0],
        [0.085, -0.09],
        [0.05, -0.095],
      ],
      0.03,
    ),
    MAT.gWood,
  );
  trig(g, -0.012, 0.03);
  const mg = grp(g, 0, -0.085, -0.1);
  add(mg, rbox(0.022, 0.17, 0.034), MAT.gBlue);
  r.mag = mg;
  r.magDir = [0, -1, 0];
  const b = grp(g, 0.025, 0.025, 0.02);
  add(b, rbox(0.012, 0.008, 0.012), MAT.gPark);
  r.bolt = b;
  add(g, rbox(0.012, 0.016, 0.008), MAT.gBlue, 0, 0.045, 0.07);
  add(g, rbox(0.003, 0.02, 0.004), MAT.gBlue, 0, 0.042, -0.31);
  r.sight = [0.053, 0.07];
  r.muzzle = [0.02, -0.38];
  r.rh = [0, -0.05, 0.065];
  r.lh = [0, -0.012, -0.25];
  return r;
}

function mHalberd() {
  const g = new THREE.Group(),
    r = {
      g: g,
    };
  add(
    g,
    prof(
      [
        [0.5, -0.105],
        [0.5, 0.035],
        [0.15, 0.03],
        [0.1, 0.005],
        [0.06, -0.03],
        [0.12, -0.07],
        [0.5, -0.11],
      ],
      0.044,
    ),
    MAT.gWood,
  );
  add(g, rbox(0.046, 0.075, 0.34, 0.005), MAT.gPark, 0, 0.015, -0.1);
  add(g, rbox(0.05, 0.042, 0.22, 0.008), MAT.gWood, 0, 0, -0.37);
  add(g, cyl(0.0105, 0.36), MAT.gBlue, 0, 0.025, -0.64);
  add(g, cyl(0.015, 0.05, 10), MAT.gBlue, 0, 0.025, -0.84);
  [-0.012, 0.012].forEach((x) => add(g, cyl(0.004, 0.28, 6), MAT.steel, x, -0.004, -0.62));
  trig(g, -0.03, 0.06);
  const mg = grp(g, 0, -0.075, -0.1);
  add(mg, rbox(0.03, 0.105, 0.078), MAT.gBlue);
  r.mag = mg;
  r.magDir = [0, -1, 0];
  const b = grp(g, -0.027, 0.02, -0.02);
  add(b, rbox(0.012, 0.012, 0.012), MAT.gBlue);
  r.bolt = b;
  add(g, rbox(0.02, 0.02, 0.012), MAT.gBlue, 0, 0.062, 0.04);
  add(g, rbox(0.012, 0.02, 0.012), MAT.gBlue, 0, 0.045, -0.8);
  add(g, rbox(0.003, 0.016, 0.004), MAT.gBlue, 0, 0.058, -0.8);
  r.sight = [0.074, 0.04];
  r.muzzle = [0.025, -0.87];
  r.rh = [0, -0.052, 0.1];
  r.lh = [0, -0.03, -0.37];
  return r;
}

function mMercer() {
  const g = new THREE.Group(),
    r = {
      g: g,
    };
  add(
    g,
    prof(
      [
        [0.56, -0.115],
        [0.56, 0.03],
        [0.2, 0.022],
        [0.13, 0],
        [0.07, 0.013],
        [-0.44, 0.013],
        [-0.44, -0.025],
        [0, -0.034],
        [0.06, -0.068],
        [0.15, -0.058],
        [0.56, -0.115],
      ],
      0.046,
    ),
    MAT.gWood,
  );
  add(g, rbox(0.034, 0.016, 0.3), MAT.gWood, 0, 0.046, -0.28);
  add(g, rbox(0.036, 0.042, 0.2, 0.005), MAT.gPark, 0, 0.032, -0.02);
  add(g, cyl(0.0095, 0.4), MAT.gBlue, 0, 0.032, -0.62);
  add(g, cyl(0.011, 0.05), MAT.gPark, 0, 0.022, -0.75);
  add(g, rbox(0.003, 0.02, 0.004), MAT.gBlue, 0, 0.052, -0.77);
  add(g, rbox(0.026, 0.018, 0.014), MAT.gPark, 0, 0.062, 0.06);
  trig(g, -0.03, 0.06);
  const b = grp(g, 0.02, 0.03, 0.01);
  add(b, rbox(0.008, 0.012, 0.08), MAT.gPark);
  add(b, rbox(0.014, 0.012, 0.012), MAT.gPark, 0.006, 0, 0.035);
  r.bolt = b;
  const clip = grp(g, 0, 0.05, -0.02);
  add(clip, rbox(0.02, 0.008, 0.045), MAT.gBrass);
  r.clip = clip;
  r.sight = [0.073, 0.06];
  r.muzzle = [0.032, -0.82];
  r.rh = [0, -0.05, 0.11];
  r.lh = [0, -0.035, -0.3];
  return r;
}

function mLongspear() {
  const g = new THREE.Group(),
    r = {
      g: g,
    };
  add(
    g,
    prof(
      [
        [0.46, -0.1],
        [0.46, 0.04],
        [0.12, 0.035],
        [0.08, 0],
        [0.05, -0.03],
        [0.1, -0.075],
        [0.46, -0.105],
      ],
      0.05,
    ),
    MAT.gWood,
  );
  add(g, rbox(0.062, 0.09, 0.36, 0.006), MAT.gBlue, 0, 0.02, -0.1);
  const top = grp(g, 0, 0.075, -0.05);
  add(top, rbox(0.066, 0.02, 0.2, 0.004), MAT.gPark);
  r.bolt = top;
  add(g, cyl(0.028, 0.34, 14), MAT.gPark, 0, 0.03, -0.44);
  for (let i = 0; i < 6; i++) {
    add(g, cyl(0.029, 0.01, 14), MAT.dark, 0, 0.03, -0.32 - i * 0.045);
  }
  add(g, cyl(0.011, 0.18), MAT.gBlue, 0, 0.03, -0.7);
  add(g, cyl(0.018, 0.06, 10, 0.012), MAT.gBlue, 0, 0.03, -0.8);
  add(g, rbox(0.01, 0.04, 0.1), MAT.gBlue, 0, 0.07, -0.35);
  [-0.02, 0.02].forEach((x) => add(g, cyl(0.005, 0.3, 6), MAT.steel, x, 0, -0.62));
  const mg = grp(g, -0.06, -0.03, -0.06);
  add(mg, rbox(0.085, 0.1, 0.11, 0.006), MAT.gPark);
  r.mag = mg;
  r.magDir = [-0.7, -0.7, 0];
  add(
    g,
    prof(
      [
        [0.02, -0.02],
        [0.06, -0.02],
        [0.085, -0.11],
        [0.05, -0.115],
      ],
      0.03,
    ),
    MAT.gWood,
  );
  trig(g, -0.03, 0.04);
  add(g, rbox(0.018, 0.02, 0.012), MAT.gBlue, 0, 0.095, 0.02);
  add(g, rbox(0.004, 0.02, 0.004), MAT.gBlue, 0, 0.07, -0.58);
  r.sight = [0.105, 0.02];
  r.muzzle = [0.03, -0.83];
  r.rh = [0, -0.06, 0.07];
  r.lh = [0, -0.012, -0.42];
  return r;
}

function mRiveter() {
  const g = new THREE.Group(),
    r = {
      g: g,
    };
  add(
    g,
    prof(
      [
        [0.4, -0.1],
        [0.4, 0.035],
        [0.1, 0.03],
        [0.07, -0.01],
        [0.1, -0.07],
        [0.4, -0.105],
      ],
      0.05,
    ),
    MAT.gBake,
  );
  add(g, rbox(0.06, 0.085, 0.32, 0.008), MAT.gPark, 0, 0.02, -0.08);
  add(g, cyl(0.016, 0.32), MAT.gBlue, 0, 0.035, -0.4);
  add(g, rbox(0.035, 0.03, 0.05, 0.004), MAT.gBlue, 0, 0.035, -0.58);
  add(g, rbox(0.03, 0.08, 0.035, 0.006), MAT.gWood, 0, -0.05, -0.34);
  trig(g, -0.03, 0.06);
  const mg = grp(g, 0, -0.09, -0.08);
  const dg = new THREE.CylinderGeometry(0.075, 0.075, 0.06, 20);
  dg.rotateZ(Math.PI / 2);
  add(mg, dg, MAT.gBlue);
  add(mg, cyl(0.02, 0.065, 10), MAT.gPark, 0, 0, 0, 0, Math.PI / 2);
  r.mag = mg;
  r.magDir = [0, -1, 0];
  add(g, rbox(0.016, 0.016, 0.01), MAT.gBlue, 0, 0.07, 0.03);
  add(g, rbox(0.004, 0.02, 0.004), MAT.gBlue, 0, 0.06, -0.55);
  r.sight = [0.078, 0.03];
  r.muzzle = [0.035, -0.61];
  r.rh = [0, -0.052, 0.085];
  r.lh = [0, -0.075, -0.34];
  return r;
}

function mMarksman() {
  const r = mKarvel(),
    g = r.g;
  r.clip.visible = false;
  add(g, cyl(0.013, 0.26, 14), MAT.gBlue, 0, 0.085, -0.05);
  add(g, cyl(0.013, 0.05, 14, 0.021), MAT.gBlue, 0, 0.085, -0.2);
  add(g, cyl(0.018, 0.05, 14, 0.013), MAT.gBlue, 0, 0.085, 0.1);
  add(g, new THREE.CircleGeometry(0.018, 16), MAT.glass, 0, 0.085, -0.226, 0, Math.PI);
  [-0.1, 0].forEach((z) => add(g, rbox(0.01, 0.03, 0.012), MAT.gBlue, 0, 0.062, z));
  const mg = grp(g, 0, -0.06, 0);
  add(mg, rbox(0.024, 0.06, 0.06), MAT.gBlue);
  r.mag = mg;
  r.magDir = [0, -1, 0];
  r.sight = [0.085, 0.1];
  return r;
}

function mEmber() {
  const g = new THREE.Group(),
    r = {
      g: g,
    };
  add(g, rbox(0.07, 0.09, 0.26, 0.012), MAT.gBake, 0, 0.01, 0.05);
  add(
    g,
    prof(
      [
        [0.08, -0.03],
        [0.12, -0.03],
        [0.145, -0.125],
        [0.1, -0.13],
      ],
      0.034,
    ),
    MAT.gWood,
  );
  trig(g, -0.04, 0.04);
  add(g, cyl(0.036, 0.03, 16), MAT.gBrass, 0, 0.02, -0.1);
  add(g, cyl(0.028, 0.3, 16), MAT.gGlass, 0, 0.02, -0.27);
  const core = add(g, cyl(0.009, 0.3, 8), MAT.gGlow, 0, 0.02, -0.27);
  r.core = core;
  [-0.16, -0.22, -0.28, -0.34].forEach((z) =>
    add(g, new THREE.TorusGeometry(0.033, 0.005, 6, 18), MAT.gCopper, 0, 0.02, z),
  );
  add(g, cyl(0.02, 0.05, 16, 0.031), MAT.gBrass, 0, 0.02, -0.44);
  [0.07, 0.11].forEach((z) => {
    const t = new THREE.CylinderGeometry(0.009, 0.009, 0.035, 8);
    add(g, t, MAT.gGlass, 0, 0.072, z);
    add(g, new THREE.CylinderGeometry(0.004, 0.004, 0.03, 6), MAT.gGlow, 0, 0.072, z);
  });
  add(g, rbox(0.012, 0.012, 0.12), MAT.gBrass, 0, 0.062, 0.06);
  const mg = grp(g, 0, -0.055, -0.02);
  add(mg, rbox(0.04, 0.05, 0.06, 0.006), MAT.gCopper);
  add(mg, rbox(0.03, 0.01, 0.05), MAT.gGlow, 0, -0.028, 0);
  r.mag = mg;
  r.magDir = [0, -1, 0];
  const b = grp(g, 0.04, 0.02, 0.1);
  add(b, rbox(0.012, 0.02, 0.03), MAT.gBrass);
  r.bolt = b;
  r.sight = [0.07, 0.12];
  r.muzzle = [0.02, -0.47];
  r.rh = [0, -0.075, 0.12];
  r.lh = [0, -0.022, -0.13];
  return r;
}

function mMP40() {
  const g = new THREE.Group(),
    r = {
      g: g,
    };
  add(g, cyl(0.018, 0.3, 14), MAT.gBlue, 0, 0.02, -0.08);
  add(g, cyl(0.011, 0.12, 10), MAT.gBlue, 0, 0.018, -0.29);
  add(g, rbox(0.03, 0.012, 0.07), MAT.gBlue, 0, -0.005, -0.3);
  add(g, rbox(0.026, 0.05, 0.16, 0.006), MAT.gBake, 0, -0.012, -0.02);
  add(
    g,
    prof(
      [
        [0.03, -0.02],
        [0.065, -0.02],
        [0.085, -0.1],
        [0.05, -0.105],
      ],
      0.03,
    ),
    MAT.gBake,
  );
  [-0.012, 0.012].forEach((x) => {
    add(g, cyl(0.004, 0.26, 6), MAT.gBlue, x, 0, 0.2);
  });
  add(g, rbox(0.04, 0.06, 0.008), MAT.gBlue, 0, -0.01, 0.33);
  trig(g, -0.02, 0.05);
  const mg = grp(g, 0, -0.1, -0.12);
  add(mg, rbox(0.02, 0.2, 0.032), MAT.gBlue);
  add(g, rbox(0.03, 0.05, 0.04), MAT.gBlue, 0, -0.02, -0.12);
  r.mag = mg;
  r.magDir = [0, -1, 0];
  const b = grp(g, -0.022, 0.022, 0.02);
  add(b, cyl(0.006, 0.02, 8), MAT.gSteel, 0, 0, 0, 0, 0, Math.PI / 2);
  r.bolt = b;
  add(g, rbox(0.012, 0.014, 0.01), MAT.gBlue, 0, 0.044, 0.05);
  hood(g, 0.036, -0.33);
  r.sight = [0.051, 0.05];
  r.muzzle = [0.018, -0.36];
  r.rh = [0, -0.055, 0.065];
  r.lh = [0, -0.07, -0.12];
  return r;
}

function mSTG() {
  const g = new THREE.Group(),
    r = {
      g: g,
    };
  add(
    g,
    prof(
      [
        [0.42, -0.09],
        [0.42, 0.03],
        [0.14, 0.028],
        [0.1, -0.01],
        [0.14, -0.07],
        [0.42, -0.1],
      ],
      0.042,
    ),
    MAT.gWood,
  );
  add(g, rbox(0.042, 0.07, 0.34, 0.005), MAT.gPark, 0, 0.02, -0.05);
  add(g, rbox(0.044, 0.046, 0.16, 0.006), MAT.gWood, 0, 0.005, -0.3);
  add(g, cyl(0.01, 0.2), MAT.gBlue, 0, 0.03, -0.45);
  add(g, cyl(0.013, 0.05), MAT.gBlue, 0, 0.01, -0.4);
  add(
    g,
    prof(
      [
        [0.07, -0.015],
        [0.105, -0.015],
        [0.125, -0.1],
        [0.09, -0.105],
      ],
      0.03,
    ),
    MAT.gWood,
  );
  trig(g, -0.02, 0.09);
  const mg = grp(g, 0, -0.07, -0.12);
  const curve = new THREE.Shape();
  curve.moveTo(-0.02, 0);
  curve.quadraticCurveTo(-0.03, -0.09, -0.06, -0.17);
  curve.lineTo(-0.02, -0.18);
  curve.quadraticCurveTo(0.005, -0.09, 0.02, 0);
  curve.lineTo(-0.02, 0);
  const cg = new THREE.ExtrudeGeometry(curve, {
    depth: 0.022,
    bevelEnabled: true,
    bevelThickness: 0.002,
    bevelSize: 0.002,
    bevelSegments: 1,
  });
  cg.rotateY(-Math.PI / 2);
  cg.translate(0.011, 0.02, 0);
  add(mg, cg, MAT.gBlue);
  r.mag = mg;
  r.magDir = [0, -0.9, 0.3];
  const b = grp(g, -0.023, 0.03, -0.02);
  add(b, rbox(0.01, 0.01, 0.014), MAT.gSteel);
  r.bolt = b;
  add(g, rbox(0.016, 0.016, 0.02), MAT.gBlue, 0, 0.062, -0.14);
  add(g, rbox(0.004, 0.02, 0.004), MAT.gBlue, 0, 0.05, -0.53);
  r.sight = [0.07, -0.14];
  r.muzzle = [0.03, -0.55];
  r.rh = [0, -0.06, 0.1];
  r.lh = [0, -0.02, -0.3];
  return r;
}

function mNebula() {
  const g = new THREE.Group(),
    r = {
      g: g,
    };
  const chrome = MAT.chrome,
    glassV = new THREE.MeshBasicMaterial({
      color: 11563263,
      transparent: true,
      opacity: 0.45,
    }),
    coreV = new THREE.MeshBasicMaterial({
      color: 14199039,
    });
  add(g, rbox(0.04, 0.05, 0.15, 0.012), chrome, 0, 0.02, 0);
  add(
    g,
    prof(
      [
        [0.03, -0.005],
        [0.07, -0.005],
        [0.09, -0.11],
        [0.052, -0.115],
      ],
      0.034,
    ),
    MAT.gBake,
  );
  add(g, new THREE.SphereGeometry(0.036, 18, 14), glassV, 0, 0.03, -0.1);
  const core = add(g, new THREE.SphereGeometry(0.016, 12, 10), coreV, 0, 0.03, -0.1);
  r.core = core;
  r.coreHue = 0.78;
  [-0.075, -0.125].forEach((z) => add(g, new THREE.TorusGeometry(0.037, 0.004, 6, 20), chrome, 0, 0.03, z));
  add(g, cyl(0.012, 0.07, 12, 0.02), chrome, 0, 0.03, -0.17);
  add(g, new THREE.TorusGeometry(0.013, 0.003, 6, 14), MAT.gCopper, 0, 0.03, -0.205);
  add(g, rbox(0.01, 0.014, 0.1), MAT.gCopper, 0, 0.052, 0.01);
  add(g, rbox(0.03, 0.006, 0.03), MAT.gCopper, 0, 0.002, 0.06);
  trig(g, -0.005, 0.03);
  const mg = grp(g, 0, -0.06, 0.06);
  add(mg, rbox(0.024, 0.03, 0.03, 0.006), MAT.gCopper);
  r.mag = mg;
  r.magDir = [0, -0.9, 0.44];
  r.sight = [0.06, 0.05];
  r.muzzle = [0.03, -0.21];
  r.rh = [0, -0.06, 0.07];
  r.lh = [-0.014, -0.075, 0.06];
  return r;
}

function mGale() {
  const g = new THREE.Group(),
    r = {
      g: g,
    };
  add(
    g,
    prof(
      [
        [0.46, -0.1],
        [0.46, 0.03],
        [0.2, 0.03],
        [0.14, -0.01],
        [0.2, -0.07],
        [0.46, -0.11],
      ],
      0.046,
    ),
    MAT.gWood,
  );
  const bel = new THREE.Group();
  bel.position.set(0, 0.02, -0.12);
  g.add(bel);
  for (let i = 0; i < 6; i++) {
    add(
      bel,
      new THREE.CylinderGeometry(0.055 - (i % 2) * 0.008, 0.055 - ((i + 1) % 2) * 0.008, 0.03, 18, 1, true),
      std({
        color: 3810840,
        roughness: 0.8,
        side: THREE.DoubleSide,
      }),
      0,
      0,
      -i * 0.028,
      Math.PI / 2,
    );
  }
  add(g, rbox(0.07, 0.08, 0.14, 0.01), MAT.gBrass, 0, 0.02, 0.04);
  const horn = new THREE.LatheGeometry(
    [
      [0.03, 0],
      [0.035, 0.06],
      [0.05, 0.13],
      [0.08, 0.2],
      [0.12, 0.25],
      [0.125, 0.255],
    ].map((p) => new THREE.Vector2(p[0], p[1])),
    28,
  );
  horn.rotateX(-Math.PI / 2);
  add(
    g,
    horn,
    std({
      color: 13145660,
      roughness: 0.25,
      metalness: 1,
      side: THREE.DoubleSide,
    }),
    0,
    0.02,
    -0.3,
  );
  add(g, new THREE.TorusGeometry(0.125, 0.006, 8, 28), MAT.gCopper, 0, 0.02, -0.555);
  [0.035, -0.035].forEach((x) => add(g, cyl(0.006, 0.3, 8), MAT.gSteel, x, -0.035, -0.2));
  add(
    g,
    prof(
      [
        [0.08, -0.02],
        [0.12, -0.02],
        [0.14, -0.12],
        [0.1, -0.125],
      ],
      0.032,
    ),
    MAT.gWood,
  );
  trig(g, -0.02, 0.1);
  const gauge = add(
    g,
    new THREE.CylinderGeometry(0.022, 0.022, 0.01, 16),
    MAT.gBrass,
    0.045,
    0.05,
    0.05,
    0,
    0,
    Math.PI / 2,
  );
  add(g, new THREE.CircleGeometry(0.018, 16), MAT.watchFace || MAT.gSteel, 0.051, 0.05, 0.05, 0, Math.PI / 2);
  const mg = grp(g, 0, -0.06, 0.02);
  add(mg, cyl(0.022, 0.09, 12), MAT.gCopper);
  r.mag = mg;
  r.magDir = [0, -1, 0];
  r.bellows = bel;
  r.sight = [0.075, 0.06];
  r.muzzle = [0.02, -0.56];
  r.rh = [0, -0.07, 0.11];
  r.lh = [0, -0.05, -0.2];
  return r;
}

function mVolt() {
  const g = new THREE.Group(),
    r = {
      g: g,
    };
  add(
    g,
    prof(
      [
        [0.44, -0.1],
        [0.44, 0.03],
        [0.16, 0.025],
        [0.1, -0.005],
        [0.15, -0.065],
        [0.44, -0.11],
      ],
      0.044,
    ),
    MAT.gWood,
  );
  add(g, rbox(0.05, 0.07, 0.22, 0.01), MAT.gPark, 0, 0.015, -0.05);
  add(g, cyl(0.012, 0.44), MAT.gBlue, 0, 0.03, -0.38);
  const coil = new THREE.TubeGeometry(
    new THREE.CatmullRomCurve3(
      Array.from(
        {
          length: 90,
        },
        (_, i) => {
          const a = (i / 89) * Math.PI * 2 * 11;
          return new THREE.Vector3(Math.cos(a) * 0.022, 0.03 + Math.sin(a) * 0.022, -0.2 - (i / 89) * 0.34);
        },
      ),
    ),
    360,
    0.0035,
    5,
    false,
  );
  add(g, coil, MAT.gCopper);
  const ins = std({
    color: 14998992,
    roughness: 0.25,
  });
  [-0.19, -0.36, -0.55].forEach((z) => {
    for (let i = 0; i < 3; i++) {
      add(
        g,
        new THREE.CylinderGeometry(0.018 - i * 0.002, 0.018 - i * 0.002, 0.008, 14),
        ins,
        0,
        0.03,
        z - i * 0.01,
        Math.PI / 2,
      );
    }
  });
  const tip = add(
    g,
    new THREE.SphereGeometry(0.014, 12, 10),
    new THREE.MeshBasicMaterial({
      color: 10475775,
    }),
    0,
    0.03,
    -0.6,
  );
  r.core = tip;
  r.coreHue = 0.56;
  add(g, rbox(0.03, 0.04, 0.06, 0.008), MAT.gBrass, 0, 0.07, -0.02);
  add(g, rbox(0.012, 0.012, 0.1), MAT.gBlue, 0, 0.06, 0.06);
  trig(g, -0.025, 0.06);
  const mg = grp(g, 0, -0.06, -0.07);
  add(mg, rbox(0.036, 0.06, 0.07, 0.008), MAT.gCopper);
  add(
    mg,
    rbox(0.03, 0.01, 0.05),
    new THREE.MeshBasicMaterial({
      color: 8374527,
    }),
    0,
    -0.032,
    0,
  );
  r.mag = mg;
  r.magDir = [0, -1, 0];
  r.sight = [0.068, 0.06];
  r.muzzle = [0.03, -0.61];
  r.rh = [0, -0.055, 0.1];
  r.lh = [0, -0.012, -0.3];
  return r;
}

function buildKnife() {
  const g = new THREE.Group();
  add(g, rbox(0.022, 0.025, 0.11, 0.006), MAT.gWood, 0, 0, 0.04);
  add(g, rbox(0.03, 0.04, 0.01), MAT.gBrass, 0, 0.005, -0.02);
  const bg = new THREE.Shape();
  bg.moveTo(0, -0.012);
  bg.lineTo(0.17, -0.004);
  bg.lineTo(0.2, 0.01);
  bg.lineTo(0, 0.014);
  const bl = new THREE.ExtrudeGeometry(bg, {
    depth: 0.004,
    bevelEnabled: false,
  });
  bl.rotateY(Math.PI / 2);
  bl.translate(0.002, 0, -0.025);
  add(g, bl, MAT.blade);
  return g;
}

function buildHammer() {
  const g = new THREE.Group();
  add(g, rbox(0.024, 0.024, 0.3, 0.008), MAT.gWood, 0, 0, 0);
  add(g, rbox(0.03, 0.09, 0.03, 0.004), MAT.hammerHead, 0, 0.02, -0.16);
  return g;
}

function buildBottle(color) {
  const g = new THREE.Group();
  const lg = new THREE.LatheGeometry(
    [
      [0, 0],
      [0.028, 0],
      [0.03, 0.01],
      [0.03, 0.1],
      [0.022, 0.14],
      [0.011, 0.17],
      [0.011, 0.2],
      [0.013, 0.205],
      [0, 0.205],
    ].map((p) => new THREE.Vector2(p[0], p[1])),
    18,
  );
  add(
    g,
    lg,
    std({
      color: color,
      roughness: 0.08,
      metalness: 0.1,
      transparent: true,
      opacity: 0.82,
    }),
  );
  add(
    g,
    cyl(0.031, 0.05, 18),
    std({
      color: 15260868,
      roughness: 0.5,
    }),
    0,
    0.07,
    0,
    Math.PI / 2,
  );
  add(
    g,
    new THREE.CylinderGeometry(0.027, 0.026, 0.095, 16),
    std({
      color: 1707014,
      roughness: 0.3,
      transparent: true,
      opacity: 0.7,
    }),
    0,
    0.055,
    0,
  );
  const cap = new THREE.Group();
  cap.position.set(0, 0.21, 0);
  g.add(cap);
  add(
    cap,
    new THREE.CylinderGeometry(0.0145, 0.0145, 0.008, 18),
    std({
      color: 13158600,
      roughness: 0.3,
      metalness: 1,
    }),
  );
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * TAU;
    add(
      cap,
      new THREE.BoxGeometry(0.003, 0.008, 0.003),
      MAT.chrome,
      Math.cos(a) * 0.0152,
      -0.001,
      Math.sin(a) * 0.0152,
    );
  }
  g.userData.cap = cap;
  return g;
}

function buildGrenade() {
  const g = new THREE.Group();
  add(g, new THREE.CylinderGeometry(0.028, 0.028, 0.07, 12), MAT.gPark);
  add(g, new THREE.CylinderGeometry(0.012, 0.016, 0.02, 8), MAT.gBlue, 0, 0.044, 0);
  add(g, new THREE.TorusGeometry(0.01, 0.002, 6, 12), MAT.chrome, 0.014, 0.05, 0);
  return g;
}

const VM = {
  root: new THREE.Group(),
  pivot: new THREE.Group(),
  rig: null,
  id: null,
  s: 0.72,
  st: {
    kick: 0,
    roll: 0,
    swayX: 0,
    swayY: 0,
    bob: 0,
    ads: 0,
    sprint: 0,
    land: 0,
    lowered: 0,
  },
  init() {
    vmScene.add(this.root);
    this.root.add(this.pivot);
    this.pivot.scale.setScalar(this.s);
    const hand = (left) => {
      const h = new THREE.Group();
      add(h, rbox(0.05, 0.03, 0.08, 0.012), MAT.skinHand);
      for (let i = 0; i < 4; i++) {
        const f = grp(h, -0.018 + i * 0.012, -0.004, -0.04);
        f.rotation.x = 0.5 + i * 0.06;
        add(f, rbox(0.011, 0.012, 0.03, 0.005), MAT.skinHand, 0, 0, -0.014);
        const f2 = grp(f, 0, 0, -0.028);
        f2.rotation.x = 1.1;
        add(f2, rbox(0.01, 0.011, 0.025, 0.005), MAT.skinHand, 0, 0, -0.011);
      }
      const th = grp(h, left ? 0.026 : -0.026, 0.006, -0.01);
      th.rotation.set(0, left ? -0.6 : 0.6, 0);
      add(th, rbox(0.014, 0.014, 0.04, 0.006), MAT.skinHand, 0, 0, -0.02);
      add(h, cyl(0.03, 0.045, 12), MAT.sleeve, 0, 0, 0.07);
      add(h, cyl(0.032, 0.012, 12), MAT.sleeve, 0, 0, 0.05);
      if (left) {
        const w = grp(h, 0, 0, 0.038);
        add(w, cyl(0.029, 0.014, 14), MAT.watch);
        add(w, new THREE.CylinderGeometry(0.011, 0.011, 0.006, 16), MAT.gSteel, 0, 0.031, 0);
        add(w, new THREE.CylinderGeometry(0.009, 0.009, 0.002, 16), MAT.watchFace, 0, 0.0345, 0);
      }
      this.root.add(h);
      return h;
    };
    this.hR = hand(false);
    this.hL = hand(true);
    const arm = () => {
      const m = new THREE.Mesh(new THREE.CylinderGeometry(0.036, 0.03, 1, 10), MAT.sleeve);
      this.root.add(m);
      return m;
    };
    this.aR = arm();
    this.aL = arm();
    this.flash = new THREE.Sprite(
      new THREE.SpriteMaterial({
        map: TX.flash,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        transparent: true,
      }),
    );
    this.flash.visible = false;
    this.knife = buildKnife();
    this.root.add(this.knife);
    this.knife.visible = false;
    this.hammer = buildHammer();
    this.root.add(this.hammer);
    this.hammer.visible = false;
    this.nade = buildGrenade();
    this.root.add(this.nade);
    this.nade.visible = false;
    this.bottles = {};
    this.bottle = null;
  },
  set(id, pap) {
    if (this.rig) {
      this.pivot.remove(this.rig.g);
    }
    if (!this.cache) {
      this.cache = {};
    }
    const rig = this.cache[id] || (this.cache[id] = GUNS[id].build());
    this.rig = rig;
    this.id = id;
    this.pivot.add(rig.g);
    rig.g.add(this.flash);
    this.flash.position.set(0, rig.muzzle[0], rig.muzzle[1] - 0.05);
    this.flash.material.color.set(
      pap
        ? 16734896
        : {
            ember: 16742954,
            nebula: 11563263,
            volt: 12577023,
          }[id] || 16777215,
    );
    this.flash.material.opacity = id === 'gale' ? 0 : 1;
    rig.g.traverse((m) => {
      if (!m.isMesh) {
        return;
      }
      if (!m.userData.m0) {
        m.userData.m0 = m.material;
      }
      const m0 = m.userData.m0;
      m.material = !pap
        ? m0
        : m0 === MAT.gBlue || m0 === MAT.gPark || m0 === MAT.gSteel
          ? MAT.papMetal
          : m0 === MAT.gWood || m0 === MAT.gBake || m0 === MAT.gGrip
            ? MAT.papWood
            : m0;
    });
    this.pap = !!pap;
    if (!rig.homes) {
      rig.homes = {};
      for (const k of ['mag', 'bolt', 'slide', 'pump', 'clip']) {
        if (rig[k]) {
          rig.homes[k] = rig[k].position.clone();
        }
      }
      if (rig.bolt) {
        rig.homes.boltR = rig.bolt.rotation.clone();
      }
    }
  },
  setBottle(color) {
    if (!this.bottles[color]) {
      this.bottles[color] = buildBottle(color);
      this.root.add(this.bottles[color]);
    }
    for (const k in this.bottles) {
      this.bottles[k].visible = false;
    }
    this.bottle = this.bottles[color];
  },
  _v: new THREE.Vector3(),
  _q: new THREE.Quaternion(),
  _up: new THREE.Vector3(0, 1, 0),
  placeArm(m, from, to) {
    const d = this._v.copy(to).sub(from);
    const L = d.length();
    m.position.copy(from).addScaledVector(d, 0.5);
    m.scale.set(1, L, 1);
    m.quaternion.setFromUnitVectors(this._up, d.normalize());
  },
  update(dt) {
    const r = this.rig;
    if (!r) {
      return;
    }
    const st = this.st,
      def = GUNS[this.id];
    const s = this.s;
    st.ads = ME.adsK;
    st.sprint = damp(st.sprint, ME.sprinting ? 1 : 0, 10, dt);
    const busy = W.knifeT > 0 || W.nadeT > 0 || W.drinkT > 0 || W.repairing || ME.down;
    st.lowered = damp(st.lowered, W.drinkT > 0 || W.repairing || curW().inPress ? 1 : 0, 10, dt);
    if (this.pap && MAT.papMetal.map) {
      MAT.papMetal.map.offset.x += dt * 0.03;
      MAT.papMetal.map.offset.y += dt * 0.017;
      MAT.papMetal.emissiveIntensity = 0.55 + Math.sin(performance.now() * 0.004) * 0.25;
    }
    if (r.bellows) {
      r.bellows.scale.z = 1 - st.kick * 0.25;
    }
    const hip = [0.12, -0.125, -0.3],
      ads = [0, -r.sight[0] * s, -0.23 - r.sight[1] * s];
    let px = lerp(hip[0], ads[0], st.ads),
      py = lerp(hip[1], ads[1], st.ads),
      pz = lerp(hip[2], ads[2], st.ads),
      rx = 0,
      ry = 0,
      rz = 0;
    const mv = ME.moveK,
      bobA = (SET.video.bob ? 1 : 0.3) * (1 - st.ads * 0.85);
    st.bob += dt * (ME.sprinting ? 12 : 8.5) * Math.max(0.15, mv);
    const breathe = Math.sin(performance.now() * 0.0017) * 0.0025 * (1 - st.ads * 0.7);
    px += Math.cos(st.bob * 0.5) * 0.008 * mv * bobA;
    py += (Math.abs(Math.sin(st.bob * 0.5)) * -0.008 * mv + breathe) * bobA;
    rz += Math.cos(st.bob * 0.5) * 0.02 * mv * bobA;
    st.swayX = damp(st.swayX, clamp(-IN.lookDX * 0.0025, -0.08, 0.08), 8, dt);
    st.swayY = damp(st.swayY, clamp(-IN.lookDY * 0.0025, -0.08, 0.08), 8, dt);
    ry += st.swayX * (1 - st.ads * 0.7);
    rx += st.swayY * (1 - st.ads * 0.7);
    px += st.swayX * 0.12 * (1 - st.ads);
    const sp = st.sprint * (1 - st.ads);
    px += sp * 0.04;
    py -= sp * 0.04;
    rx -= sp * 0.35;
    ry += sp * 0.75;
    rz += sp * 0.15;
    px += Math.sin(st.bob) * 0.02 * sp;
    py += Math.abs(Math.cos(st.bob)) * 0.015 * sp;
    st.land = damp(st.land, 0, 8, dt);
    py -= st.land * 0.03;
    st.kick = damp(st.kick, 0, 14, dt);
    st.roll = damp(st.roll, 0, 10, dt);
    pz += st.kick * 0.045 * (1 - st.ads * 0.4);
    rx += st.kick * (def.recoil * 3.5 + 0.03) * (1 - st.ads * 0.5);
    rz += st.roll;
    py += st.kick * 0.006;
    const R = W.reload;
    let rk = 0;
    if (R) {
      rk = R.t / R.dur;
      if (R.type === 'mag') {
        const tilt = bell(rk, 0, 1);
        rz += tilt * 0.45;
        rx += tilt * 0.2;
        py -= tilt * 0.03;
        px -= tilt * 0.02;
        if (rk > 0.66 && rk < 0.82 && R.empty) {
          rx -= bell(rk, 0.66, 0.82) * 0.12;
        }
      } else if (R.type === 'shell') {
        const tilt = R.stage === 'in' ? smooth(R.st / R.sd) : R.stage === 'out' ? 1 - smooth(R.st / R.sd) : 1;
        rz -= tilt * 0.6;
        rx += tilt * 0.25;
        py -= tilt * 0.02;
        px += tilt * 0.02;
      } else if (R.type === 'clip') {
        const tilt = bell(rk, 0, 1);
        rz += tilt * 0.3;
        rx += tilt * 0.12;
        py -= tilt * 0.02;
      }
      py += (1 - st.ads) * 0;
    }
    if (W.switchT > 0) {
      const k = W.switchT / W.switchDur;
      const low = k > 0.5 ? 1 - (k - 0.5) * 2 : k * 2;
      py -= (1 - low) * 0;
      const d = Math.sin(clamp(k, 0, 1) * Math.PI);
      py -= d * 0.28;
      rx -= d * 0.8;
    }
    if (W.knifeT > 0) {
      const k = 1 - W.knifeT / W.knifeDur;
      const d = bell(k, 0, 1);
      py -= d * 0.12;
      px += d * 0.06;
      rz -= d * 0.5;
    }
    if (W.nadeT > 0) {
      const k = 1 - W.nadeT / W.nadeDur;
      const d = bell(k, 0, 1);
      py -= d * 0.1;
      px += d * 0.05;
      rz -= d * 0.3;
    }
    py -= st.lowered * 0.32;
    rx -= st.lowered * 0.9;
    if (ME.down) {
      px += 0.02;
      py -= 0.02;
      rz += 0.08;
    }
    this.pivot.position.set(px, py, pz);
    this.pivot.rotation.set(rx, ry, rz);
    const H = r.homes;
    if (r.slide) {
      let o = 0;
      if (W.cycleT > 0) {
        o = bell(1 - W.cycleT / W.cycleDur, 0, 1) * 0.045;
      }
      if (curW().mag === 0 && !R) {
        o = 0.045;
      }
      if (R && R.type === 'mag' && R.empty) {
        o = rk < 0.78 ? 0.045 : 0.045 * (1 - seg(rk, 0.78, 0.84));
      }
      r.slide.position.z = H.slide.z + o;
    }
    if (r.bolt && H.bolt) {
      r.bolt.position.copy(H.bolt);
      r.bolt.rotation.copy(H.boltR);
      let lift = 0,
        back = 0;
      if (def.cycle === 'bolt' && W.cycleT > 0) {
        const k = 1 - W.cycleT / W.cycleDur;
        lift = seg(k, 0.12, 0.25) - seg(k, 0.7, 0.82);
        back = seg(k, 0.28, 0.42) - seg(k, 0.52, 0.66);
      }
      if (R && R.type === 'clip' && def.cycle === 'bolt') {
        lift = seg(rk, 0.05, 0.15) - seg(rk, 0.85, 0.95);
        back = seg(rk, 0.15, 0.25) - seg(rk, 0.75, 0.85);
      }
      if (R && R.type === 'clip' && def.cycle !== 'bolt') {
        back = seg(rk, 0.08, 0.2) - seg(rk, 0.8, 0.88);
      }
      if (R && R.type === 'mag' && R.empty) {
        back = seg(rk, 0.68, 0.74) - seg(rk, 0.76, 0.8);
      }
      if (this.id === 'longspear' && R) {
        r.bolt.rotation.x = -(seg(rk, 0.08, 0.2) - seg(rk, 0.8, 0.9)) * 1.1;
      } else {
        r.bolt.rotation.z = H.boltR.z + lift * 1.3;
        r.bolt.position.z = H.bolt.z + back * 0.075;
      }
    }
    if (r.pump) {
      let o = 0;
      if (W.cycleT > 0) {
        const k = 1 - W.cycleT / W.cycleDur;
        o = seg(k, 0.2, 0.45) - seg(k, 0.55, 0.85);
      }
      if (R && R.stage === 'out' && R.empty) {
        const k = R.st / R.sd;
        o = bell(k, 0.2, 0.9);
      }
      r.pump.position.z = H.pump.z + o * 0.085;
    }
    let magOff = 0,
      magVis = true;
    if (r.mag && R && R.type === 'mag') {
      if (rk < 0.2) {
        magOff = 0;
      } else if (rk < 0.38) {
        magOff = seg(rk, 0.2, 0.38) * 0.3;
      } else if (rk < 0.45) {
        magOff = 0.3;
        magVis = false;
      } else if (rk < 0.62) {
        magOff = (1 - seg(rk, 0.45, 0.62)) * 0.3;
      } else {
        magOff = 0;
      }
    }
    if (r.mag) {
      const d = r.magDir;
      r.mag.position.set(H.mag.x + d[0] * magOff, H.mag.y + d[1] * magOff, H.mag.z + d[2] * magOff);
      r.mag.visible = magVis;
    }
    if (r.clip && this.id !== 'marksman') {
      if (R && R.type === 'clip') {
        const k = seg(rk, 0.25, 0.6);
        r.clip.visible = rk > 0.2 && rk < 0.7;
        r.clip.position.set(
          H.clip.x,
          H.clip.y + (1 - k) * 0.08 + (this.id === 'karvel' ? 0.02 : 0),
          H.clip.z,
        );
      } else {
        r.clip.visible = this.id === 'mercer' && curW().mag > 0;
      }
    }
    if (r.shell) {
      r.shell.visible = !!(R && R.stage === 'load');
      if (r.shell.visible) {
        const k = R.st / R.sd;
        r.shell.position.set(0, -0.02 - (1 - seg(k, 0.2, 0.7)) * 0.05, -0.09 + seg(k, 0.5, 0.8) * 0.05);
      }
    }
    if (r.core) {
      r.core.material.color.setHSL(
        r.coreHue == null ? 0.07 : r.coreHue,
        1,
        0.55 + Math.sin(performance.now() * 0.01) * 0.12,
      );
    }
    if (W.flashT > 0) {
      W.flashT -= dt;
      this.flash.visible = true;
      this.flash.material.rotation = rand(0, TAU);
      const fs = rand(0.14, 0.24) / s;
      this.flash.scale.set(fs, fs, 1);
      vmFlash.intensity = 2.5;
    } else {
      this.flash.visible = false;
      vmFlash.intensity = 0;
    }
    this.pivot.updateMatrix();
    const M4 = this.pivot.matrix;
    const tRH = new THREE.Vector3(...r.rh).applyMatrix4(M4);
    let tLH = new THREE.Vector3(...r.lh);
    if (r.pump) {
      tLH.z = r.pump.position.z;
    }
    if (R && R.type === 'mag' && r.mag) {
      const mp = r.mag.position;
      const toMag = bell(rk, 0.12, 0.7);
      const off = new THREE.Vector3(mp.x, mp.y - 0.03, mp.z);
      if (rk > 0.38 && rk < 0.45) {
        off.set(-0.2, -0.4, 0.1);
      }
      tLH.lerp(off, clamp(toMag * 1.5, 0, 1));
      if (R.empty && rk > 0.64 && rk < 0.82 && (r.bolt || r.slide)) {
        const bp = r.bolt ? r.bolt.position : new THREE.Vector3(0, 0.03, 0.03);
        tLH.lerp(new THREE.Vector3(bp.x - 0.02, bp.y, bp.z), bell(rk, 0.64, 0.82));
      }
    }
    if (R && R.type === 'shell') {
      const k = R.stage === 'load' ? R.st / R.sd : 0;
      if (R.stage === 'load') {
        tLH.set(0, -0.07 + seg(k, 0.2, 0.7) * 0.04, -0.07);
        tLH.y -= bell(k, 0, 0.3) * 0.1;
      }
    }
    if (R && R.type === 'clip') {
      tLH.lerp(new THREE.Vector3(0, 0.09, 0.02), bell(rk, 0.15, 0.75));
    }
    tLH.applyMatrix4(M4);
    this.knife.visible = W.knifeT > 0;
    if (this.knife.visible) {
      const k = 1 - W.knifeT / W.knifeDur;
      const a = smooth(seg(k, 0.1, 0.55));
      this.knife.position.set(
        lerp(0.28, -0.18, a),
        lerp(-0.14, -0.2, a) + bell(k, 0.1, 0.55) * 0.06,
        lerp(-0.3, -0.38, a),
      );
      this.knife.rotation.set(-0.2, lerp(0.9, -1.2, a), lerp(-0.4, 0.6, a));
      tRH.copy(this.knife.position).add(new THREE.Vector3(0, -0.01, 0.05));
    }
    this.nade.visible = W.nadeT > 0 && 1 - W.nadeT / W.nadeDur < 0.55;
    if (W.nadeT > 0) {
      const k = 1 - W.nadeT / W.nadeDur;
      const up = smooth(seg(k, 0, 0.35)),
        thr = smooth(seg(k, 0.35, 0.55));
      tLH.set(lerp(-0.25, -0.12, up), lerp(-0.35, 0.02, up) - thr * 0.15, lerp(-0.1, 0.05, up) - thr * 0.5);
      this.nade.position.copy(tLH).add(new THREE.Vector3(0, 0.03, -0.03));
    }
    this.hammer.visible = W.repairing && st.lowered > 0.5;
    if (this.hammer.visible) {
      const h = Math.sin(W.hammerPh * TAU);
      this.hammer.position.set(0.12, -0.1 + h * 0.02, -0.33);
      this.hammer.rotation.set(-0.6 + h * 0.9, 0.2, -0.3);
      tRH.set(0.13, -0.2 + h * 0.03, -0.24);
    }
    if (this.bottle) {
      this.bottle.visible = W.drinkT > 0;
    }
    ME.drinkLean = 0;
    if (W.drinkT > 0 && this.bottle) {
      const k = 1 - W.drinkT / W.drinkDur,
        B = this.bottle,
        cap = B.userData.cap;
      const up = smooth(seg(k, 0, 0.12)),
        tip = smooth(seg(k, 0.3, 0.42)) - smooth(seg(k, 0.74, 0.86)),
        away = smooth(seg(k, 0.88, 1));
      B.position.set(
        lerp(0.2, 0.05, up) + away * 0.25 - tip * 0.04,
        lerp(-0.42, -0.16, up) + tip * 0.1 - away * 0.35,
        lerp(-0.34, -0.27, up) + tip * 0.13,
      );
      B.rotation.set(tip * 1.95 + away * 0.6, 0, lerp(-0.25, 0.12, up) - tip * 0.1 - away * 0.5);
      ME.drinkLean = tip;
      if (k < 0.2) {
        cap.visible = true;
        cap.position.set(0, 0.21, 0);
        cap.rotation.set(0, 0, 0);
        B.userData.flew = false;
      } else if (k < 0.6) {
        if (!B.userData.flew) {
          B.userData.flew = true;
          B.userData.cv = [rand(0.6, 0.9), 1.4, rand(-0.2, 0.2)];
        }
        const tt = (k - 0.2) * W.drinkDur;
        cap.position.set(
          B.userData.cv[0] * tt,
          0.21 + B.userData.cv[1] * tt - 4.9 * tt * tt,
          B.userData.cv[2] * tt,
        );
        cap.rotation.x = tt * 25;
        cap.visible = tt < 0.5;
      } else {
        cap.visible = false;
      }
      tRH.copy(B.position).add(new THREE.Vector3(0.02, 0.03, 0.05));
      const flick = bell(k, 0.12, 0.24);
      if (flick > 0) {
        tLH.lerp(B.position.clone().add(new THREE.Vector3(-0.02, 0.2 - tip * 0.1, 0)), flick);
      }
    }
    this.hR.position.copy(tRH);
    this.hL.position.copy(tLH);
    this.hR.rotation.copy(this.pivot.rotation);
    this.hL.rotation.copy(this.pivot.rotation);
    this.hL.rotation.z += 0.6;
    this.hL.visible = !(ME.down && false);
    this.placeArm(
      this.aR,
      new THREE.Vector3(0.24, -0.42, 0.15),
      this._tmp1 || (this._tmp1 = new THREE.Vector3()).copy(tRH).add(new THREE.Vector3(0, -0.01, 0.06)),
    );
    this.placeArm(
      this.aL,
      new THREE.Vector3(-0.26, -0.44, 0.08),
      (this._tmp2 || (this._tmp2 = new THREE.Vector3())).copy(tLH).add(new THREE.Vector3(0, -0.01, 0.06)),
    );
    const hideGun = GUNS[this.id].scope && st.ads > 0.92;
    this.pivot.visible = !curW().inPress;
    this.root.visible = !hideGun;
  },
};

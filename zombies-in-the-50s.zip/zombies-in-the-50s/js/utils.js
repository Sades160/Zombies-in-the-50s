'use strict';

const $ = (s, r = document) => r.querySelector(s);

const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

const rand = (a, b) => a + Math.random() * (b - a);

const randi = (a, b) => Math.floor(a + Math.random() * (b - a + 1));

const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

const lerp = (a, b, t) => a + (b - a) * t;

const pick = (a) => a[(Math.random() * a.length) | 0];

const damp = (a, b, l, dt) => a + (b - a) * (1 - Math.exp(-l * dt));

const TAU = Math.PI * 2;

const wrapA = (a) => {
  a = (a + Math.PI) % TAU;
  if (a < 0) {
    a += TAU;
  }
  return a - Math.PI;
};

const smooth = (t) => (t <= 0 ? 0 : t >= 1 ? 1 : t * t * (3 - 2 * t));

const seg = (k, a, b) => clamp((k - a) / (b - a), 0, 1);

const bell = (k, a, b) => Math.sin(seg(k, a, b) * Math.PI);

function mulberry(a) {
  return function () {
    a |= 0;
    a = (a + 1831565813) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const TOUCH = (() => {
  try {
    const ua = navigator.userAgent || '';
    const mobileUA =
      /Android|iPhone|iPad|iPod|Mobile|Silk|Kindle/i.test(ua) ||
      (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
    const coarse = matchMedia('(pointer: coarse)').matches && !matchMedia('(any-pointer: fine)').matches;
    return mobileUA || coarse;
  } catch (e) {
    return false;
  }
})();

const REDUCED = (() => {
  try {
    return matchMedia('(prefers-reduced-motion: reduce)').matches;
  } catch (e) {
    return false;
  }
})();

const store = {
  get(k, d) {
    try {
      const v = localStorage.getItem(k);
      return v == null ? d : JSON.parse(v);
    } catch (e) {
      return d;
    }
  },
  set(k, v) {
    try {
      localStorage.setItem(k, JSON.stringify(v));
    } catch (e) {}
  },
};

const DEFAULTS = {
  video: {
    quality: 'medium',
    scale: 0.8,
    shadows: 'low',
    aa: true,
    bloom: false,
    dynres: true,
    fov: 80,
    bright: 1.12,
    grain: true,
    chroma: true,
    bob: true,
    fps: false,
  },
  audio: {
    master: 0.85,
    sfx: 1,
    music: 0.6,
    zombies: 1,
    voice: true,
  },
  controls: {
    sens: 1,
    padSens: 1,
    adsSens: 0.7,
    invertY: false,
    aimToggle: false,
    sprintToggle: false,
    crouchHold: false,
  },
  game: {
    name: '',
    crosshair: true,
    hitmarkers: true,
    tags: true,
  },
  keys: {
    forward: 'KeyW',
    back: 'KeyS',
    left: 'KeyA',
    right: 'KeyD',
    sprint: 'ShiftLeft',
    jump: 'Space',
    crouch: 'KeyC',
    prone: 'KeyZ',
    fire: 'Mouse0',
    aim: 'Mouse2',
    reload: 'KeyR',
    use: 'KeyF',
    melee: 'KeyV',
    grenade: 'KeyG',
    swap: 'KeyQ',
    weapon1: 'Digit1',
    weapon2: 'Digit2',
    flashlight: 'KeyL',
    scores: 'Tab',
  },
};

function deepMerge(a, b) {
  if (!b || typeof b !== 'object') {
    return a;
  }
  for (const k in a) {
    if (b[k] === undefined) {
      continue;
    }
    if (a[k] && typeof a[k] === 'object') {
      deepMerge(a[k], b[k]);
    } else if (typeof b[k] === typeof a[k]) {
      a[k] = b[k];
    }
  }
  return a;
}

const FIRST_RUN = store.get('z50_settings', null) === null;

const SET = deepMerge(JSON.parse(JSON.stringify(DEFAULTS)), store.get('z50_settings', {}));

if (FIRST_RUN && TOUCH) {
  Object.assign(SET.video, {
    quality: 'low',
    scale: 0.6,
    shadows: 'off',
    aa: false,
    bloom: false,
  });
}

if (!SET.game.name) {
  SET.game.name = 'Worker ' + randi(10, 99);
}

function saveSet() {
  store.set('z50_settings', SET);
}

const KEY_ACTIONS = [
  ['forward', 'Move forward'],
  ['back', 'Move back'],
  ['left', 'Strafe left'],
  ['right', 'Strafe right'],
  ['sprint', 'Sprint'],
  ['jump', 'Jump'],
  ['crouch', 'Crouch (hold for prone)'],
  ['prone', 'Prone'],
  ['fire', 'Fire'],
  ['aim', 'Aim down sights'],
  ['reload', 'Reload'],
  ['use', 'Use / buy / repair'],
  ['melee', 'Knife'],
  ['grenade', 'Throw grenade'],
  ['swap', 'Switch weapon'],
  ['weapon1', 'Primary weapon'],
  ['weapon2', 'Secondary weapon'],
  ['flashlight', 'Flashlight'],
  ['scores', 'Scoreboard (hold)'],
];

function keyLabel(c) {
  if (!c) {
    return 'Unbound';
  }
  if (c.startsWith('Key')) {
    return c.slice(3);
  }
  if (c.startsWith('Digit')) {
    return c.slice(5);
  }
  const m = {
    Mouse0: 'Left Mouse',
    Mouse1: 'Middle Mouse',
    Mouse2: 'Right Mouse',
    Mouse3: 'Mouse 4',
    Mouse4: 'Mouse 5',
    ShiftLeft: 'Left Shift',
    ShiftRight: 'Right Shift',
    ControlLeft: 'Left Ctrl',
    ControlRight: 'Right Ctrl',
    AltLeft: 'Left Alt',
    AltRight: 'Right Alt',
    Space: 'Space',
    Tab: 'Tab',
    CapsLock: 'Caps Lock',
    ArrowUp: 'Up Arrow',
    ArrowDown: 'Down Arrow',
    ArrowLeft: 'Left Arrow',
    ArrowRight: 'Right Arrow',
    Backquote: '`',
    Minus: '-',
    Equal: '=',
    BracketLeft: '[',
    BracketRight: ']',
    Semicolon: ';',
    Quote: "'",
    Comma: ',',
    Period: '.',
    Slash: '/',
    Backslash: '\\',
    Enter: 'Enter',
    Backspace: 'Backspace',
    WheelUp: 'Wheel Up',
    WheelDown: 'Wheel Down',
  };
  return m[c] || c.replace('Numpad', 'Num ');
}

function escapeHTML(s) {
  return String(s).replace(
    /[&<>"']/g,
    (c) =>
      ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;',
      })[c],
  );
}

function cleanName(s) {
  let t = String(s || '');
  try {
    t = t.replace(/[^\p{L}\p{N} _.\-']/gu, '');
  } catch (e) {
    t = t.replace(/[^A-Za-z0-9 _.\-']/g, '');
  }
  return t.trim().slice(0, 16) || 'Worker';
}

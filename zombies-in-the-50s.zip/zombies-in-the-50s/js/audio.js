const AU = (() => {
  let ctx = null,
    SR = 44100,
    master,
    bus = {},
    revIn,
    ready = false,
    readyP = null,
    noiseB = null;
  const B = {};
  const loops = {};
  let zVoices = 0;
  let musicLoopSrc = null;
  const L = {
    x: 0,
    y: 0,
    z: 0,
  };
  function nb() {
    if (noiseB) {
      return noiseB;
    }
    noiseB = new AudioBuffer({
      length: SR * 2,
      sampleRate: SR,
      numberOfChannels: 1,
    });
    const d = noiseB.getChannelData(0);
    for (let i = 0; i < d.length; i++) {
      d[i] = Math.random() * 2 - 1;
    }
    return noiseB;
  }
  function env(p, t, dur, peak, a) {
    p.setValueAtTime(1e-4, t);
    p.exponentialRampToValueAtTime(Math.max(2e-4, peak), t + Math.max(5e-4, a));
    p.exponentialRampToValueAtTime(1e-4, t + Math.max(dur, a + 0.002));
  }
  function N(c, d, t, dur, o = {}) {
    const s = c.createBufferSource();
    s.buffer = nb();
    s.loop = true;
    let n = s;
    if (o.hp) {
      const f = c.createBiquadFilter();
      f.type = 'highpass';
      f.frequency.value = o.hp;
      n.connect(f);
      n = f;
    }
    const f = c.createBiquadFilter();
    f.type = o.type || 'lowpass';
    f.frequency.setValueAtTime(o.f || 2e3, t);
    if (o.f2) {
      f.frequency.exponentialRampToValueAtTime(o.f2, t + (o.fd || dur));
    }
    f.Q.value = o.q == null ? 0.7 : o.q;
    n.connect(f);
    const g = c.createGain();
    if (o.flat) {
      g.gain.setValueAtTime(o.g == null ? 0.5 : o.g, t);
    } else {
      env(g.gain, t, dur, o.g == null ? 0.5 : o.g, o.a == null ? 0.002 : o.a);
    }
    f.connect(g);
    g.connect(d);
    s.start(t, Math.random() * 1.5);
    s.stop(t + dur + 0.05);
    return g;
  }
  function O(c, d, t, f, dur, o = {}) {
    const s = c.createOscillator();
    s.type = o.type || 'sine';
    s.frequency.setValueAtTime(f, t);
    if (o.f2) {
      s.frequency.exponentialRampToValueAtTime(o.f2, t + (o.fd || dur));
    }
    if (o.det) {
      s.detune.value = o.det;
    }
    const g = c.createGain();
    env(g.gain, t, dur, o.g == null ? 0.3 : o.g, o.a == null ? 0.003 : o.a);
    let n = s;
    if (o.lp) {
      const l = c.createBiquadFilter();
      l.type = 'lowpass';
      l.frequency.value = o.lp;
      s.connect(l);
      n = l;
    }
    n.connect(g);
    g.connect(d);
    s.start(t);
    s.stop(t + dur + 0.05);
    return s;
  }
  function WS(c, amt) {
    const w = c.createWaveShaper(),
      n = 2048,
      cv = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      const x = (i / (n - 1)) * 2 - 1;
      cv[i] = Math.tanh(x * amt) / Math.tanh(amt);
    }
    w.curve = cv;
    return w;
  }
  function Filt(c, type, f, q = 0.7) {
    const b = c.createBiquadFilter();
    b.type = type;
    b.frequency.value = f;
    b.Q.value = q;
    return b;
  }
  function normalize(b, peak) {
    let m = 0;
    for (let ch = 0; ch < b.numberOfChannels; ch++) {
      const d = b.getChannelData(ch);
      for (let i = 0; i < d.length; i++) {
        const a = Math.abs(d[i]);
        if (a > m) {
          m = a;
        }
      }
    }
    if (m < 1e-6) {
      return b;
    }
    const k = peak / m;
    for (let ch = 0; ch < b.numberOfChannels; ch++) {
      const d = b.getChannelData(ch);
      for (let i = 0; i < d.length; i++) {
        d[i] *= k;
      }
    }
    return b;
  }
  async function R(dur, fn, ch = 1, peak = 0.9) {
    const c = new OfflineAudioContext(ch, Math.ceil(dur * SR), SR);
    const out = c.createGain();
    out.connect(c.destination);
    fn(c, out);
    const b = await c.startRendering();
    return normalize(b, peak);
  }
  const PACK = new Set();
  const waiting = [];
  async function def(name, n, dur, fn, ch, peak) {
    if (PACK.has(name)) {
      return;
    }
    const arr = [];
    for (let i = 0; i < n; i++) {
      arr.push(await R(typeof dur === 'function' ? dur(i) : dur, (c, o) => fn(c, o, i), ch, peak));
    }
    if (!PACK.has(name)) {
      B[name] = arr;
    }
    flushWaiting();
  }
  function flushWaiting() {
    for (let i = waiting.length - 1; i >= 0; i--) {
      if (B[waiting[i][0]]) {
        const f = waiting[i][1];
        waiting.splice(i, 1);
        f();
      }
    }
  }
  function whenBuf(name, f) {
    if (B[name]) {
      f();
    } else {
      waiting.push([name, f]);
    }
  }
  async function loadPack() {
    if (window.Z50_NO_PACK) {
      return;
    }
    let man;
    try {
      const r = await fetch('sounds/manifest.json', {
        cache: 'no-cache',
      });
      if (!r.ok) {
        return;
      }
      man = await r.json();
    } catch (e) {
      return;
    }
    for (const name in man) {
      const files = [].concat(man[name]).filter((f) => typeof f === 'string');
      if (!files.length) {
        continue;
      }
      PACK.add(name);
      const bufs = [];
      for (const f of files) {
        try {
          const ab = await (await fetch('sounds/' + f)).arrayBuffer();
          bufs.push(await ctx.decodeAudioData(ab));
        } catch (e) {}
      }
      if (bufs.length) {
        B[name] = bufs;
        flushWaiting();
      } else {
        PACK.delete(name);
      }
    }
  }
  const mtof = (m) => 440 * Math.pow(2, (m - 69) / 12);
  const clk = (c, o, t, f, g = 0.5, d = 0.018) =>
    N(c, o, t, d, {
      type: 'bandpass',
      f: f,
      q: 6,
      g: g,
    });
  const slide = (c, o, t, f, d, g = 0.25) =>
    N(c, o, t, d, {
      type: 'bandpass',
      f: f,
      f2: f * 0.6,
      q: 2,
      g: g,
      a: d * 0.3,
    });
  const GS = {
    pistol: {
      bf: 4200,
      bf2: 520,
      bd: 0.09,
      t0: 170,
      t1: 55,
      td: 0.09,
      tail: 1.1,
      dist: 5,
      mech: [
        [0.028, 3600],
        [0.05, 2200],
      ],
      crack: 0,
      bark: 1500,
      g: 1,
    },
    rifle: {
      bf: 6200,
      bf2: 300,
      bd: 0.16,
      t0: 115,
      t1: 36,
      td: 0.22,
      tail: 2.1,
      dist: 7,
      mech: [],
      crack: 1,
      bark: 1100,
      g: 1.1,
    },
    shotgun: {
      bf: 3e3,
      bf2: 190,
      bd: 0.26,
      t0: 85,
      t1: 30,
      td: 0.34,
      tail: 2,
      dist: 8,
      mech: [],
      crack: 0,
      bark: 700,
      g: 1.2,
    },
    smg: {
      bf: 3800,
      bf2: 650,
      bd: 0.06,
      t0: 200,
      t1: 80,
      td: 0.06,
      tail: 0.8,
      dist: 5,
      mech: [
        [0.022, 3300],
        [0.04, 2e3],
      ],
      crack: 0,
      bark: 1700,
      g: 0.9,
    },
    ar: {
      bf: 4600,
      bf2: 400,
      bd: 0.1,
      t0: 140,
      t1: 48,
      td: 0.12,
      tail: 1.5,
      dist: 6,
      mech: [
        [0.028, 3e3],
        [0.046, 1800],
      ],
      crack: 1,
      bark: 1200,
      g: 1,
    },
    semi: {
      bf: 5200,
      bf2: 340,
      bd: 0.13,
      t0: 130,
      t1: 42,
      td: 0.16,
      tail: 1.8,
      dist: 6.5,
      mech: [
        [0.035, 2800],
        [0.06, 1600],
      ],
      crack: 1,
      bark: 1100,
      g: 1.05,
    },
    lmg: {
      bf: 3800,
      bf2: 360,
      bd: 0.12,
      t0: 120,
      t1: 40,
      td: 0.15,
      tail: 1.6,
      dist: 6,
      mech: [
        [0.03, 2600],
        [0.05, 1500],
      ],
      crack: 1,
      bark: 1e3,
      g: 1,
    },
  };
  const REFL = [
    [0.009, -0.75, 0.5, 5200],
    [0.016, 0.8, 0.42, 4600],
    [0.027, -0.35, 0.34, 3800],
    [0.041, 0.55, 0.27, 3100],
    [0.058, -0.6, 0.2, 2500],
    [0.083, 0.3, 0.14, 2e3],
    [0.121, -0.15, 0.09, 1500],
  ];
  function gunshot(c, o, p) {
    const dry = c.createGain();
    const sat = WS(c, p.dist * 1.4 * rand(0.9, 1.1));
    dry.connect(sat);
    const hp = Filt(c, 'highpass', 25);
    sat.connect(hp);
    hp.connect(o);
    const t0 = p.crack ? 0.0015 : 0;
    if (p.crack) {
      N(c, dry, 0, 0.003, {
        type: 'highpass',
        f: 6e3,
        g: 1.6,
        a: 1e-4,
      });
    }
    N(c, dry, t0, 0.007, {
      type: 'highpass',
      f: 1400,
      g: 1.4,
      a: 1e-4,
    });
    N(c, dry, t0, p.bd * rand(0.9, 1.1), {
      f: p.bf * rand(0.9, 1.1),
      f2: p.bf2,
      q: 0.35,
      g: 1.3,
      a: 3e-4,
    });
    N(c, dry, t0, p.bd * 0.8, {
      type: 'bandpass',
      f: p.bark * rand(0.9, 1.1),
      q: 1.1,
      g: 0.7,
      a: 5e-4,
    });
    N(c, dry, t0, p.td * 1.5, {
      f: 240,
      f2: 70,
      q: 0.9,
      g: 1.5,
      a: 8e-4,
    });
    N(c, dry, t0, p.td * 2.4, {
      f: 95,
      q: 0.7,
      g: 1,
      a: 0.0015,
    });
    p.mech.forEach(([t, f]) => {
      N(c, o, t, 0.012, {
        type: 'bandpass',
        f: f * rand(0.95, 1.05),
        q: 7,
        g: 0.26,
      });
      N(c, o, t + 0.004, 0.009, {
        type: 'bandpass',
        f: f * 1.7,
        q: 9,
        g: 0.12,
      });
    });
    REFL.forEach(([dl, pan, gn, lp]) => {
      const d = c.createDelay(0.2);
      d.delayTime.value = dl * rand(0.9, 1.15);
      const f = Filt(c, 'lowpass', lp);
      const g = c.createGain();
      g.gain.value = gn * 0.75;
      const pn = c.createStereoPanner();
      pn.pan.value = pan;
      sat.connect(d);
      d.connect(f);
      f.connect(g);
      g.connect(pn);
      pn.connect(o);
    });
    [-0.7, 0.7].forEach((pan) => {
      const pn = c.createStereoPanner();
      pn.pan.value = pan;
      pn.connect(o);
      N(c, pn, 0.02, p.tail * rand(0.9, 1.1), {
        f: 1300,
        f2: 100,
        g: 0.22,
        a: 0.04,
        q: 0.4,
      });
      N(c, pn, 0.05, p.tail * 0.7, {
        type: 'bandpass',
        f: 380,
        q: 0.6,
        g: 0.1,
        a: 0.08,
      });
    });
    N(c, o, 0.01, p.tail * 0.6, {
      f: 70,
      g: 0.35,
      a: 0.03,
      q: 0.5,
    });
  }
  function ember(c, o) {
    const d = WS(c, 3);
    d.connect(o);
    const s = c.createOscillator();
    s.type = 'sawtooth';
    s.frequency.setValueAtTime(1600, 0);
    s.frequency.exponentialRampToValueAtTime(70, 0.35);
    const g = c.createGain();
    env(g.gain, 0, 0.42, 0.6, 0.002);
    const f = Filt(c, 'lowpass', 4e3, 4);
    s.connect(f);
    f.connect(g);
    g.connect(d);
    s.start(0);
    s.stop(0.45);
    O(c, d, 0, 900, 0.3, {
      type: 'square',
      f2: 50,
      g: 0.25,
    });
    N(c, o, 0, 0.35, {
      type: 'bandpass',
      f: 3500,
      f2: 600,
      q: 2,
      g: 0.4,
    });
    O(c, d, 0, 55, 0.4, {
      f2: 30,
      g: 0.8,
    });
    N(c, o, 0.05, 0.8, {
      type: 'bandpass',
      f: 900,
      q: 3,
      g: 0.1,
      a: 0.1,
    });
  }
  const VOW = {
    u: [450, 1e3, 2400],
    a: [760, 1150, 2500],
    o: [380, 760, 2350],
    e: [520, 1650, 2450],
    r: [480, 1300, 1700],
  };
  function voice(c, o, v) {
    const dur = v.dur;
    const osc = c.createOscillator();
    osc.type = 'sawtooth';
    const sub = c.createOscillator();
    sub.type = 'square';
    const steps = Math.ceil(dur * 30);
    osc.frequency.setValueAtTime(v.f0, 0);
    sub.frequency.setValueAtTime(v.f0 / 2, 0);
    for (let i = 1; i <= steps; i++) {
      const k = i / steps,
        f = lerp(v.f0, v.f1, Math.pow(k, 0.8)) * (1 + rand(-v.jit, v.jit));
      osc.frequency.linearRampToValueAtTime(f, k * dur);
      sub.frequency.linearRampToValueAtTime(f * 0.5 * (1 + rand(-0.03, 0.03)), k * dur);
    }
    if (v.vib) {
      const l = c.createOscillator();
      l.frequency.value = v.vib;
      const lg = c.createGain();
      lg.gain.value = v.f0 * 0.05;
      l.connect(lg);
      lg.connect(osc.frequency);
      l.start(0);
      l.stop(dur);
    }
    const src = c.createGain();
    osc.connect(src);
    const sg = c.createGain();
    sg.gain.value = v.sub == null ? 0.4 : v.sub;
    sub.connect(sg);
    sg.connect(src);
    N(c, src, 0, dur, {
      type: 'bandpass',
      f: 1300,
      q: 0.6,
      g: v.breath || 0.3,
      a: dur * 0.2,
    });
    const ws = WS(c, v.rough || 3);
    src.connect(ws);
    const fsum = c.createGain();
    const fs = v.fs || 1;
    for (let k = 0; k < 3; k++) {
      const bp = c.createBiquadFilter();
      bp.type = 'bandpass';
      bp.Q.value = [6, 9, 12][k];
      bp.frequency.setValueAtTime(VOW[v.vow[0]][k] * fs, 0);
      v.vow.forEach((w, i) => {
        if (i) {
          bp.frequency.linearRampToValueAtTime(VOW[w][k] * fs, (dur * i) / (v.vow.length - 1));
        }
      });
      const g = c.createGain();
      g.gain.value = [1, 0.7, 0.35][k] * 3;
      ws.connect(bp);
      bp.connect(g);
      g.connect(fsum);
    }
    const amp = c.createGain();
    amp.gain.setValueAtTime(1e-4, 0);
    amp.gain.exponentialRampToValueAtTime(1, Math.min(0.12, dur * 0.2));
    const sg2 = Math.ceil(dur * 12);
    for (let i = 1; i < sg2; i++) {
      amp.gain.linearRampToValueAtTime(rand(0.45, 1), (i / sg2) * dur * 0.9);
    }
    amp.gain.exponentialRampToValueAtTime(1e-4, dur);
    if (v.flutter) {
      const fl = c.createOscillator();
      fl.frequency.value = v.flutter;
      const fg = c.createGain();
      fg.gain.value = 0.45;
      fl.connect(fg);
      fg.connect(amp.gain);
      fl.start(0);
      fl.stop(dur);
    }
    fsum.connect(amp);
    amp.connect(o);
    osc.start(0);
    sub.start(0);
    osc.stop(dur);
    sub.stop(dur);
  }
  function pad(c, o, t, notes, dur, g = 0.08, cut = 700) {
    const f = Filt(c, 'lowpass', cut, 0.8);
    const gg = c.createGain();
    gg.gain.setValueAtTime(1e-4, t);
    gg.gain.exponentialRampToValueAtTime(g, t + dur * 0.35);
    gg.gain.setValueAtTime(g, t + dur * 0.7);
    gg.gain.exponentialRampToValueAtTime(1e-4, t + dur + 0.5);
    f.connect(gg);
    gg.connect(o);
    notes.forEach((m) =>
      [-7, 6].forEach((det) => {
        const s = c.createOscillator();
        s.type = 'sawtooth';
        s.frequency.value = mtof(m);
        s.detune.value = det;
        s.connect(f);
        s.start(t);
        s.stop(t + dur + 0.6);
      }),
    );
  }
  function mbox(c, o, t, m, g = 0.2) {
    const f = mtof(m);
    O(c, o, t, f, 1.6, {
      g: g,
      a: 0.002,
    });
    O(c, o, t, f * 4, 0.5, {
      g: g * 0.25,
      a: 0.002,
    });
    O(c, o, t, f * 6.1, 0.2, {
      g: g * 0.08,
      a: 0.001,
    });
  }
  function piano(c, o, t, m, g = 0.25, d = 2.2) {
    const f = mtof(m);
    O(c, o, t, f, d, {
      type: 'triangle',
      g: g,
      a: 0.003,
    });
    O(c, o, t, f * 2, d * 0.5, {
      g: g * 0.3,
      a: 0.003,
    });
    O(c, o, t, f * 3.01, d * 0.25, {
      g: g * 0.12,
    });
    N(c, o, t, 0.03, {
      type: 'bandpass',
      f: f * 4,
      q: 3,
      g: g * 0.2,
    });
  }
  function bellM(c, o, t, m, g = 0.2, d = 3) {
    const f = mtof(m);
    O(c, o, t, f, d, {
      g: g,
    });
    O(c, o, t, f * 2.76, d * 0.5, {
      g: g * 0.35,
    });
    O(c, o, t, f * 5.4, d * 0.22, {
      g: g * 0.12,
    });
    O(c, o, t, f * 0.5, d * 0.8, {
      g: g * 0.2,
    });
  }
  function organ(c, o, t, m, d, g = 0.12) {
    const f = mtof(m);
    [
      [1, 1],
      [2, 0.5],
      [3, 0.28],
      [4, 0.12],
    ].forEach(([h, a]) =>
      O(c, o, t, f * h, d, {
        g: g * a,
        a: 0.01,
      }),
    );
  }
  function crackle(c, o, dur, g = 0.05) {
    for (let t = 0; t < dur; t += rand(0.02, 0.18)) {
      N(c, o, t, 0.006, {
        type: 'highpass',
        f: 2500,
        g: g * rand(0.3, 1.4),
        a: 5e-4,
      });
    }
    N(c, o, 0, dur, {
      type: 'bandpass',
      f: 3e3,
      q: 0.5,
      g: g * 0.25,
      flat: true,
    });
  }
  function laugh(c, o) {
    const out = c.createGain();
    out.gain.value = 0.9;
    out.connect(o);
    const dly = c.createDelay(1);
    dly.delayTime.value = 0.23;
    const fb = c.createGain();
    fb.gain.value = 0.38;
    const dl = Filt(c, 'lowpass', 1600);
    out.connect(dly);
    dly.connect(dl);
    dl.connect(fb);
    fb.connect(dly);
    const wet = c.createStereoPanner();
    wet.pan.value = 0.5;
    dl.connect(wet);
    wet.connect(o);
    const syl = [
      [0, 0.26, 118],
      [0.3, 0.22, 112],
      [0.55, 0.22, 106],
      [0.8, 0.24, 100],
      [1.08, 0.26, 92],
      [1.4, 0.3, 84],
      [1.8, 0.9, 70],
    ];
    syl.forEach(([t, d, f0], i) => {
      const pn = c.createStereoPanner();
      pn.pan.value = i % 2 ? 0.25 : -0.25;
      pn.connect(out);
      const node = c.createGain();
      const sh = c.createDelay(3);
      sh.delayTime.value = t;
      node.connect(sh);
      sh.connect(pn);
      voice(c, node, {
        f0: f0,
        f1: f0 * (i === syl.length - 1 ? 0.6 : 0.85),
        dur: d,
        jit: 0.06,
        rough: 4,
        vow: i === syl.length - 1 ? ['a', 'o', 'u'] : ['e', 'a'],
        breath: 0.9,
        sub: 0.6,
        fs: 0.82,
      });
      voice(c, node, {
        f0: f0 / 2,
        f1: f0 * 0.4,
        dur: d,
        jit: 0.05,
        rough: 6,
        vow: ['a', 'u'],
        breath: 0.5,
        sub: 0.8,
        fs: 0.7,
      });
    });
    N(c, out, 2.6, 2, {
      type: 'bandpass',
      f: 600,
      q: 0.7,
      g: 0.15,
      a: 0.6,
    });
  }
  function menuTheme(c, o) {
    const L = c.createStereoPanner(),
      Rp = c.createStereoPanner();
    L.pan.value = -0.5;
    Rp.pan.value = 0.5;
    L.connect(o);
    Rp.connect(o);
    const ch = [
      [38, 41, 45, 50],
      [34, 41, 46, 50],
      [31, 38, 43, 46],
      [33, 40, 45, 49],
    ];
    for (let i = 0; i < 8; i++) {
      pad(c, o, i * 4, ch[i % 4], 4.3, 0.045, 480);
      O(c, o, i * 4, mtof(ch[i % 4][0] - 12), 4.2, {
        type: 'sawtooth',
        g: 0.05,
        lp: 160,
        a: 1.2,
      });
      O(c, o, i * 4, mtof(ch[i % 4][0] - 11), 4.2, {
        type: 'sawtooth',
        g: 0.025,
        lp: 200,
        a: 2,
      });
    }
    const mel = [
      69, 0, 65, 64, 62, 0, 0, 0, 69, 70, 69, 67, 65, 0, 64, 0, 62, 65, 69, 74, 73, 0, 69, 0, 67, 65, 64, 0,
      62, 0, 0, 0,
    ];
    mel.forEach((m, i) => {
      if (!m) {
        return;
      }
      const t = i + 0.02 + rand(-0.04, 0.06);
      const f = mtof(m + 12) * (1 + rand(-0.012, 0.012));
      const s1 = c.createOscillator();
      s1.frequency.setValueAtTime(f, t);
      s1.frequency.linearRampToValueAtTime(f * 0.985, t + 1.5);
      const lf = c.createOscillator();
      lf.frequency.value = 5.5;
      const lg = c.createGain();
      lg.gain.value = f * 0.006;
      lf.connect(lg);
      lg.connect(s1.frequency);
      const g = c.createGain();
      env(g.gain, t, 1.9, 0.13, 0.002);
      s1.connect(g);
      g.connect(i % 2 ? L : Rp);
      s1.start(t);
      lf.start(t);
      s1.stop(t + 2);
      lf.stop(t + 2);
      O(c, i % 2 ? Rp : L, t + 0.33, f * 2.01, 0.5, {
        g: 0.02,
      });
    });
    for (let k = 0; k < 4; k++) {
      const t0 = 3 + k * 8;
      N(c, k % 2 ? L : Rp, t0, 3.2, {
        type: 'bandpass',
        f: 700,
        f2: 3500,
        fd: 3,
        q: 0.8,
        g: 0.1,
        a: 3,
      });
    }
    for (let k = 0; k < 6; k++) {
      const t0 = rand(1, 30);
      N(c, k % 2 ? L : Rp, t0, 1.2, {
        type: 'bandpass',
        f: rand(900, 1500),
        q: 6,
        g: 0.05,
        a: 0.4,
      });
      N(c, k % 2 ? L : Rp, t0 + 0.2, 1, {
        type: 'bandpass',
        f: rand(2200, 2800),
        q: 8,
        g: 0.035,
        a: 0.3,
      });
    }
    for (let k = 0; k < 5; k++) {
      const t0 = 6 + k * 6.3;
      O(c, o, t0, 55, 0.14, {
        g: 0.35,
      });
      O(c, o, t0 + 0.22, 49, 0.16, {
        g: 0.25,
      });
    }
    crackle(c, o, 32, 0.03);
  }
  function endTheme(c, o) {
    const L = c.createStereoPanner(),
      Rp = c.createStereoPanner();
    L.pan.value = -0.45;
    Rp.pan.value = 0.45;
    L.connect(o);
    Rp.connect(o);
    const chords = [
      [38, 45, 50, 53],
      [34, 41, 46, 50],
      [36, 43, 48, 51],
      [33, 40, 45, 49],
    ];
    chords.forEach((ch, i) => {
      pad(c, o, i * 3.6, ch, 3.8, 0.06, 520);
      ch.forEach((m) => {
        const t = i * 3.6;
        const s1 = c.createOscillator();
        s1.type = 'sawtooth';
        s1.frequency.value = mtof(m + 12);
        const f1 = Filt(c, 'bandpass', 450, 5),
          f2 = Filt(c, 'bandpass', 900, 7);
        const g = c.createGain();
        g.gain.setValueAtTime(1e-4, t);
        g.gain.exponentialRampToValueAtTime(0.05, t + 1.2);
        g.gain.exponentialRampToValueAtTime(1e-4, t + 3.9);
        s1.connect(f1);
        s1.connect(f2);
        f1.connect(g);
        f2.connect(g);
        g.connect(i % 2 ? L : Rp);
        s1.start(t);
        s1.stop(t + 4);
      });
    });
    [74, 72, 69, 65, 64, 62, 61, 62].forEach((m, i) =>
      bellM(c, i % 2 ? L : Rp, 0.4 + i * 1.75, m - 12, 0.18, 4),
    );
    O(c, o, 0, 36.7, 15, {
      type: 'sawtooth',
      g: 0.08,
      lp: 140,
      a: 2,
    });
    N(c, o, 13.5, 2.4, {
      f: 120,
      g: 0.4,
      a: 0.8,
    });
    crackle(c, o, 15.5, 0.03);
  }
  async function buildAll() {
    await def('ui_hover', 3, 0.3, (c, o) => {
      N(c, o, 0, 0.03, {
        type: 'bandpass',
        f: rand(1800, 2600),
        q: 5,
        g: 0.5,
      });
      N(c, o, 0.01, 0.22, {
        type: 'bandpass',
        f: 400,
        f2: 180,
        q: 3,
        g: 0.25,
        a: 0.02,
      });
    });
    await def('ui_click', 2, 1.4, (c, o) => {
      const d = WS(c, 3);
      d.connect(o);
      N(c, d, 0, 0.5, {
        f: 180,
        g: 1.2,
      });
      N(c, d, 0, 0.05, {
        type: 'bandpass',
        f: 1800,
        q: 3,
        g: 0.8,
      });
      const f0 = rand(380, 460);
      O(c, o, 0, f0, 1.1, {
        g: 0.12,
      });
      O(c, o, 0, f0 * 1.51, 0.8, {
        g: 0.07,
      });
      O(c, o, 0, f0 * 2.37, 0.5, {
        g: 0.04,
      });
      N(c, o, 0.02, 1.2, {
        type: 'bandpass',
        f: 800,
        f2: 200,
        q: 0.6,
        g: 0.12,
        a: 0.05,
      });
    });
    await def('ui_back', 1, 0.8, (c, o) => {
      N(c, o, 0, 0.6, {
        type: 'bandpass',
        f: 300,
        f2: 1600,
        fd: 0.5,
        q: 1.2,
        g: 0.6,
        a: 0.5,
      });
      N(c, o, 0.55, 0.15, {
        f: 150,
        g: 0.7,
      });
    });
    await def('ui_start', 1, 4, (c, o) => {
      const d = WS(c, 4);
      d.connect(o);
      N(c, d, 0, 2.5, {
        f: 120,
        g: 1.3,
        a: 0.005,
      });
      N(c, o, 0, 3, {
        type: 'bandpass',
        f: 900,
        f2: 120,
        q: 0.5,
        g: 0.4,
        a: 0.01,
      });
      [38, 39, 45].forEach((m) =>
        O(c, o, 0, mtof(m), 3.5, {
          type: 'sawtooth',
          g: 0.08,
          lp: 500,
          a: 0.02,
        }),
      );
    });
    await def('laugh', 2, 5.5, (c, o) => laugh(c, o), 2, 0.95);
    await def('mus_menu', 1, 32.5, (c, o) => menuTheme(c, o), 2, 0.8);
    await def('mus_over', 1, 16, (c, o) => endTheme(c, o), 2, 0.85);
    for (const k in GS) {
      await def('gun_' + k, 4, GS[k].tail + 0.25, (c, o) => gunshot(c, o, GS[k]), 2, 0.95);
    }
    await def('gun_ember', 2, 1, (c, o) => ember(c, o));
    await def(
      'gun_nebula',
      3,
      0.8,
      (c, o) => {
        const s1 = c.createOscillator();
        s1.type = 'sawtooth';
        s1.frequency.setValueAtTime(2600, 0);
        s1.frequency.exponentialRampToValueAtTime(260, 0.22);
        const f = Filt(c, 'bandpass', 1800, 2);
        const g = c.createGain();
        env(g.gain, 0, 0.3, 0.5, 0.002);
        s1.connect(f);
        f.connect(g);
        g.connect(o);
        s1.start(0);
        s1.stop(0.32);
        O(c, o, 0, 1300, 0.18, {
          type: 'square',
          f2: 180,
          g: 0.12,
        });
        N(c, o, 0, 0.25, {
          type: 'bandpass',
          f: 4200,
          f2: 900,
          q: 2,
          g: 0.35,
        });
        N(c, o, 0, 0.12, {
          f: 160,
          g: 0.6,
        });
        N(c, o, 0.05, 0.6, {
          type: 'bandpass',
          f: 2600,
          q: 6,
          g: 0.06,
          a: 0.05,
        });
      },
      2,
    );
    await def('orb_hit', 2, 0.8, (c, o) => {
      N(c, o, 0, 0.5, {
        f: 2200,
        f2: 200,
        g: 0.8,
      });
      O(c, o, 0, 900, 0.3, {
        type: 'sawtooth',
        f2: 90,
        g: 0.12,
        lp: 2500,
      });
      N(c, o, 0, 0.2, {
        f: 120,
        g: 0.7,
      });
    });
    await def(
      'gun_gale',
      2,
      2.2,
      (c, o) => {
        const d = WS(c, 3);
        d.connect(o);
        N(c, d, 0, 0.5, {
          f: 140,
          g: 1.3,
          a: 0.004,
        });
        N(c, d, 0, 0.9, {
          type: 'bandpass',
          f: 240,
          f2: 2400,
          fd: 0.12,
          q: 0.8,
          g: 1,
          a: 0.01,
        });
        N(c, o, 0.1, 1.8, {
          type: 'bandpass',
          f: 1600,
          f2: 300,
          q: 0.5,
          g: 0.35,
          a: 0.05,
        });
        N(c, o, 0.15, 1.9, {
          type: 'bandpass',
          f: 600,
          f2: 200,
          q: 0.6,
          g: 0.3,
          a: 0.2,
        });
        for (let i = 0; i < 8; i++) {
          N(c, o, rand(0.1, 1.2), 0.08, {
            type: 'bandpass',
            f: rand(800, 2500),
            q: 3,
            g: 0.1,
          });
        }
      },
      2,
    );
    await def(
      'gun_volt',
      2,
      1.1,
      (c, o) => {
        for (let i = 0; i < 26; i++) {
          N(c, o, rand(0, 0.5), rand(0.005, 0.03), {
            type: 'highpass',
            f: rand(2500, 6e3),
            g: rand(0.4, 1),
            a: 5e-4,
          });
        }
        const s1 = c.createOscillator();
        s1.type = 'sawtooth';
        s1.frequency.value = 118;
        const f = Filt(c, 'lowpass', 1800);
        const g = c.createGain();
        env(g.gain, 0, 0.8, 0.35, 0.01);
        s1.connect(f);
        f.connect(g);
        g.connect(o);
        s1.start(0);
        s1.stop(0.85);
        N(c, o, 0, 0.08, {
          f: 180,
          g: 0.8,
        });
      },
      2,
    );
    await def('zap', 4, 0.35, (c, o) => {
      for (let i = 0; i < 8; i++) {
        N(c, o, rand(0, 0.15), rand(0.004, 0.02), {
          type: 'highpass',
          f: rand(3e3, 7e3),
          g: rand(0.4, 1),
        });
      }
      N(c, o, 0, 0.2, {
        type: 'bandpass',
        f: 1200,
        q: 2,
        g: 0.3,
      });
    });
    await def('pap_layer', 2, 0.9, (c, o) => {
      N(c, o, 0.01, 0.7, {
        type: 'bandpass',
        f: 3200,
        f2: 800,
        q: 4,
        g: 0.3,
        a: 0.02,
      });
      const s1 = c.createOscillator();
      s1.frequency.setValueAtTime(1800, 0);
      s1.frequency.exponentialRampToValueAtTime(420, 0.5);
      const g = c.createGain();
      env(g.gain, 0, 0.55, 0.08, 0.01);
      s1.connect(g);
      g.connect(o);
      s1.start(0);
      s1.stop(0.6);
    });
    await def('press_start', 1, 1.6, (c, o) => {
      N(c, o, 0, 0.3, {
        f: 400,
        g: 1,
      });
      for (let i = 0; i < 3; i++) {
        clk(c, o, 0.05 + i * 0.06, 1800, 0.5, 0.03);
      }
      N(c, o, 0.3, 1.2, {
        type: 'highpass',
        f: 3e3,
        g: 0.35,
        a: 0.1,
      });
      N(c, o, 0.2, 1.2, {
        f: 90,
        g: 0.5,
        a: 0.2,
      });
    });
    await def('press_stamp', 3, 0.9, (c, o) => {
      const d = WS(c, 3);
      d.connect(o);
      N(c, d, 0, 0.25, {
        f: 300,
        g: 1.2,
      });
      N(c, d, 0, 0.5, {
        f: 80,
        g: 1,
      });
      const f0 = rand(900, 1300);
      O(c, o, 0.002, f0, 0.5, {
        g: 0.12,
      });
      O(c, o, 0.002, f0 * 1.63, 0.35, {
        g: 0.06,
      });
      N(c, o, 0.08, 0.6, {
        type: 'highpass',
        f: 3500,
        g: 0.25,
        a: 0.05,
      });
    });
    await def('press_done', 1, 1.4, (c, o) => {
      [0, 0.12].forEach((t, i) => {
        O(c, o, t, [1568, 2093][i], 1, {
          g: 0.25,
        });
        O(c, o, t, [1568, 2093][i] * 2.76, 0.4, {
          g: 0.06,
        });
      });
      N(c, o, 0, 0.9, {
        type: 'highpass',
        f: 3e3,
        g: 0.2,
        a: 0.05,
      });
    });
    await def('candy_crank', 1, 1.3, (c, o) => {
      for (let i = 0; i < 14; i++) {
        clk(c, o, i * 0.07, rand(2200, 3e3), 0.35, 0.015);
      }
      for (let i = 0; i < 6; i++) {
        O(c, o, 0.9 + i * 0.05, rand(2500, 3800), 0.06, {
          g: 0.1,
        });
      }
      N(c, o, 1.05, 0.1, {
        f: 600,
        g: 0.4,
      });
    });
    await def('candy_get', 1, 1, (c, o) => {
      [84, 88, 91, 96].forEach((m, i) => mbox(c, o, i * 0.08, m, 0.18));
    });
    await def('casing', 4, 0.25, (c, o) => {
      const f = rand(4200, 6200);
      O(c, o, 0, f, 0.12, {
        g: 0.3,
      });
      O(c, o, 0, f * 1.47, 0.08, {
        g: 0.14,
      });
      O(c, o, 0, f * 2.1, 0.05, {
        g: 0.06,
      });
      N(c, o, 0, 0.01, {
        type: 'highpass',
        f: 6e3,
        g: 0.5,
      });
    });
    await def('hull', 2, 0.2, (c, o) => {
      N(c, o, 0, 0.05, {
        type: 'bandpass',
        f: 1400,
        q: 2,
        g: 0.6,
      });
      O(c, o, 0, 700, 0.04, {
        g: 0.15,
      });
    });
    await def('crawl', 3, 0.5, (c, o) => {
      N(c, o, 0, 0.4, {
        type: 'bandpass',
        f: 800,
        q: 0.6,
        g: 0.5,
        a: 0.12,
      });
      N(c, o, 0.05, 0.3, {
        type: 'bandpass',
        f: 2200,
        q: 1,
        g: 0.15,
        a: 0.1,
      });
    });
    await def('magout', 2, 0.2, (c, o) => {
      clk(c, o, 0, 2600, 0.6);
      slide(c, o, 0.01, 1400, 0.08);
      clk(c, o, 0.08, 1900, 0.5);
      N(c, o, 0.09, 0.05, {
        f: 500,
        g: 0.2,
      });
    });
    await def('magin', 2, 0.2, (c, o) => {
      slide(c, o, 0, 1100, 0.06);
      clk(c, o, 0.06, 1500, 0.9, 0.025);
      N(c, o, 0.06, 0.08, {
        f: 300,
        g: 0.5,
      });
      clk(c, o, 0.09, 2800, 0.4);
    });
    await def('boltback', 2, 0.22, (c, o) => {
      clk(c, o, 0, 2200, 0.7);
      slide(c, o, 0.02, 1800, 0.1);
      clk(c, o, 0.12, 1500, 0.5);
    });
    await def('boltfwd', 2, 0.22, (c, o) => {
      slide(c, o, 0, 1600, 0.08);
      clk(c, o, 0.08, 1300, 0.9);
      clk(c, o, 0.1, 2600, 0.5);
    });
    await def('pump', 2, 0.36, (c, o) => {
      slide(c, o, 0, 1200, 0.09);
      clk(c, o, 0.09, 1800, 0.7);
      slide(c, o, 0.16, 1e3, 0.08);
      clk(c, o, 0.24, 1400, 0.9);
    });
    await def('shell', 3, 0.18, (c, o) => {
      clk(c, o, 0, 3300, 0.4);
      slide(c, o, 0.02, 900, 0.07);
      clk(c, o, 0.08, 1700, 0.6);
    });
    await def('slidefwd', 2, 0.1, (c, o) => {
      clk(c, o, 0, 2e3, 0.9, 0.03);
      N(c, o, 0.005, 0.04, {
        type: 'bandpass',
        f: 900,
        q: 3,
        g: 0.3,
      });
    });
    await def('clipin', 1, 0.3, (c, o) => {
      slide(c, o, 0, 2e3, 0.15);
      clk(c, o, 0.1, 2500, 0.7);
      clk(c, o, 0.16, 1800, 0.8);
    });
    await def('dry', 2, 0.05, (c, o) => clk(c, o, 0, 4200, 0.8, 0.012));
    await def('raise', 2, 0.35, (c, o) => {
      N(c, o, 0, 0.25, {
        type: 'bandpass',
        f: 700,
        q: 0.8,
        g: 0.25,
        a: 0.08,
      });
      clk(c, o, 0.18, 2300, 0.4);
    });
    await def('flesh', 4, 0.22, (c, o) => {
      N(c, o, 0, 0.1, {
        f: 800,
        g: 1,
      });
      N(c, o, 0, 0.08, {
        f: 140,
        g: 0.8,
      });
      N(c, o, 0.01, 0.05, {
        type: 'bandpass',
        f: 1600,
        q: 2,
        g: 0.4,
      });
    });
    await def('headshot', 2, 0.3, (c, o) => {
      N(c, o, 0, 0.1, {
        f: 900,
        g: 1,
      });
      N(c, o, 0, 0.06, {
        type: 'bandpass',
        f: 2400,
        q: 3,
        g: 0.7,
      });
      N(c, o, 0, 0.12, {
        f: 110,
        g: 0.8,
      });
      N(c, o, 0.03, 0.2, {
        f: 500,
        g: 0.4,
        a: 0.02,
      });
    });
    await def('conc', 3, 0.25, (c, o) => {
      N(c, o, 0, 0.03, {
        type: 'highpass',
        f: 2500,
        g: 1,
      });
      N(c, o, 0, 0.12, {
        type: 'bandpass',
        f: 1100,
        q: 1,
        g: 0.4,
      });
      for (let i = 0; i < 3; i++) {
        clk(c, o, rand(0.03, 0.15), rand(2e3, 5e3), 0.12);
      }
    });
    await def('metal', 3, 0.4, (c, o) => {
      const f = rand(1500, 2200);
      O(c, o, 0, f, 0.3, {
        g: 0.25,
      });
      O(c, o, 0, f * 1.58, 0.22, {
        g: 0.12,
      });
      O(c, o, 0, f * 2.2, 0.16, {
        g: 0.06,
      });
      N(c, o, 0, 0.015, {
        type: 'highpass',
        f: 4e3,
        g: 0.8,
      });
    });
    await def('wood', 3, 0.2, (c, o) => {
      N(c, o, 0, 0.08, {
        type: 'bandpass',
        f: 850,
        q: 1.5,
        g: 0.8,
      });
      N(c, o, 0, 0.06, {
        f: 260,
        g: 0.4,
      });
    });
    await def('whoosh', 2, 0.25, (c, o) =>
      N(c, o, 0, 0.2, {
        type: 'bandpass',
        f: 2200,
        f2: 500,
        q: 1.3,
        g: 0.8,
        a: 0.07,
      }),
    );
    await def('knifehit', 2, 0.25, (c, o) => {
      N(c, o, 0, 0.18, {
        f: 600,
        g: 1,
      });
      N(c, o, 0, 0.1, {
        f: 150,
        g: 0.8,
      });
      N(c, o, 0.02, 0.06, {
        type: 'bandpass',
        f: 2800,
        q: 3,
        g: 0.5,
      });
    });
    await def('hitmark', 1, 0.06, (c, o) => {
      clk(c, o, 0, 2800, 0.5, 0.01);
      clk(c, o, 0.004, 4200, 0.25, 0.008);
    });
    const vs = [
      ['u', 'a', 'o'],
      ['o', 'u'],
      ['a', 'u', 'o'],
      ['u', 'r', 'u'],
      ['r', 'o'],
    ];
    await def(
      'z_groan',
      10,
      (i) => 2.3,
      (c, o, i) => {
        const f0 = rand(62, 108);
        voice(c, o, {
          f0: f0,
          f1: f0 * rand(0.68, 0.9),
          dur: rand(1.2, 2.2),
          jit: 0.05,
          rough: 3.5,
          vow: vs[i % vs.length],
          breath: 0.35,
          sub: 0.5,
          flutter: Math.random() < 0.5 ? rand(7, 14) : 0,
        });
      },
    );
    await def('z_growl', 6, 1, (c, o) => {
      const f0 = rand(92, 140);
      voice(c, o, {
        f0: f0,
        f1: f0 * 0.8,
        dur: rand(0.5, 0.9),
        jit: 0.12,
        rough: 9,
        vow: ['a', 'u'],
        breath: 0.5,
        sub: 0.7,
        flutter: rand(18, 30),
      });
    });
    await def('z_scream', 6, 1.2, (c, o) => {
      const f0 = rand(320, 470);
      voice(c, o, {
        f0: f0,
        f1: f0 * rand(0.6, 0.8),
        dur: rand(0.7, 1.1),
        jit: 0.08,
        rough: 7,
        vow: ['a', 'e', 'a'],
        vib: 7,
        breath: 0.6,
        fs: 1.15,
        sub: 0.25,
      });
    });
    await def('z_shriek', 6, 1.2, (c, o) => {
      const f0 = rand(480, 680);
      voice(c, o, {
        f0: f0,
        f1: f0 * rand(0.55, 0.75),
        dur: rand(0.6, 1),
        jit: 0.14,
        rough: 12,
        vow: ['e', 'a', 'e'],
        vib: 11,
        breath: 0.9,
        fs: 1.3,
        sub: 0.15,
        flutter: rand(20, 32),
      });
    });
    await def('z_pant', 4, 0.8, (c, o) => {
      for (let i = 0; i < 3; i++) {
        N(c, o, i * 0.22, 0.16, {
          type: 'bandpass',
          f: rand(700, 1100),
          q: 1.5,
          g: 0.5,
          a: 0.03,
        });
      }
    });
    await def('z_snarl', 5, 0.5, (c, o) =>
      voice(c, o, {
        f0: rand(160, 220),
        f1: 110,
        dur: 0.45,
        jit: 0.1,
        rough: 10,
        vow: ['e', 'a'],
        breath: 0.7,
        flutter: 25,
        sub: 0.6,
      }),
    );
    await def('z_death', 4, 1.2, (c, o) =>
      voice(c, o, {
        f0: rand(100, 125),
        f1: 45,
        dur: 1.1,
        jit: 0.08,
        rough: 5,
        vow: ['a', 'o', 'u'],
        flutter: 12,
        breath: 0.5,
        sub: 0.5,
      }),
    );
    await def('z_step', 4, 0.35, (c, o) => {
      N(c, o, 0, 0.3, {
        f: 500,
        g: 0.5,
        a: 0.08,
      });
      N(c, o, 0, 0.2, {
        type: 'bandpass',
        f: 1500,
        q: 0.7,
        g: 0.15,
        a: 0.06,
      });
      O(c, o, 0.05, 80, 0.08, {
        g: 0.3,
      });
    });
    await def('bodyfall', 3, 0.6, (c, o) => {
      N(c, o, 0, 0.5, {
        f: 300,
        g: 0.9,
      });
      O(c, o, 0, 60, 0.3, {
        f2: 35,
        g: 0.8,
      });
      N(c, o, 0.1, 0.15, {
        type: 'bandpass',
        f: 900,
        g: 0.3,
      });
    });
    await def('p_grunt', 3, 0.35, (c, o) =>
      voice(c, o, {
        f0: rand(130, 150),
        f1: 100,
        dur: 0.28,
        jit: 0.04,
        rough: 2,
        vow: ['u', 'a'],
        breath: 0.3,
        sub: 0.2,
      }),
    );
    await def('p_down', 1, 1.3, (c, o) =>
      voice(c, o, {
        f0: 150,
        f1: 80,
        dur: 1.2,
        jit: 0.05,
        rough: 2.5,
        vow: ['a', 'u', 'o'],
        breath: 0.5,
        sub: 0.3,
      }),
    );
    await def('rip', 4, 1, (c, o) => {
      const s = c.createOscillator();
      s.type = 'sawtooth';
      s.frequency.setValueAtTime(rand(160, 200), 0);
      s.frequency.linearRampToValueAtTime(rand(100, 120), 0.3);
      const bp = Filt(c, 'bandpass', rand(600, 900), 12);
      const g = c.createGain();
      env(g.gain, 0, 0.32, 0.5, 0.05);
      s.connect(bp);
      bp.connect(g);
      g.connect(o);
      s.start(0);
      s.stop(0.35);
      N(c, o, 0.28, 0.09, {
        type: 'bandpass',
        f: 2400,
        q: 2,
        g: 1,
      });
      N(c, o, 0.28, 0.15, {
        type: 'highpass',
        f: 4e3,
        g: 0.3,
      });
      N(c, o, 0.3, 0.25, {
        f: 500,
        g: 0.5,
      });
      for (let i = 0; i < 3; i++) {
        clk(c, o, rand(0.45, 0.85), rand(1200, 2600), 0.3, 0.03);
      }
    });
    await def('hammer', 2, 0.75, (c, o) => {
      N(c, o, 0, 0.12, {
        type: 'bandpass',
        f: 700,
        g: 0.5,
      });
      [0, 0.18, 0.36].forEach((t) => {
        O(c, o, t, 2100 * rand(0.95, 1.05), 0.09, {
          g: 0.2,
        });
        N(c, o, t, 0.025, {
          type: 'bandpass',
          f: 3800,
          q: 2,
          g: 0.9,
        });
        O(c, o, t, 160, 0.07, {
          f2: 90,
          g: 0.6,
        });
      });
    });
    await def('clear', 2, 1.8, (c, o) => {
      N(c, o, 0, 1.5, {
        f: 800,
        f2: 100,
        g: 1,
        a: 0.02,
      });
      O(c, o, 0, 55, 0.9, {
        f2: 30,
        g: 0.8,
      });
      for (let i = 0; i < 10; i++) {
        const t = rand(0.05, 1.3);
        clk(c, o, t, rand(800, 2400), 0.3, 0.04);
        N(c, o, t, 0.1, {
          type: 'bandpass',
          f: 500,
          g: 0.3,
        });
      }
    });
    await def('register', 1, 1, (c, o) => {
      [0, 0.01, 0.02, 0.03].forEach((t) => clk(c, o, t, 3e3, 0.3));
      N(c, o, 0.05, 0.3, {
        f: 900,
        g: 0.4,
      });
      O(c, o, 0.08, 2093, 0.9, {
        g: 0.35,
      });
      O(c, o, 0.08, 3140, 0.6, {
        g: 0.15,
      });
      O(c, o, 0.08, 4186, 0.3, {
        g: 0.08,
      });
    });
    await def('denied', 1, 0.4, (c, o) => {
      O(c, o, 0, 110, 0.35, {
        type: 'sawtooth',
        g: 0.3,
        lp: 900,
      });
      O(c, o, 0, 117, 0.35, {
        type: 'sawtooth',
        g: 0.3,
        lp: 900,
      });
    });
    await def('vend', 1, 1, (c, o) => {
      O(c, o, 0, 90, 0.2, {
        f2: 50,
        g: 0.8,
      });
      N(c, o, 0, 0.25, {
        f: 400,
        g: 0.6,
      });
      [0.25, 0.38, 0.5].forEach((t) =>
        O(c, o, t, 2700 * rand(0.9, 1.1), 0.05, {
          g: 0.15,
        }),
      );
      N(c, o, 0.6, 0.15, {
        f: 500,
        g: 0.7,
      });
    });
    await def('pop', 1, 1, (c, o) => {
      N(c, o, 0, 0.03, {
        type: 'bandpass',
        f: 2800,
        q: 3,
        g: 1,
      });
      N(c, o, 0.01, 0.9, {
        type: 'highpass',
        f: 5e3,
        g: 0.25,
        a: 0.02,
      });
    });
    await def('gulp', 1, 1.1, (c, o) => {
      [0, 0.33, 0.66].forEach((t) => {
        O(c, o, t, 170, 0.15, {
          f2: 110,
          g: 0.6,
        });
        N(c, o, t, 0.15, {
          f: 350,
          g: 0.5,
        });
      });
    });
    await def('smash', 2, 0.6, (c, o) => {
      N(c, o, 0, 0.35, {
        type: 'highpass',
        f: 3e3,
        g: 0.8,
      });
      for (let i = 0; i < 6; i++) {
        O(c, o, rand(0, 0.15), rand(2500, 5500), 0.15, {
          g: 0.15,
        });
      }
    });
    await def('lid', 1, 0.6, (c, o) => {
      const s = c.createOscillator();
      s.type = 'sawtooth';
      s.frequency.setValueAtTime(120, 0);
      s.frequency.linearRampToValueAtTime(190, 0.45);
      const bp = Filt(c, 'bandpass', 800, 10);
      const g = c.createGain();
      env(g.gain, 0, 0.5, 0.4, 0.1);
      s.connect(bp);
      bp.connect(g);
      g.connect(o);
      s.start(0);
      s.stop(0.5);
    });
    await def('crateThud', 1, 0.6, (c, o) => {
      N(c, o, 0, 0.4, {
        f: 350,
        g: 1,
      });
      O(c, o, 0, 70, 0.3, {
        f2: 40,
        g: 0.8,
      });
    });
    await def('lever', 1, 2.2, (c, o) => {
      N(c, o, 0, 0.3, {
        f: 400,
        g: 1,
      });
      O(c, o, 0, 70, 0.2, {
        g: 0.8,
      });
      N(c, o, 0.02, 0.05, {
        type: 'bandpass',
        f: 3e3,
        g: 0.6,
      });
      O(c, o, 0.2, 60, 1.8, {
        type: 'sawtooth',
        g: 0.25,
        a: 0.5,
        lp: 700,
      });
      O(c, o, 0.2, 120, 1.8, {
        type: 'sawtooth',
        g: 0.12,
        a: 0.6,
        lp: 900,
      });
      for (let i = 0; i < 5; i++) {
        N(c, o, 0.6 + i * 0.2, 0.04, {
          type: 'bandpass',
          f: 4e3,
          q: 4,
          g: 0.3,
        });
      }
    });
    await def('boom', 2, 2, (c, o) => {
      const d = WS(c, 4);
      d.connect(o);
      N(c, d, 0, 1.8, {
        f: 3500,
        f2: 90,
        g: 1,
      });
      N(c, d, 0, 1.4, {
        f: 90,
        g: 1.2,
        q: 0.6,
      });
      N(c, o, 0.05, 0.6, {
        type: 'bandpass',
        f: 700,
        g: 0.4,
      });
      for (let i = 0; i < 10; i++) {
        clk(c, o, rand(0.2, 1.3), rand(1500, 4e3), 0.15, 0.03);
      }
    });
    await def('pin', 1, 0.3, (c, o) => {
      clk(c, o, 0, 3500, 0.6);
      O(c, o, 0.02, 3e3, 0.2, {
        g: 0.1,
      });
    });
    await def('clink', 3, 0.15, (c, o) => {
      O(c, o, 0, 2200 * rand(0.9, 1.1), 0.08, {
        g: 0.3,
      });
      O(c, o, 0, 3300, 0.06, {
        g: 0.15,
      });
      clk(c, o, 0, 2500, 0.4);
    });
    await def('step', 6, 0.14, (c, o) => {
      N(c, o, 0, 0.09, {
        f: rand(700, 1e3),
        g: 0.7,
        a: 0.003,
      });
      N(c, o, 0, 0.03, {
        type: 'bandpass',
        f: 2600,
        q: 1.5,
        g: 0.25,
      });
      N(c, o, 0, 0.05, {
        f: 120,
        g: 0.3,
      });
    });
    await def('land', 1, 0.25, (c, o) => {
      N(c, o, 0, 0.15, {
        f: 400,
        g: 0.9,
      });
      N(c, o, 0, 0.1, {
        f: 100,
        g: 0.6,
      });
    });
    await def('heart', 1, 0.45, (c, o) => {
      O(c, o, 0, 60, 0.12, {
        g: 0.8,
      });
      O(c, o, 0.2, 52, 0.14, {
        g: 0.6,
      });
    });
    await def('breath', 2, 1.5, (c, o) => {
      N(c, o, 0, 0.7, {
        type: 'bandpass',
        f: 1100,
        q: 0.7,
        g: 0.5,
        a: 0.3,
      });
      N(c, o, 0.8, 0.6, {
        type: 'bandpass',
        f: 900,
        q: 0.7,
        g: 0.4,
        a: 0.1,
      });
    });
    await def('pw_spawn', 1, 1.4, (c, o) => {
      [880, 1108, 1318].forEach((f) =>
        O(c, o, 0, f, 1.3, {
          g: 0.15,
          a: 0.2,
        }),
      );
      N(c, o, 0, 1.3, {
        type: 'highpass',
        f: 7e3,
        g: 0.08,
        a: 0.5,
      });
    });
    await def('pw_get', 1, 1.4, (c, o) => {
      [72, 76, 79, 84, 88].forEach((m, i) => organ(c, o, i * 0.07, m, 0.5, 0.12));
      N(c, o, 0, 0.8, {
        type: 'highpass',
        f: 6e3,
        g: 0.15,
        a: 0.5,
      });
    });
    await def('crate_music', 1, 5.4, (c, o) => {
      const sc = [72, 74, 76, 79, 81, 84, 86, 88];
      let t = 0,
        gap = 0.13;
      while (t < 5) {
        mbox(c, o, t, pick(sc), 0.16);
        t += gap;
        gap *= 1.03;
      }
      for (let i = 0; i < 12; i++) {
        clk(c, o, rand(0, 4), rand(700, 1500), 0.1, 0.04);
      }
    });
    const JG = {
      titan: [
        [60, 64, 67, 72, 71, 67, 64, 67],
        [36, 43],
      ],
      quick: [
        [67, 69, 71, 74, 76, 74, 71, 67],
        [43, 50],
      ],
      rocket: [
        [72, 76, 79, 84, 79, 76, 72, 79],
        [48, 55],
      ],
      second: [
        [55, 59, 62, 67, 66, 62, 59, 62],
        [31, 38],
      ],
      jet: [
        [64, 66, 68, 71, 73, 71, 68, 66],
        [40, 47],
      ],
    };
    for (const k in JG) {
      await def('jingle_' + k, 1, 2.4, (c, o) => {
        const [mel, bass] = JG[k];
        mel.forEach((m, i) => organ(c, o, i * 0.14, m, 0.2, 0.13));
        for (let i = 0; i < 4; i++) {
          O(c, o, i * 0.28, mtof(bass[i % 2]), 0.25, {
            type: 'triangle',
            g: 0.3,
          });
        }
        organ(c, o, 1.15, mel[0], 0.9, 0.1);
        organ(c, o, 1.15, mel[0] + 4, 0.9, 0.08);
        organ(c, o, 1.15, mel[0] + 7, 0.9, 0.08);
        if (k === 'rocket') {
          const s = c.createOscillator();
          s.frequency.setValueAtTime(600, 1.3);
          s.frequency.exponentialRampToValueAtTime(1400, 2);
          const l = c.createOscillator();
          l.frequency.value = 6;
          const lg = c.createGain();
          lg.gain.value = 25;
          l.connect(lg);
          lg.connect(s.frequency);
          const g = c.createGain();
          env(g.gain, 1.3, 0.9, 0.15, 0.1);
          s.connect(g);
          g.connect(o);
          s.start(1.3);
          l.start(1.3);
          s.stop(2.3);
          l.stop(2.3);
        }
        crackle(c, o, 2.3, 0.02);
      });
    }
    const THEMES = {
      titan: {
        tempo: 0.19,
        key: 48,
        mel: [
          7, 7, 9, 7, 12, 11, 7, 0, 5, 5, 7, 5, 9, 7, 4, 0, 7, 7, 9, 7, 14, 12, 11, 9, 7, 9, 11, 12, 14, 12,
          0, 0,
        ],
        ch: [0, 5, 7, 0],
      },
      quick: {
        tempo: 0.16,
        key: 55,
        mel: [
          0, 2, 4, 7, 9, 7, 4, 2, 4, 4, 2, 0, 2, 4, 0, 0, 7, 9, 11, 12, 11, 9, 7, 4, 5, 7, 9, 7, 4, 2, 0, 0,
        ],
        ch: [0, 9, 5, 7],
      },
      rocket: {
        tempo: 0.15,
        key: 60,
        mel: [
          12, 0, 12, 11, 12, 0, 7, 0, 9, 0, 9, 7, 9, 0, 4, 0, 12, 14, 16, 14, 12, 11, 9, 7, 11, 9, 7, 5, 7, 0,
          0, 0,
        ],
        ch: [0, 5, 9, 7],
      },
      second: {
        tempo: 0.21,
        key: 43,
        mel: [
          4, 0, 7, 0, 9, 7, 4, 2, 0, 0, 2, 4, 7, 4, 2, 0, 4, 0, 7, 0, 12, 11, 9, 7, 9, 7, 4, 2, 0, 0, 0, 0,
        ],
        ch: [0, 5, 0, 7],
      },
      jet: {
        tempo: 0.14,
        key: 52,
        mel: [
          0, 4, 7, 11, 12, 11, 7, 4, 5, 9, 12, 14, 12, 9, 5, 2, 0, 4, 7, 11, 12, 14, 16, 14, 12, 11, 9, 7, 12,
          0, 0, 0,
        ],
        ch: [0, 4, 5, 7],
      },
    };
    for (const k in THEMES) {
      await def(
        'theme_' + k,
        1,
        (T) => 32 * THEMES[k].tempo + 1.6,
        (c, o) => {
          const T = THEMES[k],
            bp = Filt(c, 'lowpass', 3800),
            hp = Filt(c, 'highpass', 90);
          bp.connect(hp);
          hp.connect(o);
          T.mel.forEach((d, i) => {
            if (!d && d !== 0) {
              return;
            }
            if (d === 0 && i % 8 > 5) {
              return;
            }
            organ(c, bp, i * T.tempo, T.key + 12 + d, T.tempo * 1.4, 0.12);
          });
          for (let bar = 0; bar < 4; bar++) {
            const root = T.key + T.ch[bar];
            for (let b = 0; b < 4; b++) {
              const t = (bar * 8 + b * 2) * T.tempo;
              O(c, bp, t, mtof(root - 12 + (b % 2 ? 7 : 0)), T.tempo * 1.8, {
                type: 'triangle',
                g: 0.28,
              });
              if (b % 2) {
                N(c, bp, t, 0.09, {
                  type: 'bandpass',
                  f: 2500,
                  q: 0.7,
                  g: 0.18,
                });
              } else {
                N(c, bp, t, 0.05, {
                  f: 180,
                  g: 0.3,
                });
              }
              [0, 4, 7].forEach((iv) => organ(c, bp, t + T.tempo, root + iv, T.tempo * 0.7, 0.05));
            }
          }
          organ(c, bp, 32 * T.tempo, T.key + 12, 1.4, 0.1);
          organ(c, bp, 32 * T.tempo, T.key + 16, 1.4, 0.08);
          organ(c, bp, 32 * T.tempo, T.key + 19, 1.4, 0.08);
          crackle(c, o, 32 * T.tempo + 1.5, 0.025);
        },
        1,
        0.8,
      );
    }
    await def(
      'rain',
      1,
      6,
      (c, o) => {
        N(c, o, 0, 6, {
          f: 1800,
          q: 0.3,
          g: 0.5,
          flat: true,
        });
        N(c, o, 0, 6, {
          type: 'bandpass',
          f: 400,
          q: 0.5,
          g: 0.3,
          flat: true,
        });
        for (let t = 0; t < 5.9; t += rand(0.005, 0.03)) {
          clk(c, o, t, rand(2500, 7e3), rand(0.02, 0.08), 0.006);
        }
      },
      1,
      0.6,
    );
    await def('thunder', 3, 5, (c, o) => {
      N(c, o, 0, 0.5, {
        f: 1500,
        g: 0.4,
        a: 0.01,
      });
      N(c, o, 0, 4.5, {
        f: 320,
        f2: 55,
        g: 1,
        a: 0.3,
      });
      for (let i = 0; i < 4; i++) {
        N(c, o, rand(0.3, 2.5), 1.2, {
          f: 200,
          g: 0.6,
          a: 0.2,
        });
      }
    });
    await def('creak', 4, 3.2, (c, o) => {
      const s = c.createOscillator();
      s.type = 'sawtooth';
      const f0 = rand(55, 90);
      s.frequency.setValueAtTime(f0, 0);
      s.frequency.linearRampToValueAtTime(f0 * rand(0.8, 1.3), 2.8);
      const bp = c.createBiquadFilter();
      bp.type = 'bandpass';
      bp.Q.value = 15;
      bp.frequency.setValueAtTime(rand(350, 600), 0);
      bp.frequency.linearRampToValueAtTime(rand(500, 950), 2.8);
      const g = c.createGain();
      env(g.gain, 0, 3, 0.6, 1.2);
      s.connect(bp);
      bp.connect(g);
      g.connect(o);
      s.start(0);
      s.stop(3.1);
    });
    await def('drip', 3, 0.15, (c, o) =>
      O(c, o, 0, rand(800, 1100), 0.08, {
        f2: rand(1500, 2200),
        fd: 0.03,
        g: 0.5,
      }),
    );
    await def(
      'hum',
      1,
      4,
      (c, o) => {
        [60, 120, 180.4].forEach((f, i) =>
          O(c, o, 0, f, 4, {
            type: 'sawtooth',
            g: [0.3, 0.15, 0.06][i],
            a: 0.001,
            lp: 500,
          }),
        );
      },
      1,
      0.5,
    );
    await def(
      'radio',
      1,
      16,
      (c, o) => {
        const bp1 = Filt(c, 'highpass', 350);
        const bp2 = Filt(c, 'lowpass', 3e3);
        const d = WS(c, 1.5);
        bp1.connect(bp2);
        bp2.connect(d);
        d.connect(o);
        const mel = [
          65, 69, 72, 74, 72, 69, 65, 67, 69, 67, 65, 62, 60, 0, 0, 0, 70, 74, 77, 79, 77, 74, 70, 72, 69, 65,
          67, 69, 65, 0, 0, 0,
        ];
        mel.forEach((m, i) => {
          if (!m) {
            return;
          }
          const t = i * 0.5 + (i % 2 ? 0.08 : 0);
          const s = c.createOscillator();
          s.type = 'square';
          s.frequency.value = mtof(m);
          const l = c.createOscillator();
          l.frequency.value = 5;
          const lg = c.createGain();
          lg.gain.value = 3;
          l.connect(lg);
          lg.connect(s.frequency);
          const lp = Filt(c, 'lowpass', 1800);
          const g = c.createGain();
          env(g.gain, t, 0.45, 0.18, 0.03);
          s.connect(lp);
          lp.connect(g);
          g.connect(bp1);
          s.start(t);
          l.start(t);
          s.stop(t + 0.5);
          l.stop(t + 0.5);
        });
        const bass = [41, 48, 41, 48, 43, 50, 43, 50, 46, 53, 46, 53, 48, 43, 41, 48];
        for (let i = 0; i < 32; i++) {
          O(c, bp1, i * 0.5, mtof(bass[i % 16]) * 2, 0.4, {
            type: 'triangle',
            g: 0.22,
          });
        }
        for (let i = 0; i < 64; i++) {
          N(c, bp1, i * 0.25, 0.05, {
            type: 'highpass',
            f: 5e3,
            g: i % 2 ? 0.05 : 0.1,
          });
        }
        crackle(c, o, 16, 0.06);
      },
      1,
      0.7,
    );
    await def(
      'mus_round',
      1,
      6,
      (c, o) => {
        O(c, o, 0, 45, 3, {
          g: 0.9,
          f2: 30,
        });
        N(c, o, 0, 2.5, {
          f: 200,
          g: 0.6,
          a: 0.02,
        });
        [38, 45, 50, 53].forEach((m) => piano(c, o, 0.05, m, 0.22, 4));
        [74, 72, 69, 65, 64].forEach((m, i) => bellM(c, o, 1 + i * 0.55, m, 0.16, 3));
        pad(c, o, 0.5, [38, 45, 50], 5, 0.05, 500);
        N(c, o, 1, 3, {
          type: 'bandpass',
          f: 1500,
          q: 0.4,
          g: 0.12,
          a: 1.5,
        });
      },
      1,
      0.8,
    );
    await def(
      'mus_end',
      1,
      5,
      (c, o) => {
        [62, 65, 69, 72, 76].forEach((m, i) => bellM(c, o, i * 0.45, m, 0.15, 2.6));
        pad(c, o, 0, [38, 45, 52], 4, 0.06, 800);
      },
      1,
      0.7,
    );
    await def(
      'mus_drone',
      1,
      16,
      (c, o) => {
        pad(c, o, 0, [26, 33], 15.5, 0.07, 220);
        for (let i = 0; i < 5; i++) {
          N(c, o, rand(0, 14), 2, {
            type: 'bandpass',
            f: rand(300, 900),
            q: 8,
            g: 0.04,
            a: 0.8,
          });
        }
      },
      1,
      0.5,
    );
  }
  function init() {
    if (ctx) {
      if (ctx.state === 'suspended') {
        ctx.resume();
      }
      return readyP;
    }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC || typeof OfflineAudioContext === 'undefined') {
      return Promise.resolve();
    }
    ctx = new AC();
    SR = ctx.sampleRate;
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -12;
    comp.knee.value = 10;
    comp.ratio.value = 4;
    comp.attack.value = 0.003;
    comp.release.value = 0.25;
    comp.connect(ctx.destination);
    master = ctx.createGain();
    master.connect(comp);
    for (const k of ['sfx', 'mus', 'zom', 'amb']) {
      bus[k] = ctx.createGain();
      bus[k].connect(master);
    }
    const rv = ctx.createConvolver();
    const rl = Math.floor(SR * 3);
    const ib = ctx.createBuffer(2, rl, SR);
    for (let c = 0; c < 2; c++) {
      const d = ib.getChannelData(c);
      for (let i = 0; i < rl; i++) {
        d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / rl, 3.2) * (i < SR * 0.02 ? i / (SR * 0.02) : 1);
      }
    }
    rv.buffer = ib;
    revIn = ctx.createGain();
    revIn.gain.value = 0.55;
    revIn.connect(rv);
    const rg = ctx.createGain();
    rg.gain.value = 0.5;
    rv.connect(rg);
    rg.connect(master);
    applyVolumes();
    loadPack();
    readyP = buildAll()
      .then(() => {
        ready = true;
        onReady.forEach((f) => f());
      })
      .catch((e) => console.warn('audio build', e));
    return readyP;
  }
  const onReady = [];
  function whenReady(f) {
    if (ready) {
      f();
    } else {
      onReady.push(f);
    }
  }
  function applyVolumes() {
    if (!ctx) {
      return;
    }
    const a = SET.audio;
    master.gain.value = a.master;
    bus.sfx.gain.value = a.sfx;
    bus.mus.gain.value = a.music;
    bus.zom.gain.value = a.zombies * a.sfx;
    bus.amb.gain.value = a.sfx * 0.9;
  }
  function setP(p, x, y, z) {
    if (p.positionX) {
      p.positionX.value = x;
      p.positionY.value = y;
      p.positionZ.value = z;
    } else {
      p.setPosition(x, y, z);
    }
  }
  function setListener(x, y, z, yaw, pitch) {
    L.x = x;
    L.y = y;
    L.z = z;
    if (!ctx) {
      return;
    }
    const l = ctx.listener;
    const fx = -Math.sin(yaw) * Math.cos(pitch),
      fy = Math.sin(pitch),
      fz = -Math.cos(yaw) * Math.cos(pitch);
    if (l.positionX) {
      l.positionX.value = x;
      l.positionY.value = y;
      l.positionZ.value = z;
      l.forwardX.value = fx;
      l.forwardY.value = fy;
      l.forwardZ.value = fz;
      l.upX.value = 0;
      l.upY.value = 1;
      l.upZ.value = 0;
    } else {
      l.setPosition(x, y, z);
      l.setOrientation(fx, fy, fz, 0, 1, 0);
    }
  }
  function play(name, o = {}) {
    if (!ctx) {
      return null;
    }
    const arr = B[name];
    if (!arr) {
      return null;
    }
    const buf = o.v != null ? arr[o.v % arr.length] : pick(arr);
    let d = 0;
    if (o.pos) {
      d = Math.hypot(o.pos[0] - L.x, o.pos[1] - L.y, o.pos[2] - L.z);
      if (d > (o.max || 55)) {
        return null;
      }
    }
    const s = ctx.createBufferSource();
    s.buffer = buf;
    s.playbackRate.value = (o.rate || 1) * (o.rr ? 1 + rand(-o.rr, o.rr) : 1);
    const g = ctx.createGain();
    g.gain.value = o.g == null ? 1 : o.g;
    s.connect(g);
    let n = g;
    if (o.pos) {
      const lp = ctx.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.value = clamp(2e4 * Math.pow(0.92, d), 700, 2e4);
      const pn = ctx.createPanner();
      pn.panningModel = o.hrtf ? 'HRTF' : 'equalpower';
      pn.distanceModel = 'inverse';
      pn.refDistance = o.ref || 2;
      pn.rolloffFactor = o.roll || 1.1;
      pn.maxDistance = 100;
      setP(pn, o.pos[0], o.pos[1], o.pos[2]);
      n.connect(lp);
      lp.connect(pn);
      n = pn;
      s._pn = pn;
    }
    n.connect(bus[o.bus || 'sfx']);
    if (o.wet) {
      const w = ctx.createGain();
      w.gain.value = o.wet;
      n.connect(w);
      w.connect(revIn);
    }
    if (o.loop) {
      s.loop = true;
    }
    s.start(ctx.currentTime + (o.delay || 0));
    s._g = g;
    return s;
  }
  function zvoice(name, pos, run) {
    if (!ctx || zVoices > 9) {
      return null;
    }
    const s = play(name, {
      pos: pos,
      bus: 'zom',
      hrtf: true,
      rr: 0.12,
      wet: 0.35,
      ref: 2.5,
      g: run ? 1 : 0.85,
    });
    if (s) {
      zVoices++;
      s.onended = () => zVoices--;
    }
    return s;
  }
  function loop(key, name, o = {}) {
    stopLoop(key);
    const s = play(
      name,
      Object.assign(
        {
          loop: true,
        },
        o,
      ),
    );
    if (s) {
      loops[key] = s;
    }
    return s;
  }
  function stopLoop(key, fade = 0.3) {
    const s = loops[key];
    if (!s) {
      return;
    }
    delete loops[key];
    try {
      s._g.gain.setTargetAtTime(0, ctx.currentTime, fade / 3);
      s.stop(ctx.currentTime + fade + 0.05);
    } catch (e) {}
  }
  function loopPos(key, x, y, z) {
    const s = loops[key];
    if (s && s._pn) {
      setP(s._pn, x, y, z);
    }
  }
  function loopGain(key, g) {
    const s = loops[key];
    if (s) {
      s._g.gain.setTargetAtTime(g, ctx.currentTime, 0.1);
    }
  }
  function say(text) {
    if (!SET.audio.voice) {
      return;
    }
    try {
      if (!('speechSynthesis' in window)) {
        return;
      }
      const u = new SpeechSynthesisUtterance(text);
      u.pitch = 0.25;
      u.rate = 0.82;
      u.volume = SET.audio.master;
      speechSynthesis.cancel();
      speechSynthesis.speak(u);
    } catch (e) {}
  }
  function suspend() {
    if (ctx && ctx.state === 'running') {
      ctx.suspend();
    }
    try {
      speechSynthesis.pause();
    } catch (e) {}
  }
  function resume() {
    if (ctx && ctx.state === 'suspended') {
      ctx.resume();
    }
    try {
      speechSynthesis.resume();
    } catch (e) {}
  }
  return {
    whenBuf: whenBuf,
    suspend: suspend,
    resume: resume,
    init: init,
    whenReady: whenReady,
    get ready() {
      return ready;
    },
    get ctx() {
      return ctx;
    },
    applyVolumes: applyVolumes,
    setListener: setListener,
    play: play,
    zvoice: zvoice,
    loop: loop,
    stopLoop: stopLoop,
    loopPos: loopPos,
    loopGain: loopGain,
    say: say,
  };
})();

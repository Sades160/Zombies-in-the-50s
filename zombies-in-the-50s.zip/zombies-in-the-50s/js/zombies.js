const ZG = {};

const ZM = {};

function lathe(pts, seg = 14) {
  return new THREE.LatheGeometry(
    pts.map((p) => new THREE.Vector2(p[0], p[1])),
    seg,
  );
}

function sphereAt(r, x, y, z, sx = 1, sy = 1, sz = 1, ws = 12, hs = 9) {
  const g = new THREE.SphereGeometry(r, ws, hs);
  g.scale(sx, sy, sz);
  g.translate(x, y, z);
  return g;
}

function mergeGroups(list) {
  list = list.map(([g, m]) => [g.index ? g.toNonIndexed() : g, m]).sort((a, b) => a[1] - b[1]);
  const merged = mergeGeos(list.map((l) => l[0]));
  let start = 0;
  for (const [g, m] of list) {
    const n = g.attributes.position.count;
    merged.addGroup(start, n, m);
    start += n;
  }
  return merged;
}

function sculptHead() {
  const g = new THREE.SphereGeometry(0.104, 34, 26);
  const p = g.attributes.position;
  const v = new THREE.Vector3(),
    d = new THREE.Vector3();
  const bump = (dir, cx, cy, cz, rad, amt) => {
    const dd = Math.hypot(dir.x - cx, dir.y - cy, dir.z - cz);
    return dd < rad ? amt * (0.5 + 0.5 * Math.cos((Math.PI * dd) / rad)) : 0;
  };
  for (let i = 0; i < p.count; i++) {
    v.set(p.getX(i), p.getY(i), p.getZ(i));
    d.copy(v).normalize();
    let r = 1;
    r -= bump(d, 0.36, 0.1, 0.92, 0.3, 0.12);
    r -= bump(d, -0.36, 0.1, 0.92, 0.3, 0.12);
    r += bump(d, 0.32, 0.3, 0.9, 0.25, 0.05);
    r += bump(d, -0.32, 0.3, 0.9, 0.25, 0.05);
    r += bump(d, 0, 0.32, 0.95, 0.3, 0.04);
    r += bump(d, 0, -0.02, 1, 0.16, 0.2);
    r += bump(d, 0, 0.12, 0.99, 0.14, 0.08);
    r -= bump(d, 0.58, -0.28, 0.76, 0.3, 0.09);
    r -= bump(d, -0.58, -0.28, 0.76, 0.3, 0.09);
    r += bump(d, 0.72, 0.02, 0.62, 0.2, 0.05);
    r += bump(d, -0.72, 0.02, 0.62, 0.2, 0.05);
    r -= bump(d, 0.9, 0.15, 0, 0.45, 0.05);
    r -= bump(d, -0.9, 0.15, 0, 0.45, 0.05);
    let sx = 1,
      sy = 1.18,
      sz = 1.1;
    if (d.y < -0.35) {
      sx *= 1 - (-0.35 - d.y) * 0.35;
    }
    if (d.z < -0.2) {
      sz *= 1.06;
      sy *= 1.02;
    }
    p.setXYZ(i, v.x * r * sx, v.y * r * sy, v.z * r * sz);
  }
  g.computeVertexNormals();
  const earL = sphereAt(0.028, 0.104, 0, -0.005, 0.45, 1, 0.75, 8, 6),
    earR = sphereAt(0.028, -0.104, 0, -0.005, 0.45, 1, 0.75, 8, 6);
  return mergeGroups([
    [g, 0],
    [earL, 0],
    [earR, 0],
  ]);
}

function clawHand() {
  const parts = [[rbox(0.068, 0.085, 0.032, 0.012).translate(0, -0.34, 0), 0]];
  for (let i = 0; i < 4; i++) {
    const f = rbox(0.013, 0.06, 0.013, 0.005);
    f.translate(0, -0.03, 0);
    f.rotateX(-0.55 - i * 0.05);
    f.translate(-0.024 + i * 0.016, -0.38, 0.006);
    parts.push([f, 0]);
    const t = rbox(0.011, 0.035, 0.011, 0.004);
    t.translate(0, -0.017, 0);
    t.rotateX(-1.3);
    t.translate(-0.024 + i * 0.016, -0.425, 0.03);
    parts.push([t, 0]);
  }
  const th = rbox(0.015, 0.05, 0.015, 0.006);
  th.translate(0, -0.025, 0);
  th.rotateZ(0.6);
  th.rotateX(-0.5);
  th.translate(0.034, -0.31, 0.01);
  parts.push([th, 0]);
  return parts;
}

function zInit() {
  const C = (a, b, h, s) => new THREE.CylinderGeometry(a, b, h, s);
  ZG.pelvis = lathe(
    [
      [0.13, -0.12],
      [0.162, -0.06],
      [0.165, 0.02],
      [0.152, 0.1],
    ],
    16,
  );
  ZG.pelvis.scale(1, 1, 0.68);
  ZG.torso = new THREE.LatheGeometry(
    [
      [0.001, 0],
      [0.135, 0],
      [0.148, 0.06],
      [0.15, 0.14],
      [0.147, 0.22],
      [0.168, 0.32],
      [0.19, 0.4],
      [0.198, 0.45],
      [0.185, 0.49],
      [0.15, 0.52],
      [0.07, 0.545],
      [0.001, 0.55],
    ].map((p) => new THREE.Vector2(p[0], p[1])),
    24,
  );
  ZG.torso.scale(1, 1, 0.6);
  ZG.torso.translate(0, -0.27, 0);
  ZG.neck = lathe(
    [
      [0.058, -0.01],
      [0.05, 0.03],
      [0.047, 0.08],
      [0.052, 0.13],
    ],
    12,
  );
  ZG.head = sculptHead();
  ZG.jaw = rbox(0.1, 0.035, 0.09, 0.012);
  ZG.upper = mergeGroups([
    [sphereAt(0.056, 0, 0, 0, 1, 1, 1, 14, 10), 0],
    [
      lathe(
        [
          [0.054, 0],
          [0.056, -0.05],
          [0.05, -0.13],
          [0.047, -0.2],
          [0.041, -0.28],
          [0.04, -0.3],
        ],
        14,
      ),
      0,
    ],
  ]);
  ZG.fore = mergeGroups([
    [sphereAt(0.043, 0, 0, 0), 0],
    [
      lathe(
        [
          [0.042, 0],
          [0.045, -0.06],
          [0.04, -0.13],
          [0.033, -0.24],
          [0.03, -0.29],
        ],
        14,
      ),
      0,
    ],
    ...clawHand().map(([g]) => [g, 1]),
  ]);
  ZG.thigh = mergeGroups([
    [sphereAt(0.08, 0, 0, 0, 1, 1, 1, 14, 10), 0],
    [
      lathe(
        [
          [0.08, 0],
          [0.084, -0.08],
          [0.074, -0.22],
          [0.063, -0.36],
          [0.057, -0.44],
        ],
        16,
      ),
      0,
    ],
  ]);
  ZG.shin = mergeGroups([
    [sphereAt(0.06, 0, 0, 0, 1, 1, 1, 12, 9), 0],
    [
      lathe(
        [
          [0.058, 0],
          [0.064, -0.1],
          [0.056, -0.2],
          [0.044, -0.36],
          [0.041, -0.44],
        ],
        14,
      ),
      0,
    ],
    [rbox(0.095, 0.07, 0.24, 0.03).translate(0, -0.47, 0.05), 1],
  ]);
  ZG.torso2 = null;
  ZG.eye = new THREE.SphereGeometry(0.014, 8, 6);
  ZG.cap = C(0.122, 0.125, 0.07, 16);
  ZG.brim = rbox(0.2, 0.015, 0.1, 0.005);
  ZG.stump = new THREE.CircleGeometry(0.055, 10);
  ZG.stump.rotateX(-Math.PI / 2);
  ZG.apron = C(0.205, 0.17, 0.5, 12, 1, true);
  ZG.apron.scale(1, 1, 0.66);
  ZM.skins = [];
  ZM.faces = [];
  const tints = [7108448, 7828842, 6581848];
  TX.skins.forEach((t, i) => {
    const sn = normalFromHeight(t.image, 2.5);
    ZM.skins.push(
      std({
        map: t,
        normalMap: sn,
        normalScale: new THREE.Vector2(0.6, 0.6),
        color: tints[i],
        roughness: 0.55,
        envMapIntensity: 0.5,
      }),
    );
    ZM.faces.push(
      std({
        map: TX.faces[i],
        normalMap: normalFromHeight(TX.faces[i].image, 3),
        normalScale: new THREE.Vector2(0.7, 0.7),
        color: tints[i],
        roughness: 0.62,
      }),
    );
  });
  ZM.cloth = {};
  for (const k in TX.cloth) {
    ZM.cloth[k] = std({
      map: TX.cloth[k],
      bumpMap: TX.cloth[k],
      bumpScale: 0.003,
      roughness: 0.95,
    });
    ZM.cloth[k + 'D'] = std({
      map: TX.cloth[k],
      roughness: 0.95,
      side: THREE.DoubleSide,
    });
  }
  ZM.hair = std({
    color: 1840914,
    roughness: 0.95,
  });
  ZM.hairGrey = std({
    color: 6972764,
    roughness: 0.95,
  });
  ZG.ear = new THREE.SphereGeometry(0.028, 8, 6);
  ZG.ear.scale(0.45, 1, 0.75);
  ZG.nose = new THREE.ConeGeometry(0.016, 0.045, 6);
  ZG.nose.rotateX(Math.PI / 2 + 0.4);
  ZG.hairCap = new THREE.SphereGeometry(0.109, 16, 8, 0, TAU, 0, Math.PI * 0.42);
  ZG.hairCap.scale(1.02, 1.2, 1.12);
  ZG.brow = rbox(0.085, 0.016, 0.025, 0.006);
  ZG.strip = new THREE.PlaneGeometry(0.06, 0.16);
  ZG.strip.translate(0, -0.08, 0);
  ZM.eye = new THREE.MeshBasicMaterial({
    color: 16722450,
  });
  ZM.stump = std({
    color: 5900294,
    roughness: 0.4,
  });
  ZM.playerSkin = std({
    color: 13146746,
    roughness: 0.7,
  });
  ZM.capDark = std({
    color: 1711140,
    roughness: 0.7,
  });
  ZM.capTweed = std({
    color: 4866614,
    roughness: 0.95,
  });
}

const OUTFITS = [
  {
    shirt: 'flannelR',
    pants: 'denim',
    cap: 'tweed',
  },
  {
    shirt: 'flannelG',
    pants: 'khaki',
  },
  {
    shirt: 'white',
    pants: 'denim',
    over: 'denim',
  },
  {
    shirt: 'white',
    pants: 'grey',
    apron: 1,
  },
  {
    shirt: 'navy',
    pants: 'navy',
    cap: 'dark',
  },
  {
    shirt: 'suit',
    pants: 'grey',
  },
  {
    shirt: 'khaki',
    pants: 'khaki',
    cap: 'tweed',
  },
];

function buildRig(o) {
  const root = new THREE.Group();
  root.rotation.order = 'YXZ';
  const hits = [];
  const all = [];
  const M = (geo, mat, parent, x = 0, y = 0, z = 0, part) => {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(x, y, z);
    parent.add(m);
    all.push(m);
    if (part) {
      (hits.push(m), (m.userData.part = part));
    }
    return m;
  };
  const Gp = (parent, x, y, z) => {
    const g = new THREE.Group();
    g.position.set(x, y, z);
    parent.add(g);
    return g;
  };
  const shirt = o.shirtMat,
    pants = o.pantsMat,
    skin = o.skinMat;
  const hips = Gp(root, 0, 0.95, 0);
  M(ZG.pelvis, pants, hips, 0, 0, 0, 'body');
  const spine = Gp(hips, 0, 0.06, 0);
  M(ZG.torso, o.overMat || shirt, spine, 0, 0.27, 0, 'body');
  if (o.apronMat) {
    M(ZG.apron, o.apronMat, spine, 0, 0.24, 0.005);
  }
  const neck = Gp(spine, 0, 0.53, 0);
  M(ZG.neck, skin, neck, 0, 0.04, 0, 'head');
  const head = Gp(neck, 0, 0.09, 0);
  const hm = M(ZG.head, [o.faceMat], head, 0, 0.1, 0, 'head');
  hm.rotation.y = 0;
  if (o.hair && !o.cap) {
    M(ZG.hairCap, o.hair, head, 0, 0.112, -0.008);
  }
  const strips = [];
  if (o.torn) {
    for (let i = 0; i < 3; i++) {
      const st = new THREE.Group();
      st.position.set(-0.1 + i * 0.1, -0.02, 0.09 - (i === 1 ? 0.01 : 0));
      spine.add(st);
      const m = new THREE.Mesh(ZG.strip, o.torn);
      m.castShadow = false;
      st.add(m);
      all.push(m);
      strips.push(st);
    }
  }
  const jaw = Gp(head, 0, 0.035, 0.03);
  M(ZG.jaw, skin, jaw, 0, -0.01, 0.02, 'head');
  const eyes = [];
  if (o.eyes) {
    [-0.038, 0.038].forEach((x) => {
      M(ZG.eye, ZM.eye, head, x, 0.12, 0.1);
      const s = glowSprite(16717832, 0.075, 0.95, false);
      s.position.set(x, 0.12, 0.122);
      head.add(s);
      eyes.push(s);
    });
  }
  if (o.cap) {
    const cm = o.cap === 'dark' ? ZM.capDark : ZM.capTweed;
    M(ZG.cap, cm, head, 0, 0.22, -0.005);
    M(ZG.brim, cm, head, 0, 0.19, 0.1);
  }
  const stump = M(ZG.stump, ZM.stump, neck, 0, 0.1, 0);
  stump.visible = false;
  const arm = (sx) => {
    const s = Gp(spine, sx * 0.225, 0.47, 0);
    M(ZG.upper, o.sleeveMat || shirt, s, 0, 0, 0, 'limb');
    const e = Gp(s, 0, -0.3, 0);
    M(ZG.fore, [o.bareArms ? skin : o.sleeveMat || shirt, skin], e, 0, 0, 0, 'limb');
    return [s, e];
  };
  const [sL, eL] = arm(1),
    [sR, eR] = arm(-1);
  const leg = (sx) => {
    const h = Gp(hips, sx * 0.1, -0.02, 0);
    M(ZG.thigh, pants, h, 0, 0, 0, 'limb');
    const k = Gp(h, 0, -0.44, 0);
    M(ZG.shin, [pants, MAT.rubber], k, 0, 0, 0, 'limb');
    return [h, k];
  };
  const [hL, kL] = leg(1),
    [hR, kR] = leg(-1);
  const sh = SET.video.shadows === 'high';
  all.forEach((m) => {
    m.castShadow = sh;
  });
  return {
    root: root,
    hips: hips,
    spine: spine,
    neck: neck,
    head: head,
    jaw: jaw,
    sL: sL,
    sR: sR,
    eL: eL,
    eR: eR,
    hL: hL,
    hR: hR,
    kL: kL,
    kR: kR,
    eyes: eyes,
    stump: stump,
    hits: hits,
    all: all,
    strips: strips,
  };
}

function zombieLook(id) {
  const R = mulberry(id * 7919 + 13);
  const o = OUTFITS[(R() * OUTFITS.length) | 0];
  const si = (R() * ZM.skins.length) | 0;
  return {
    skinMat: ZM.skins[si],
    faceMat: ZM.faces[(R() * ZM.faces.length) | 0],
    shirtMat: ZM.cloth[o.shirt],
    pantsMat: ZM.cloth[o.pants],
    overMat: o.over ? ZM.cloth[o.over] : null,
    apronMat: o.apron ? ZM.cloth.apron : null,
    cap: o.cap,
    eyes: true,
    bareArms: R() < 0.35,
    hair: R() < 0.75 ? (R() < 0.3 ? ZM.hairGrey : ZM.hair) : null,
    torn: R() < 0.55 ? ZM.cloth[o.shirt + 'D'] : null,
    gait: {
      limp: R() < 0.3 ? 0.3 + R() * 0.4 : 0,
      limpArm: R() < 0.25,
      hunch: R() * 0.2,
      tilt: (R() - 0.5) * 0.5,
      seed: R() * 10,
      scale: 0.93 + R() * 0.14,
      twitch: 2 + R() * 5,
    },
  };
}

const ZBS = [];

let ZID = 1;

function zCreate(id, kind) {
  const look = zombieLook(id);
  const rig = buildRig(look);
  const z = {
    id: id,
    kind: kind,
    rig: rig,
    look: look,
    g: look.gait,
    x: 0,
    z: 0,
    y: 0,
    yaw: 0,
    tx: 0,
    tz: 0,
    ty: 0,
    tyaw: 0,
    anim: 0,
    at: rand(0, 5),
    ph: rand(0, 6),
    moveSpd: 0,
    dead: false,
    deathT: 0,
    flinch: 0,
    hflinch: 0,
    pullT: 0,
    voiceT: 0,
    groanT: rand(1, 5),
    stepT: 0,
    atkT: 0,
    twT: rand(1, 4),
    twA: 0,
    climbK: 0,
  };
  rig.root.scale.setScalar(look.gait.scale);
  rig.hits.forEach((m) => (m.userData.z = z));
  scene.add(rig.root);
  ZBS.push(z);
  return z;
}

function zRemove(z) {
  scene.remove(z.rig.root);
  const i = ZBS.indexOf(z);
  if (i >= 0) {
    ZBS.splice(i, 1);
  }
}

function zById(id) {
  for (const z of ZBS) {
    if (z.id === id) {
      return z;
    }
  }
  return null;
}

function zStartDeath(z, part, dtype) {
  if (z.dead) {
    return;
  }
  z.dead = true;
  z.deathT = 0;
  z.dtype = dtype == null ? randi(0, 2) : dtype;
  z.anim = 5;
  if (z.dtype === 3) {
    let dx = z.flyDir ? z.flyDir[0] : z.x - ME.x,
      dz = z.flyDir ? z.flyDir[1] : z.z - ME.z;
    const L = Math.hypot(dx, dz) || 1;
    const sp = rand(9, 14);
    z.fly = {
      vx: (dx / L) * sp,
      vz: (dz / L) * sp,
      vy: rand(4, 7),
      spin: rand(-6, 6),
    };
    z.yaw = Math.atan2(-dx, -dz);
  }
  if (part === 'head') {
    z.rig.head.visible = false;
    z.rig.stump.visible = true;
    spawnFX(z.x, 1.65, z.z, 18, 'blood');
    spawnFX(z.x, 1.65, z.z, 5, 'mist');
  }
  z.rig.eyes.forEach((e) => (e.visible = false));
  if (Math.random() < 0.7) {
    AU.zvoice('z_death', [z.x, 1.5, z.z]);
  }
  setTimeout(
    () =>
      AU.play('bodyfall', {
        pos: [z.x, 0.2, z.z],
        rr: 0.1,
      }),
    650,
  );
  bloodPool(z.x, z.z);
}

function animZombie(z, dt) {
  const r = z.rig,
    g = z.g;
  z.at += dt;
  const t = z.at;
  z.flinch = damp(z.flinch, 0, 6, dt);
  z.hflinch = damp(z.hflinch, 0, 6, dt);
  z.pullT = Math.max(0, z.pullT - dt);
  z.voiceT = Math.max(0, z.voiceT - dt);
  z.twT -= dt;
  if (z.twT <= 0) {
    z.twT = rand(1, g.twitch);
    z.twA = rand(-0.6, 0.6);
  }
  z.twA = damp(z.twA, 0, 5, dt);
  if (z.dead) {
    z.deathT += dt;
    if (z.dtype === 3 && z.fly) {
      const f = z.fly;
      if (z.deathT < 1.6) {
        f.vy -= 14 * dt;
        z.x += f.vx * dt;
        z.z += f.vz * dt;
        z.y = Math.max(0, z.y + f.vy * dt);
        if (z.y === 0 && f.vy < 0) {
          f.vy *= -0.25;
          f.vx *= 0.5;
          f.vz *= 0.5;
        }
        r.root.rotation.x = -Math.min(1.5, z.deathT * 3);
        r.root.rotation.z += f.spin * dt * (z.y > 0.05 ? 1 : 0);
      }
      r.sL.rotation.x = -2.8;
      r.sR.rotation.x = -2.5;
      r.hL.rotation.x = -0.6;
      r.kL.rotation.x = 0.8;
      r.root.position.set(z.x, z.y - (z.deathT > 4 ? (z.deathT - 4) * 0.5 : 0), z.z);
      r.root.rotation.y = z.yaw;
      return;
    }
    let dT = z.deathT;
    if (z.dtype === 4) {
      if (z.deathT < 1.3) {
        const j = Math.sin(z.deathT * 60);
        r.spine.rotation.set(0.1 + j * 0.12, j * 0.2, j * 0.1);
        r.sL.rotation.set(-1.6 + j * 0.5, 0, 0.6);
        r.sR.rotation.set(-1.4 - j * 0.5, 0, -0.6);
        r.neck.rotation.x = j * 0.3;
        r.jaw.rotation.x = 0.6;
        r.root.position.set(z.x, z.y + Math.abs(j) * 0.03, z.z);
        r.root.rotation.y = z.yaw;
        if (Math.random() < 0.3) {
          spawnFX(z.x + rand(-0.3, 0.3), rand(0.6, 1.8), z.z + rand(-0.3, 0.3), 1, 'arc');
        }
        return;
      }
      dT = z.deathT - 1.3;
    }
    const k = smooth(Math.min(1, dT / 0.75));
    const T0 = z.dtype === 4 ? 2 : z.dtype;
    r.root.rotation.x = T0 === 0 ? -k * 1.5 : T0 === 1 ? k * 1.48 : k * 0.1;
    r.root.rotation.z = T0 === 2 ? k * 1.45 : 0;
    r.hips.position.y = 0.95 - (T0 === 2 ? k * 0.55 : k * 0.05);
    r.kL.rotation.x = k * (T0 === 2 ? 1.6 : 0.5);
    r.kR.rotation.x = k * (T0 === 2 ? 1.3 : 0.3);
    r.hL.rotation.x = -k * (T0 === 2 ? 1.2 : 0.3);
    r.hR.rotation.x = -k * 0.1;
    r.sL.rotation.x = lerp(r.sL.rotation.x, T0 === 0 ? -2.6 : 0.2, k * 0.2);
    r.sR.rotation.x = lerp(r.sR.rotation.x, T0 === 0 ? -2.3 : -0.3, k * 0.2);
    r.sL.rotation.z = k * 0.5;
    r.sR.rotation.z = -k * 0.6;
    r.eL.rotation.x = -k * 0.4;
    r.eR.rotation.x = -k * 0.2;
    r.spine.rotation.x = k * (T0 === 1 ? 0.2 : -0.1);
    r.neck.rotation.x = k * (T0 === 0 ? -0.5 : 0.5);
    r.jaw.rotation.x = 0.5 * k;
    const sink = z.deathT > 4.5 ? (z.deathT - 4.5) * 0.5 : 0;
    r.root.position.set(z.x, z.y * (1 - k) - sink, z.z);
    r.root.rotation.y = z.yaw;
    return;
  }
  const run = z.kind !== 'walk',
    sprint = z.kind === 'sprint';
  const moving = z.anim === 0 && z.moveSpd > 0.15;
  z.ph += dt * (moving ? (run ? z.moveSpd * 2.1 + 2 : z.moveSpd * 3.4 + 0.8) : 1);
  const ph = z.ph,
    s = Math.sin(ph),
    s2 = Math.sin(ph + Math.PI);
  let hL = 0,
    hR = 0,
    kL = 0.08,
    kR = 0.08,
    sLx = 0,
    sRx = 0,
    sLz = 0.08,
    sRz = -0.08,
    eLx = -0.2,
    eRx = -0.2,
    spX = 0.1 + g.hunch,
    spZ = 0,
    spY = 0,
    hipY = 0.95,
    nkX = -0.05,
    hdZ = g.tilt,
    jaw = 0.15;
  if (z.anim === 0 || z.anim === 1) {
    const A = moving ? (sprint ? 0.95 : run ? 0.78 : 0.45) : 0;
    const lim = g.limp && !run ? g.limp : 0;
    hL = -s * A * (1 - lim);
    hR = -s2 * A;
    kL = 0.1 + Math.max(0, Math.sin(ph - 1.3)) * (run ? 1.4 : 0.75) * (A ? 1 : 0);
    kR = 0.1 + Math.max(0, Math.sin(ph + Math.PI - 1.3)) * (run ? 1.4 : 0.75) * (A ? 1 : 0);
    hipY =
      0.95 -
      Math.abs(Math.cos(ph)) * (run ? 0.07 : 0.035) * (A ? 1 : 0) -
      (lim ? Math.max(0, s) * lim * 0.08 : 0);
    spX = (run ? (sprint ? 0.5 : 0.35) : 0.12) + g.hunch;
    spZ = -s * (run ? 0.06 : 0.08) + lim * 0.12;
    spY = s * (run ? 0.18 : 0.1);
    if (run) {
      sLx = sprint ? -1.7 + Math.sin(ph * 2) * 0.5 : s2 * 1.1 - 0.3;
      sRx = sprint ? -1.7 - Math.sin(ph * 2) * 0.5 : s * 1.1 - 0.3;
      eLx = sprint ? -0.3 : -1.3;
      eRx = sprint ? -0.3 : -1.3;
    } else {
      sLx = -1.35 + Math.sin(ph * 0.5 + g.seed) * 0.14;
      sRx = -1.3 + Math.cos(ph * 0.5 + g.seed) * 0.14;
      eLx = -0.28;
      eRx = -0.22;
      if (g.limpArm) {
        sRx = 0.05 + s * 0.15;
        eRx = -0.05;
        sRz = -0.02;
      }
    }
    if (!moving) {
      spX += Math.sin(t * 1.3) * 0.04;
      sLx += Math.sin(t * 1.7) * 0.08;
      sRx += Math.cos(t * 1.5) * 0.08;
    }
    jaw = 0.15 + Math.abs(Math.sin(t * 3 + g.seed)) * 0.12;
  } else if (z.anim === 2) {
    const w = Math.sin(t * (run ? 9 : 6));
    spX = 0.4;
    hL = 0.2;
    hR = -0.1;
    kL = 0.35;
    kR = 0.25;
    hipY = 0.9;
    sLx = -1.75 + w * 0.35 - z.pullT * 2;
    sRx = -1.75 - w * 0.35 - z.pullT * 2;
    eLx = -0.25 - Math.max(0, w) * 0.5;
    eRx = -0.25 - Math.max(0, -w) * 0.5;
    jaw = 0.45 + Math.abs(w) * 0.2;
  } else if (z.anim === 3) {
    const k = z.climbK,
      b = Math.sin(k * Math.PI);
    spX = 0.3 + b * 0.5;
    hL = -b * 1.4;
    hR = -b * 0.6;
    kL = 0.2 + b * 1.8;
    kR = 0.2 + b * 1.2;
    sLx = -1.2 + b * 0.5;
    sRx = -1.4 + b * 0.5;
    eLx = -0.4;
    eRx = -0.4;
    hipY = 0.95 - b * 0.15;
  } else if (z.anim === 6) {
    const w2 = Math.sin(t * 9);
    spX = 0.75;
    hL = -0.35;
    kL = 0.5;
    hR = 0.2;
    kR = 0.3;
    hipY = 0.9;
    nkX = -0.3;
    sRx = -1.62 + w2 * 0.12;
    sRz = -0.05 + w2 * 0.35;
    eRx = -0.04;
    sLx = -1.45 - Math.max(0, w2) * 0.3;
    sLz = 0.25;
    eLx = -0.35;
    jaw = 0.7;
  } else if (z.anim === 4) {
    const k = clamp(1 - z.atkT / 0.9, 0, 1);
    const up = smooth(seg(k, 0, 0.4)),
      down = smooth(seg(k, 0.4, 0.6));
    sRx = lerp(-1.2, -2.9, up) + down * 2.4;
    sRz = lerp(-0.1, -0.5, up) + down * 0.9;
    eRx = -0.3 - up * 0.6 + down * 0.5;
    sLx = -1.4 - up * 0.3;
    eLx = -0.4;
    spY = lerp(0.2, -0.35, down) + up * 0.15;
    spX = 0.25 + down * 0.2;
    jaw = 0.6;
    hL = -0.2;
    kL = 0.3;
    hR = 0.15;
    kR = 0.1;
  }
  {
    const ddx = z.x - (z.lx ?? z.x),
      ddz = z.z - (z.lz ?? z.z);
    z.lx = z.x;
    z.lz = z.z;
    const lat = dt > 0 ? (ddx * Math.cos(z.yaw) - ddz * Math.sin(z.yaw)) / dt : 0;
    z.lean = damp(z.lean || 0, clamp(lat * 0.09, -0.45, 0.45), 10, dt);
    spZ += z.lean;
  }
  r.hips.position.y = hipY;
  r.hips.rotation.y = spY * 0.4;
  r.spine.rotation.set(spX - z.flinch * 0.5, spY, spZ);
  r.neck.rotation.set(nkX - spX * 0.45 - z.hflinch * 0.8 + z.twA * 0.3, z.twA * 0.5, 0);
  r.head.rotation.set(0, 0, hdZ + z.twA * 0.4);
  r.jaw.rotation.x = jaw + (z.voiceT > 0 ? Math.abs(Math.sin(t * 18)) * 0.3 : 0);
  r.hL.rotation.x = hL;
  r.hR.rotation.x = hR;
  r.kL.rotation.x = kL;
  r.kR.rotation.x = kR;
  r.sL.rotation.set(sLx, 0, sLz);
  r.sR.rotation.set(sRx, 0, sRz);
  r.eL.rotation.x = eLx;
  r.eR.rotation.x = eRx;
  if (r.strips) {
    r.strips.forEach((st, i) => {
      st.rotation.x = 0.2 + Math.sin(t * 6 + i * 2) * 0.15 * (moving ? 2 : 0.6) + (run ? 0.4 : 0);
      st.rotation.z = Math.sin(t * 4 + i) * 0.12;
    });
  }
  r.root.rotation.x = 0;
  r.root.rotation.z = 0;
  r.root.position.set(z.x, z.y, z.z);
  r.root.rotation.y = z.yaw;
}

function zSounds(z, dt) {
  if (z.dead) {
    return;
  }
  const d = Math.hypot(z.x - ME.x, z.z - ME.z);
  if (d > 40) {
    return;
  }
  z.groanT -= dt;
  if (z.groanT <= 0) {
    const pace = z.anim === 0 ? clamp(z.moveSpd / 4, 0, 1) : z.anim === 2 || z.anim === 6 ? 0.55 : 0.2;
    let name, gap;
    if (z.kind === 'sprint' && pace > 0.6) {
      name = Math.random() < 0.75 ? 'z_shriek' : 'z_pant';
      gap = rand(1.1, 2.3);
    } else if (z.kind !== 'walk' && pace > 0.45) {
      name = Math.random() < 0.45 ? 'z_scream' : Math.random() < 0.5 ? 'z_growl' : 'z_pant';
      gap = rand(1.8, 3.6);
    } else if (z.anim === 2 || z.anim === 6) {
      name = Math.random() < 0.6 ? 'z_growl' : 'z_groan';
      gap = rand(2, 4);
    } else {
      name = Math.random() < 0.8 ? 'z_groan' : 'z_growl';
      gap = rand(3.5, 7.5);
    }
    z.groanT = gap;
    const s = AU.zvoice(name, [z.x, 1.6, z.z], pace > 0.45);
    if (s) {
      z.voiceT = s.buffer.duration * 0.8;
    }
  }
  if (z.anim === 0 && z.moveSpd > 0.2 && d < 12) {
    z.stepT -= dt * z.moveSpd;
    if (z.stepT <= 0) {
      z.stepT = z.kind === 'walk' ? 0.9 : 1.3;
      AU.play('z_step', {
        pos: [z.x, 0.1, z.z],
        g: 0.5,
        rr: 0.15,
        bus: 'zom',
      });
    }
  }
}

function roundHealth(r) {
  const d = DIFF[G.diff];
  return (r < 10 ? 150 + 100 * (r - 1) : 950 * Math.pow(1.1, r - 9)) * d.hp;
}

const DIFF = {
  easy: {
    hp: 0.75,
    dmg: 40,
    spd: 0.95,
    label: 'Easy',
  },
  normal: {
    hp: 1,
    dmg: 50,
    spd: 1,
    label: 'Normal',
  },
  hard: {
    hp: 1.3,
    dmg: 60,
    spd: 1.1,
    label: 'Hard',
  },
};

function spawnZombieHost() {
  const act = WORLD.windows.filter((w) => roomOpen(w.room));
  if (!act.length) {
    return false;
  }
  const pl = playersAll().filter((p) => !p.down && !p.dead);
  let pickW;
  if (pl.length && Math.random() < 0.7) {
    const p = pick(pl);
    const near = act
      .slice()
      .sort((a, b) => Math.hypot(a.x - p.x, a.z - p.z) - Math.hypot(b.x - p.x, b.z - p.z));
    pickW = near[Math.min(near.length - 1, (Math.random() * Math.min(3, near.length)) | 0)];
  } else {
    pickW = pick(act);
  }
  const r = G.round,
    roll = Math.random();
  const sprintC = r >= 7 ? Math.min(0.5, (r - 6) * 0.08) : 0,
    runC = clamp((r - 2) * 0.14, 0, 0.9);
  const kind = roll < sprintC ? 'sprint' : roll < runC ? 'run' : 'walk';
  const z = zCreate(ZID++, kind);
  const w = pickW;
  const tx = -w.nz,
    tz = w.nx;
  const lat = rand(-4, 4),
    far = rand(12, 18);
  z.x = w.x + w.nx * far + tx * lat;
  z.z = w.z + w.nz * far + tz * lat;
  z.y = 0;
  z.yaw = Math.atan2(-w.nx, -w.nz);
  z.win = w;
  z.state = 'approach';
  z.hp = z.maxHp = roundHealth(r);
  z.speed =
    (kind === 'sprint' ? rand(3.7, 4.2) : kind === 'run' ? rand(2.5, 2.95) : rand(0.95, 1.3)) *
    DIFF[G.diff].spd;
  z.tearD = kind === 'walk' ? 1.4 : 0.85;
  z.lastX = z.x;
  z.lastZ = z.z;
  z.stuck = 0;
  z.atkCD = 0;
  return true;
}

function zMove(z, dx, dz) {
  if (freeAt(z.x + dx, z.z)) {
    z.x += dx;
  }
  if (freeAt(z.x, z.z + dz)) {
    z.z += dz;
  }
}

function zUpdateHost(dt) {
  const pl = playersAll();
  const targets = pl.filter((p) => !p.down && !p.dead && !p.hidden);
  G.flowT -= dt;
  if (G.flowT <= 0) {
    flowField(targets.map((p) => [p.x, p.z]));
    G.flowT = 0.25;
  }
  for (let i = ZBS.length - 1; i >= 0; i--) {
    const z = ZBS[i];
    if (z.dead) {
      if (z.deathT > 7) {
        zRemove(z);
      }
      continue;
    }
    const px = z.x,
      pz = z.z;
    const w = z.win;
    if (z.state === 'approach') {
      const qi = w.busy && w.busy !== z;
      const tx = w.outer.x + (qi ? -w.nz * ((z.id % 3) - 1) * 1.1 + w.nx * 1.4 : 0),
        tz = w.outer.z + (qi ? w.nx * ((z.id % 3) - 1) * 1.1 + w.nz * 1.4 : 0);
      const dx = tx - z.x,
        dz = tz - z.z,
        d = Math.hypot(dx, dz);
      if (d > 0.1) {
        const sp = Math.min(d, z.speed * dt);
        z.x += (dx / d) * sp;
        z.z += (dz / d) * sp;
        z.yaw = Math.atan2(dx, dz);
        z.anim = 0;
      } else {
        z.anim = 1;
        z.yaw = Math.atan2(-w.nx, -w.nz);
        if (!w.busy || w.busy === z) {
          w.busy = z;
          if (qi) {
          } else {
            z.state = G.boards[w.i] > 0 ? 'tear' : 'climb';
            z.tT = z.tearD;
            z.climbT = 0;
          }
        }
      }
    } else if (z.state === 'tear') {
      z.anim = 2;
      z.yaw = Math.atan2(-w.nx, -w.nz);
      z.tT -= dt;
      const near = targets.find((p) => Math.hypot(p.x - w.inner.x, p.z - w.inner.z) < 1.6);
      z.atkCD -= dt;
      if (z.reachT > 0) {
        z.reachT -= dt;
        z.anim = 6;
        const k = 1 - z.reachT / 1.1;
        const inK = Math.sin(Math.min(1, k * 1.25) * Math.PI);
        const rd = lerp(w.dock ? 1.45 : 1.15, 0.5, inK);
        z.x = w.x + w.nx * rd;
        z.z = w.z + w.nz * rd;
        if (!z.hitDone && k > 0.45) {
          z.hitDone = true;
          if (near) {
            hurtPlayer(near, DIFF[G.diff].dmg, z);
          }
        }
        if (z.reachT <= 0) {
          z.x = w.outer.x;
          z.z = w.outer.z;
          z.anim = 2;
        }
        z.tT += dt;
      } else if (near && G.boards[w.i] <= 4 && z.atkCD <= 0) {
        z.atkCD = 1.9;
        z.reachT = 1.1;
        z.hitDone = false;
        z.anim = 6;
        AU.zvoice('z_snarl', [z.x, 1.6, z.z]);
      }
      if (z.tT <= 0) {
        if (G.boards[w.i] > 0) {
          G.boards[w.i]--;
          broadcast(['rip', w.i, z.id]);
        }
        z.tT = z.tearD;
        if (G.boards[w.i] <= 0) {
          z.state = 'climb';
          z.climbT = 0;
        }
      }
    } else if (z.state === 'climb') {
      if (G.boards[w.i] > 0) {
        z.state = 'tear';
        z.tT = z.tearD;
        continue;
      }
      z.anim = 3;
      const dur = z.kind === 'walk' ? 1.4 : 0.85;
      z.climbT += dt;
      const k = Math.min(1, z.climbT / dur);
      z.climbK = k;
      z.x = lerp(w.outer.x, w.inner.x, k);
      z.z = lerp(w.outer.z, w.inner.z, k);
      z.y = Math.sin(k * Math.PI) * 0.55 + (k < 0.5 ? k * 1.4 : (1 - k) * 1.4) * 0.6;
      z.yaw = Math.atan2(-w.nx, -w.nz);
      if (k >= 1) {
        z.state = 'chase';
        z.y = 0;
        if (w.busy === z) {
          w.busy = null;
        }
        AU.play('land', {
          pos: [z.x, 0, z.z],
          g: 0.6,
        });
      }
    } else if (z.state === 'chase') {
      let best = null,
        bd = 1e9;
      for (const p of targets) {
        const d = Math.hypot(p.x - z.x, p.z - z.z);
        if (d < bd) {
          bd = d;
          best = p;
        }
      }
      if (z.atkT > 0) {
        z.atkT -= dt;
        z.anim = 4;
        if (!z.hitDone && z.atkT < 0.45) {
          z.hitDone = true;
          if (best && bd < 1.55) {
            hurtPlayer(best, DIFF[G.diff].dmg, z);
          }
        }
        if (best) {
          z.yaw = damp(z.yaw, z.yaw + wrapA(Math.atan2(best.x - z.x, best.z - z.z) - z.yaw), 6, dt);
        }
      } else if (!best) {
        z.anim = 1;
      } else if (bd < 1.15 && Math.abs(wrapA(Math.atan2(best.x - z.x, best.z - z.z) - z.yaw)) < 1) {
        z.atkT = 0.9;
        z.hitDone = false;
        z.anim = 4;
        z.jukeT = 0;
        AU.zvoice('z_snarl', [z.x, 1.6, z.z]);
      } else {
        let tx = best.x,
          tz = best.z;
        if (!(bd < 2.5 || losGrid(z.x, z.z, best.x, best.z))) {
          const c = cellOf(z.x, z.z);
          if (c >= 0) {
            const ci = c % GR.nx,
              cj = (c / GR.nx) | 0;
            let bv = dist[c],
              bk = -1;
            for (let n = 0; n < 8; n++) {
              const ni = ci + N8[n][0],
                nj = cj + N8[n][1];
              if (ni < 0 || nj < 0 || ni >= GR.nx || nj >= GR.nz) {
                continue;
              }
              const k = nj * GR.nx + ni;
              if (blocked[k]) {
                continue;
              }
              if (n >= 4 && (blocked[cj * GR.nx + ni] || blocked[nj * GR.nx + ci])) {
                continue;
              }
              if (dist[k] < bv) {
                bv = dist[k];
                bk = k;
              }
            }
            if (bk >= 0) {
              tx = GR.x0 + ((bk % GR.nx) + 0.5) * GR.cs;
              tz = GR.z0 + (((bk / GR.nx) | 0) + 0.5) * GR.cs;
            }
          }
        }
        let vx = tx - z.x,
          vz = tz - z.z;
        const vl = Math.hypot(vx, vz) || 1;
        vx /= vl;
        vz /= vl;
        for (const o of ZBS) {
          if (o === z || o.dead || o.state !== 'chase') {
            continue;
          }
          const ox = z.x - o.x,
            oz = z.z - o.z,
            od = Math.hypot(ox, oz);
          if (od < 0.65 && od > 0.001) {
            vx += (ox / od) * (0.65 - od) * 3;
            vz += (oz / od) * (0.65 - od) * 3;
          }
        }
        if (z.hd == null) {
          z.hd = z.yaw;
        }
        const want = Math.atan2(vx, vz);
        const turn = z.kind === 'sprint' ? 5.2 : z.kind === 'run' ? 4.2 : 3;
        const diff = wrapA(want - z.hd);
        z.hd += clamp(diff, -turn * dt, turn * dt);
        let spMul = Math.abs(diff) > 1.7 ? 0.45 : Math.abs(diff) > 0.9 ? 0.75 : 1;
        let mx = Math.sin(z.hd),
          mz = Math.cos(z.hd);
        if (z.jukeCD == null) {
          z.jukeCD = rand(0.4, 1.2);
        }
        z.jukeCD -= dt;
        if (
          z.kind !== 'walk' &&
          G.round >= 6 &&
          bd > 2.5 &&
          bd < 14 &&
          z.jukeCD <= 0 &&
          !(z.jukeT > 0) &&
          Math.random() < dt * 2.2
        ) {
          z.jukeT = rand(0.3, 0.45);
          z.jukeS = Math.random() < 0.5 ? -1 : 1;
          z.jukeCD = rand(1, 2.4);
        }
        if (z.jukeT > 0) {
          z.jukeT -= dt;
          const rx = Math.cos(z.hd) * z.jukeS,
            rz = -Math.sin(z.hd) * z.jukeS;
          mx = mx * 0.45 + rx;
          mz = mz * 0.45 + rz;
          const ml = Math.hypot(mx, mz);
          mx /= ml;
          mz /= ml;
          spMul *= 1.35;
        }
        const sp = z.speed * dt * spMul * (z.flinch > 0.3 ? 0.4 : 1);
        zMove(z, mx * sp, mz * sp);
        z.anim = 0;
        z.yaw = z.hd;
      }
      for (const p of pl) {
        if (p.dead) {
          continue;
        }
        const d = Math.hypot(z.x - p.x, z.z - p.z);
        if (d < 0.7 && d > 0.001) {
          zMove(z, ((z.x - p.x) / d) * (0.7 - d), ((z.z - p.z) / d) * (0.7 - d));
        }
      }
      z.stuck += dt;
      if (z.stuck > 5) {
        const mv = Math.hypot(z.x - z.lastX, z.z - z.lastZ);
        if (mv < 0.6 && bd > 3) {
          zRemove(z);
          G.toSpawn++;
          continue;
        }
        z.stuck = 0;
        z.lastX = z.x;
        z.lastZ = z.z;
      }
    }
    z.moveSpd = Math.hypot(z.x - px, z.z - pz) / Math.max(dt, 1e-4);
  }
}

function zHitHost(id, dmg, part, src, peer) {
  const z = zById(id);
  if (!z || z.dead || z.hp == null) {
    return;
  }
  if (G.instakill > 0) {
    dmg = z.hp + 1;
  }
  z.hp -= dmg;
  z.flinch = Math.min(1.2, z.flinch + 0.5);
  if (z.hp <= 0) {
    if (z.win && z.win.busy === z) {
      z.win.busy = null;
    }
    const dtype = src === 'gale' ? 3 : src === 'volt' ? 4 : randi(0, 2);
    broadcast(['k', id, peer, part, src, dtype]);
    if (z.state === 'chase' && G.drops < 4 && Math.random() < 0.03) {
      G.drops++;
      spawnPU(z.x, z.z);
    }
  }
}

function zApplySnapshot(list) {
  const seen = new Set();
  for (const e of list) {
    const [id, x, zz, y, yaw, anim, kc] = e;
    seen.add(id);
    let z = zById(id);
    if (!z) {
      z = zCreate(id, ['walk', 'run', 'sprint'][kc] || 'walk');
      z.x = z.tx = x / 10;
      z.z = z.tz = zz / 10;
      z.y = z.ty = y / 100;
      z.yaw = z.tyaw = yaw / 100;
    }
    if (z.dead) {
      continue;
    }
    z.tx = x / 10;
    z.tz = zz / 10;
    z.ty = y / 100;
    z.tyaw = yaw / 100;
    if (anim === 4 && z.anim !== 4) {
      z.atkT = 0.9;
    }
    z.anim = anim;
    z.climbK = anim === 3 ? clamp((z.climbK || 0) + 0.05, 0, 1) : 0;
  }
  for (const z of ZBS) {
    if (!seen.has(z.id) && !z.dead) {
      if (z.gone == null) {
        z.gone = 0;
      }
    } else {
      z.gone = null;
    }
  }
}

function zUpdateClient(dt) {
  for (let i = ZBS.length - 1; i >= 0; i--) {
    const z = ZBS[i];
    if (z.dead) {
      if (z.deathT > 6.5) {
        zRemove(z);
      }
      continue;
    }
    if (z.gone != null) {
      z.gone += dt;
      if (z.gone > 0.6) {
        zRemove(z);
        continue;
      }
    }
    const px = z.x,
      pz = z.z;
    const far = Math.hypot(z.tx - z.x, z.tz - z.z) > 3;
    z.x = far ? z.tx : damp(z.x, z.tx, 12, dt);
    z.z = far ? z.tz : damp(z.z, z.tz, 12, dt);
    z.y = damp(z.y, z.ty, 14, dt);
    z.yaw += wrapA(z.tyaw - z.yaw) * Math.min(1, dt * 12);
    if (z.anim === 4) {
      z.atkT = Math.max(0, z.atkT - dt);
    }
    if (z.anim === 3) {
      z.climbK = Math.min(1, z.climbK + dt / 1.1);
    }
    z.moveSpd = damp(z.moveSpd, Math.hypot(z.x - px, z.z - pz) / Math.max(dt, 1e-4), 8, dt);
  }
}

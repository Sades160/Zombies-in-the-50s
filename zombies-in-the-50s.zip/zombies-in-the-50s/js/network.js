const CR_STATES = ['idle', 'rolling', 'ready', 'closing', 'moving'];

const KINDS = ['walk', 'run', 'sprint'];

const NET = {
  room: null,
  avail: false,
  connected: false,
  me: 'local',
  role: 'solo',
  host: null,
  gid: 0,
  lobby: false,
  out: [],
  seq: 0,
  lastSeen: {},
  peers: [],
  rp: new Map(),
  sendT: 0,
  lobbyDiff: 'normal',
  async init() {
    try {
      if (window.claude && typeof window.claude.use === 'function') {
        this.room = await window.claude.use('room');
      }
    } catch (e) {
      this.room = null;
    }
    if (!this.room) {
      this.room = await wsRoom((late) => this.attach(late));
      this.self = !!this.room;
    }
    if (!this.room) {
      this.avail = false;
      uiCoopAvail();
      return;
    }
    this.attach(this.room);
  },
  attach(room) {
    if (this.attached) {
      return;
    }
    this.attached = true;
    this.room = room;
    this.self = this.self || !!room.__ws;
    this.avail = true;
    uiCoopAvail();
    this.room.onPeers(
      (ch) => {
        this.peers = ch.peers;
        const mine = ch.peers.find((p) => p.sameTab);
        if (mine) {
          this.me = mine.peer;
        }
        this.onPeers(ch);
      },
      () => {
        this.avail = false;
        this.connected = false;
        uiCoopAvail();
      },
    );
    this.room.onConnection(
      (c) => {
        this.connected = c;
        uiLobby();
      },
      () => {},
    );
    this.pres({
      m: 'menu',
      n: SET.game.name,
      r: null,
      h: null,
      L: null,
      g: null,
      e: [],
    });
  },
  retry() {
    if (this.attached || this.retrying) {
      return;
    }
    this.retrying = true;
    wsRoom((late) => this.attach(late)).then((r) => {
      this.retrying = false;
      if (r) {
        this.attach(r);
      }
    });
  },
  pres(patch) {
    if (!this.room) {
      return;
    }
    this.room.presence(patch).catch(() => {});
  },
  push(ev) {
    if (G.net === 'solo') {
      return;
    }
    this.seq++;
    this.out.push([this.seq].concat(ev));
    if (this.out.length > 30) {
      this.out.shift();
    }
  },
  nameOf(peer) {
    const p = this.peers.find((x) => x.peer === peer);
    return p && p.presence && p.presence.n ? cleanName(p.presence.n) : 'Someone';
  },
  hosts() {
    return this.peers.filter(
      (p) =>
        !p.sameTab &&
        p.presence &&
        p.presence.r === 'host' &&
        p.presence.L &&
        (p.presence.m === 'lobby' || p.presence.m === 'game'),
    );
  },
  squadOf(hostPeer) {
    return this.peers.filter(
      (p) => p.peer === hostPeer || (p.presence && p.presence.r === 'client' && p.presence.h === hostPeer),
    );
  },
  remotes() {
    return [...this.rp.values()];
  },
  remote(peer) {
    return this.rp.get(peer);
  },
  inMyGame(p) {
    if (p.sameTab || !p.presence) {
      return false;
    }
    const s = p.presence;
    if (G.net === 'host') {
      return s.r === 'client' && s.h === this.me && s.m === 'game' && s.gid === this.gid;
    }
    if (G.net === 'client') {
      return p.peer === this.host || (s.r === 'client' && s.h === this.host && s.m === 'game');
    }
    return false;
  },
  onPeers(ch) {
    if (ch.left.some((p) => p.peer === this.host) && this.role === 'client') {
      this.hostGone();
    }
    if (this.role === 'client') {
      const hp = this.peers.find((p) => p.peer === this.host);
      const hs = hp && hp.presence;
      if (hs && hs.r !== 'host') {
        this.hostGone();
      } else if (
        hs &&
        hs.m === 'game' &&
        hs.L &&
        hs.gid &&
        (G.mode !== 'play' || G.net !== 'client' || this.gid !== hs.gid) &&
        this.lobby
      ) {
        this.gid = hs.gid;
        G.diff = DIFF[hs.L.diff] ? hs.L.diff : 'normal';
        uiStartClient();
      }
    }
    const seen = new Set();
    for (const p of this.peers) {
      if (!this.inMyGame(p)) {
        continue;
      }
      seen.add(p.peer);
      const s = p.presence;
      let r = this.rp.get(p.peer);
      if (!r) {
        r = {
          peer: p.peer,
          x: 0,
          z: 0,
          y: 0,
          yaw: 0,
          pitch: 0,
          gun: 'warden',
          shots: 0,
          down: false,
          dead: false,
          crouch: false,
          name: 'Someone',
          pts: 0,
          st: {
            kills: 0,
            heads: 0,
            downs: 0,
            revives: 0,
          },
          wp: [],
        };
        this.rp.set(p.peer, r);
        if (Array.isArray(s.e) && s.e.length) {
          this.lastSeen[p.peer] = Math.max(...s.e.map((e) => +e[0] || 0));
        }
      }
      r.name = cleanName(s.n);
      const P = s.p;
      if (Array.isArray(P) && P.length >= 8) {
        r.x = +P[0] / 100 || 0;
        r.z = +P[1] / 100 || 0;
        r.y = +P[2] / 100 || 0;
        r.yaw = +P[3] / 100 || 0;
        r.pitch = +P[4] / 100 || 0;
        r.gun = GUN_IDS[P[5]] || 'warden';
        r.shots = +P[6] || 0;
        const f = +P[7] || 0;
        r.down = !!(f & 1);
        r.dead = !!(f & 2);
        r.crouch = !!(f & 16);
        r.prone = !!(f & 32);
        r.hidden = !!(f & 64);
      }
      r.pts = +s.pts || 0;
      if (Array.isArray(s.st)) {
        r.st = {
          kills: +s.st[0] || 0,
          heads: +s.st[1] || 0,
          downs: +s.st[2] || 0,
          revives: +s.st[3] || 0,
        };
      }
      r.wp = Array.isArray(s.wp) ? s.wp.map((i) => GUN_IDS[i]).filter(Boolean) : [];
      if (Array.isArray(s.e)) {
        const last = this.lastSeen[p.peer] || 0;
        let mx = last;
        for (const e of s.e) {
          if (!Array.isArray(e)) {
            continue;
          }
          const sq = +e[0];
          if (!(sq > last)) {
            continue;
          }
          mx = Math.max(mx, sq);
          this.handleRemoteEvent(p.peer, e.slice(1));
        }
        this.lastSeen[p.peer] = mx;
      }
      if (G.net === 'client' && p.peer === this.host && s.g && typeof s.g === 'object') {
        this.applySnapshot(s.g);
      }
    }
    for (const k of [...this.rp.keys()]) {
      if (!seen.has(k)) {
        this.rp.delete(k);
      }
    }
    uiLobby();
  },
  handleRemoteEvent(peer, ev) {
    if (G.mode !== 'play' && G.mode !== 'over') {
      return;
    }
    const ty = ev[0];
    if (ty === 'rev') {
      handleRevive(peer, ev[1]);
      return;
    }
    if (ty === 'gx') {
      if (typeof ev[1] === 'number') {
        explodeFX(ev[1], ev[2], ev[3]);
      }
      return;
    }
    if (G.net === 'host') {
      const ok = ['hit', 'door', 'board', 'power', 'crate', 'crtake', 'pu', 'candypu'];
      if (ok.includes(ty)) {
        handleEvent(peer, ev);
      }
    } else if (G.net === 'client' && peer === this.host) {
      handleBroadcast(ev);
    }
  },
  applySnapshot(g) {
    if (G.mode !== 'play') {
      return;
    }
    if (typeof g.r === 'number') {
      G.round = g.r;
    }
    if (typeof g.b === 'string') {
      for (let i = 0; i < WORLD.windows.length; i++) {
        const n = +g.b[i];
        if (n >= 0 && n <= 6 && n !== G.boards[i]) {
          const w = WORLD.windows[i];
          const prev = G.boards[i];
          G.boards[i] = n;
          syncBoards(w, n, true);
          if (n < prev) {
            AU.play('rip', {
              pos: [w.x, 1.4, w.z],
              wet: 0.3,
            });
          }
        }
      }
    }
    if (typeof g.d === 'string') {
      WORLD.doors.forEach((d, i) => {
        if (g.d[i] === '1' && !d.open) {
          setDoorOpen(d, true, true);
        }
      });
    }
    if (g.pw && !G.power) {
      setPower(true, true);
    }
    if (Array.isArray(g.cr)) {
      const [sc, t, spot, ri, owner] = g.cr;
      G.crate.state = CR_STATES[sc] || 'idle';
      G.crate.t = (+t || 0) / 10;
      G.crate.spot = clamp(+spot || 0, 0, WORLD.crate.spots.length - 1);
      G.crate.result = GUN_IDS[ri] || null;
      G.crate.owner = owner || null;
    }
    if (Array.isArray(g.pu)) {
      G.pus = g.pu.filter(Array.isArray).map(([id, ti, x, z, t]) => ({
        id: id,
        type: PU_TYPES[ti] || 'resupply',
        x: x / 10,
        z: z / 10,
        t: +t || 0,
      }));
    }
    G.instakill = +g.ik || 0;
    G.doublepay = +g.dp || 0;
    if (Array.isArray(g.z)) {
      zApplySnapshot(g.z.filter((e) => Array.isArray(e) && e.length >= 7));
    }
    if (g.ov && G.mode === 'play') {
      gameOver();
    }
  },
  snapshot() {
    return {
      r: G.round,
      b: G.boards.join(''),
      d: WORLD.doors.map((d) => (d.open ? 1 : 0)).join(''),
      pw: G.power ? 1 : 0,
      cr: [
        CR_STATES.indexOf(G.crate.state),
        Math.round(G.crate.t * 10),
        G.crate.spot,
        GUN_IDS.indexOf(G.crate.result),
        G.crate.owner,
      ],
      pu: G.pus.map((p) => [
        p.id,
        PU_TYPES.indexOf(p.type),
        Math.round(p.x * 10),
        Math.round(p.z * 10),
        Math.round(p.t),
      ]),
      ik: Math.ceil(G.instakill),
      dp: Math.ceil(G.doublepay),
      z: ZBS.filter((z) => !z.dead)
        .slice(0, 28)
        .map((z) => [
          z.id,
          Math.round(z.x * 10),
          Math.round(z.z * 10),
          Math.round(z.y * 100),
          Math.round(z.yaw * 100),
          z.anim,
          KINDS.indexOf(z.kind),
        ]),
      ov: G.over ? 1 : 0,
    };
  },
  tick(dt) {
    if (G.net === 'solo' || !this.room) {
      return;
    }
    this.sendT += dt;
    if (this.sendT < 0.05) {
      return;
    }
    this.sendT = 0;
    const flags =
      (ME.down ? 1 : 0) |
      (ME.dead ? 2 : 0) |
      (ME.adsK > 0.5 ? 4 : 0) |
      (ME.sprinting ? 8 : 0) |
      (ME.crouch > 0.5 ? 16 : 0) |
      (ME.prone > 0.5 ? 32 : 0) |
      (candyActive('ghost') ? 64 : 0);
    const patch = {
      m: 'game',
      gid: this.gid,
      n: SET.game.name,
      p: [
        Math.round(ME.x * 100),
        Math.round(ME.z * 100),
        Math.round(ME.y * 100),
        Math.round(ME.yaw * 100),
        Math.round(ME.pitch * 100),
        GUN_IDS.indexOf(curW().id),
        ME.shots,
        flags,
      ],
      pts: ME.pts,
      st: [ME.stats.kills, ME.stats.heads, ME.stats.downs, ME.stats.revives],
      wp: ME.weapons.map((w) => GUN_IDS.indexOf(w.id)),
      e: this.out,
    };
    if (G.net === 'host') {
      patch.g = this.snapshot();
    }
    let txt = JSON.stringify(patch);
    while (txt.length > 3900 && this.out.length) {
      this.out.shift();
      patch.e = this.out;
      txt = JSON.stringify(patch);
    }
    if (txt.length > 3900 && patch.g) {
      patch.g.z = patch.g.z.slice(0, 16);
    }
    this.pres(patch);
  },
  host_() {
    this.role = 'host';
    this.host = this.me;
    this.lobby = true;
    this.gid = randi(1, 1e9);
    this.pres({
      m: 'lobby',
      r: 'host',
      h: null,
      L: {
        map: 'depot',
        diff: G.diff,
        st: 0,
      },
      gid: this.gid,
      n: SET.game.name,
      e: [],
      g: null,
    });
    uiLobby();
  },
  join(hostPeer) {
    const hp = this.peers.find((p) => p.peer === hostPeer);
    if (!hp) {
      return;
    }
    if (this.squadOf(hostPeer).length >= 4) {
      uiLobbyNote('That game is full.');
      return;
    }
    this.role = 'client';
    this.host = hostPeer;
    this.lobby = true;
    this.pres({
      m: 'lobby',
      r: 'client',
      h: hostPeer,
      L: null,
      n: SET.game.name,
      e: [],
      g: null,
    });
    const s = hp.presence;
    if (s.m === 'game' && s.gid) {
      this.gid = s.gid;
      G.diff = DIFF[s.L && s.L.diff] ? s.L.diff : 'normal';
      uiStartClient();
    }
    uiLobby();
  },
  leave() {
    this.role = 'solo';
    this.host = null;
    this.lobby = false;
    this.rp.clear();
    this.lastSeen = {};
    this.out = [];
    this.pres({
      m: 'menu',
      r: null,
      h: null,
      L: null,
      g: null,
      e: [],
      gid: 0,
    });
    uiLobby();
  },
  startHosting() {
    this.gid = randi(1, 1e9);
    this.rp.clear();
    this.lastSeen = {};
    this.out = [];
    this.pres({
      m: 'game',
      r: 'host',
      L: {
        map: 'depot',
        diff: G.diff,
        st: 1,
      },
      gid: this.gid,
    });
  },
  hostGone() {
    if (this.role !== 'client') {
      return;
    }
    const inGame = G.mode === 'play' || G.mode === 'paused';
    this.leave();
    if (inGame) {
      G.mode = 'menu';
      uiToMenu();
    }
    uiLobbyNote('The host left the game.');
    showNet('The host left the game.');
  },
};

function wsRoom(onLate) {
  let url = window.DEPOT9_SERVER || '';
  if (
    !url &&
    window.Z50_SAME_ORIGIN_SERVER !== false &&
    /^https?:$/.test(location.protocol) &&
    location.hostname !== 'local' &&
    !/claude\.ai|claudeusercontent|anthropic|github\.io|netlify\.app|pages\.dev|vercel\.app|itch\.(io|zone)/.test(
      location.hostname,
    )
  ) {
    url = (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/ws';
  }
  if (!url) {
    return Promise.resolve(null);
  }
  const roomName =
    (new URLSearchParams(location.search).get('room') || 'public')
      .replace(/[^a-z0-9_-]/gi, '')
      .slice(0, 32) || 'public';
  return new Promise((resolve) => {
    let ws;
    try {
      ws = new WebSocket(url + (url.includes('?') ? '&' : '?') + 'room=' + roomName);
    } catch (e) {
      resolve(null);
      return;
    }
    const peers = new Map();
    let me = null,
      mine = {},
      conn = false,
      pending = null;
    const ph = [],
      ch = [];
    const view = () => [...peers.values()];
    const put = (id, p) => {
      const had = peers.has(id);
      peers.set(
        id,
        Object.freeze({
          peer: id,
          by: null,
          isMe: id === me,
          sameTab: id === me,
          kind: 'viewer',
          guest: false,
          presence: Object.freeze(Object.assign({}, p || {})),
          updatedAt: Date.now(),
        }),
      );
      return had;
    };
    let q = {
        joined: [],
        left: [],
        updated: [],
      },
      sched = false;
    const flush = () => {
      sched = false;
      const c = Object.assign(
        {
          peers: view(),
        },
        q,
      );
      q = {
        joined: [],
        left: [],
        updated: [],
      };
      ph.forEach((h) => h(c));
    };
    const queue = () => {
      if (!sched) {
        sched = true;
        setTimeout(flush, 0);
      }
    };
    const room = {
      presence(patch) {
        for (const k in patch) {
          if (patch[k] === null) {
            delete mine[k];
          } else {
            mine[k] = patch[k];
          }
        }
        if (me) {
          put(me, JSON.parse(JSON.stringify(mine)));
          q.updated.push(peers.get(me));
          queue();
        }
        if (ws.readyState === 1) {
          ws.send(
            JSON.stringify({
              t: 'p',
              p: patch,
            }),
          );
        } else {
          pending = Object.assign(pending || {}, patch);
        }
        return Promise.resolve();
      },
      onPeers(h) {
        ph.push(h);
        setTimeout(
          () =>
            h({
              peers: view(),
              joined: view(),
              left: [],
              updated: [],
            }),
          0,
        );
        return () => {};
      },
      onConnection(h) {
        ch.push(h);
        setTimeout(() => h(conn), 0);
        return () => {};
      },
      peers: view,
      connected: () => conn,
      emit: () => Promise.resolve(),
      on: () => () => {},
      __ws: true,
    };
    let settled = false;
    const done = (v) => {
      if (settled) {
        if (v && onLate) {
          onLate(v);
        }
        return;
      }
      settled = true;
      resolve(v);
    };
    const to = setTimeout(() => done(null), 1e4);
    ws.onmessage = (e) => {
      let m;
      try {
        m = JSON.parse(e.data);
      } catch (x) {
        return;
      }
      if (m.t === 'hi') {
        me = m.id;
        put(me, JSON.parse(JSON.stringify(mine)));
        (m.peers || []).forEach((p) => put(p.id, p.p));
        conn = true;
        ch.forEach((h) => h(true));
        clearTimeout(to);
        if (pending) {
          ws.send(
            JSON.stringify({
              t: 'p',
              p: pending,
            }),
          );
          pending = null;
        }
        q.joined.push(...view());
        queue();
        done(room);
      } else if (m.t === 'p' && m.id !== me) {
        const had = put(m.id, m.p);
        (had ? q.updated : q.joined).push(peers.get(m.id));
        queue();
      } else if (m.t === 'bye') {
        const p = peers.get(m.id);
        if (p) {
          peers.delete(m.id);
          q.left.push(p);
          queue();
        }
      }
    };
    ws.onclose = () => {
      conn = false;
      ch.forEach((h) => h(false));
      for (const [id, p] of peers) {
        if (id !== me) {
          peers.delete(id);
          q.left.push(p);
        }
      }
      queue();
      clearTimeout(to);
      done(null);
    };
    ws.onerror = () => {};
  });
}

function showNet(t) {
  const n = $('#netmsg');
  n.textContent = t;
  n.style.opacity = '1';
  setTimeout(() => (n.style.opacity = '0'), 3500);
}

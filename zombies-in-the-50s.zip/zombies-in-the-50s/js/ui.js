const SCREENS = ['scrTitle', 'scrMain', 'scrMaps', 'scrLobby', 'scrSettings', 'scrPause', 'scrOver'];

let screenStack = [];

function show(id, push = true) {
  if (push && screenStack[screenStack.length - 1] !== id) {
    screenStack.push(id);
  }
  SCREENS.forEach((s) => ($('#' + s).hidden = s !== id));
  const f = $('#' + id + ' button');
  if (f && !TOUCH) {
    setTimeout(
      () =>
        f.focus({
          preventScroll: true,
        }),
      30,
    );
  }
}

function hideScreens() {
  SCREENS.forEach((s) => ($('#' + s).hidden = true));
}

function back() {
  screenStack.pop();
  const prev = screenStack[screenStack.length - 1] || 'scrMain';
  if (prev === 'scrLobby') {
    NET;
  }
  show(prev, false);
  if (prev === 'scrPause') {
    uiPauseNote();
  }
}

$$('[data-back]').forEach((b) =>
  b.addEventListener('click', () => {
    if (screenStack[screenStack.length - 1] === 'scrLobby' && NET.role !== 'solo' && G.mode !== 'play') {
      NET.leave();
    }
    back();
  }),
);

function showTitle() {
  SCREENS.forEach((x) => ($('#' + x).hidden = true));
  $('#scrTitle').hidden = false;
}

function leaveTitle() {
  if ($('#scrTitle').hidden) {
    return;
  }
  $('#scrTitle').hidden = true;
  AU.init();
  AU.whenBuf('ui_start', () =>
    AU.play('ui_start', {
      g: 0.8,
    }),
  );
  menuMusic();
  screenStack = ['scrMain'];
  show('scrMain', false);
}

['keydown', 'pointerdown', 'touchstart'].forEach((ev) =>
  window.addEventListener(
    ev,
    () => {
      if (!$('#scrTitle').hidden) {
        setTimeout(leaveTitle, 0);
      }
    },
    {
      capture: true,
    },
  ),
);

let hoverEl = null;

document.addEventListener('pointerover', (e) => {
  const b =
    e.target.closest && e.target.closest('.mi, .btn, .tabs button, .seg button, .mapcard, .key, .tog');
  if (b && b !== hoverEl && !b.disabled) {
    hoverEl = b;
    AU.play('ui_hover', {
      g: 0.5,
      rr: 0.08,
    });
  } else if (!b) {
    hoverEl = null;
  }
});

document.addEventListener('focusin', (e) => {
  if (e.target.matches && e.target.matches('.mi, .btn') && PAD.active) {
    AU.play('ui_hover', {
      g: 0.5,
      rr: 0.08,
    });
  }
});

document.addEventListener(
  'click',
  (e) => {
    const b = e.target.closest && e.target.closest('button');
    if (!b || b.disabled || (G.mode === 'play' && !G.paused)) {
      return;
    }
    AU.play(b.matches('[data-back], #pQuit, #oMenu, #lobbyLeave') ? 'ui_back' : 'ui_click', {
      g: 0.6,
      rr: 0.05,
    });
  },
  true,
);

function updateBest() {
  const b = store.get('z50_best', 0);
  $('#bestNote').textContent = b ? `Best on this device: wave ${b}` : 'No record yet';
}

$('#mSolo').onclick = () => {
  AU.init();
  menuMusic();
  buildMapList();
  show('scrMaps');
};

$('#mCoop').onclick = () => {
  AU.init();
  menuMusic();
  if (!NET.avail) {
    NET.retry();
    return;
  }
  $('#nameInput').value = SET.game.name;
  show('scrLobby');
  uiLobby();
};

$('#mSettings').onclick = () => {
  AU.init();
  menuMusic();
  openSettings('video');
};

function menuMusic() {
  AU.whenBuf('mus_menu', () => {
    if (G.mode === 'menu' && !AU._menuOn) {
      AU._menuOn = true;
      AU.loop('menu', 'mus_menu', {
        bus: 'mus',
        g: 0.8,
      });
    }
  });
}

function uiCoopAvail() {
  const b = $('#mCoop');
  b.disabled = false;
  b.setAttribute('aria-disabled', !NET.avail);
  $('#coopNote').textContent = NET.avail
    ? NET.self
      ? 'Host or join a game on this server'
      : 'Host or join a game with people who have this page open'
    : 'Co-op needs a game server (see the README)';
}

function drawBlueprint(cv, M) {
  const g = cv.getContext('2d'),
    w = cv.width,
    h = cv.height;
  g.fillStyle = '#0f1c24';
  g.fillRect(0, 0, w, h);
  g.strokeStyle = 'rgba(160,200,220,.08)';
  g.lineWidth = 1;
  for (let x = 0; x < w; x += 16) {
    g.beginPath();
    g.moveTo(x, 0);
    g.lineTo(x, h);
    g.stroke();
  }
  for (let y = 0; y < h; y += 16) {
    g.beginPath();
    g.moveTo(0, y);
    g.lineTo(w, y);
    g.stroke();
  }
  const b = M.bounds,
    pad = 26,
    sx = (w - pad * 2) / (b.x1 - b.x0),
    sz = (h - pad * 2) / (b.z1 - b.z0),
    s = Math.min(sx, sz);
  const ox = (w - (b.x1 - b.x0) * s) / 2,
    oz = (h - (b.z1 - b.z0) * s) / 2;
  const X = (x) => ox + (x - b.x0) * s,
    Z = (z) => oz + (z - b.z0) * s;
  for (const k in M.rooms) {
    const r = M.rooms[k];
    g.fillStyle = k === 'R' ? 'rgba(208,40,28,.18)' : 'rgba(200,220,230,.05)';
    g.fillRect(X(r.x0), Z(r.z0), (r.x1 - r.x0) * s, (r.z1 - r.z0) * s);
    g.fillStyle = 'rgba(210,225,235,.75)';
    g.font = `${Math.max(10, s * 0.9)}px "Special Elite", monospace`;
    g.textAlign = 'center';
    g.fillText(r.name.toUpperCase(), X((r.x0 + r.x1) / 2), Z((r.z0 + r.z1) / 2) + 4);
  }
  g.strokeStyle = '#cfe0ea';
  g.lineWidth = 2.5;
  g.lineCap = 'square';
  for (const [axis, c, a0, a1, , , ops] of M.walls) {
    let cur = a0;
    const segs = [];
    for (const o of ops.slice().sort((p, q) => p.a - q.a)) {
      segs.push([cur, o.a]);
      cur = o.b;
    }
    segs.push([cur, a1]);
    for (const [a, bb] of segs) {
      g.beginPath();
      if (axis === 'x') {
        g.moveTo(X(a), Z(c));
        g.lineTo(X(bb), Z(c));
      } else {
        g.moveTo(X(c), Z(a));
        g.lineTo(X(c), Z(bb));
      }
      g.stroke();
    }
    for (const o of ops) {
      g.save();
      g.strokeStyle = o.w ? '#8fb7cc' : '#e0a040';
      g.lineWidth = o.w ? 1.5 : 3;
      g.setLineDash(o.w ? [3, 3] : []);
      g.beginPath();
      if (axis === 'x') {
        g.moveTo(X(o.a), Z(c));
        g.lineTo(X(o.b), Z(c));
      } else {
        g.moveTo(X(c), Z(o.a));
        g.lineTo(X(c), Z(o.b));
      }
      g.stroke();
      g.restore();
    }
  }
  g.fillStyle = '#e8dcc4';
  M.spawns.forEach(([x, z]) => {
    g.beginPath();
    g.arc(X(x), Z(z), 3, 0, TAU);
    g.fill();
  });
  g.fillStyle = 'rgba(210,225,235,.6)';
  g.font = '11px "Special Elite", monospace';
  g.textAlign = 'left';
  g.fillText('HARLAN FREIGHT CO. • DWG 9-A • 1953', 10, h - 8);
}

let selMap = 'depot';

function buildMapList() {
  const box = $('#mapList');
  box.innerHTML = '';
  for (const id in MAPS) {
    const M = MAPS[id];
    const b = document.createElement('button');
    b.className = 'mapcard' + (id === selMap ? ' sel' : '');
    b.setAttribute('aria-pressed', id === selMap);
    b.innerHTML = `<canvas width="480" height="320" aria-hidden="true"></canvas><div class="info"><span class="lbl">${escapeHTML(M.when)}</span><h3>${escapeHTML(M.name)}</h3><p class="sub">${escapeHTML(M.blurb)}</p><dl><dt>Areas</dt><dd>5, behind debris</dd><dt>Barricades</dt><dd>${M.walls.reduce((n, w) => n + w[6].filter((o) => o.w).length, 0)}</dd><dt>Soda machines</dt><dd>${M.sodas.length}, need power</dd><dt>Wall weapons</dt><dd>${M.wallbuys.length}</dd></dl></div>`;
    b.onclick = () => {
      selMap = id;
      buildMapList();
    };
    box.appendChild(b);
    drawBlueprint(b.querySelector('canvas'), M);
  }
  renderDiff($('#diffSeg'), (v) => {
    G.diff = v;
  });
  $('#mapGoNote').textContent = 'More maps are on the way.';
}

function renderDiff(el, onPick) {
  el.innerHTML = '';
  for (const k in DIFF) {
    const b = document.createElement('button');
    b.textContent = DIFF[k].label;
    b.setAttribute('aria-pressed', G.diff === k);
    b.onclick = () => {
      G.diff = k;
      onPick && onPick(k);
      renderDiff(el, onPick);
    };
    el.appendChild(b);
  }
}

$('#mapGo').onclick = () => startGame('solo');

$('#nameInput').addEventListener('input', (e) => {
  SET.game.name = cleanName(e.target.value);
  saveSet();
  NET.pres({
    n: SET.game.name,
  });
});

$('#hostBtn').onclick = () => {
  if (NET.role === 'host') {
    return;
  }
  NET.host_();
};

$('#lobbyLeave').onclick = () => {
  NET.leave();
  uiLobbyNote('');
};

$('#lobbyStart').onclick = () => {
  if (NET.role !== 'host') {
    return;
  }
  startGame('host');
};

let lobbyNoteText = '';

function uiLobbyNote(t) {
  lobbyNoteText = t;
  const n = $('#lobbyNote');
  if (n) {
    n.textContent = t;
  }
}

function uiLobby() {
  if ($('#scrLobby').hidden) {
    return;
  }
  $('#lobbyStatus').textContent = !NET.avail
    ? 'Co-op is not available in this view.'
    : NET.connected
      ? 'Connected. Everyone with this page open right now can see your game.'
      : 'Connecting…';
  const hosts = NET.hosts();
  const gl = $('#gameList');
  if (NET.role !== 'solo') {
    gl.innerHTML = '<div class="empty">You are in a squad. Leave it to join another game.</div>';
  } else {
    gl.innerHTML = hosts.length
      ? ''
      : '<div class="empty">No open games right now. Host one and share this page.</div>';
  }
  if (NET.role === 'solo') {
    hosts.forEach((h) => {
      const sq = NET.squadOf(h.peer).length;
      const s = h.presence;
      const el = document.createElement('div');
      el.className = 'li';
      el.innerHTML = `<div><b></b><br><span></span></div>`;
      el.querySelector('b').textContent = cleanName(s.n) + '’s game';
      el.querySelector('span').textContent =
        `Depot 9 • ${DIFF[s.L.diff] ? DIFF[s.L.diff].label : 'Normal'} • ${sq}/4 • ${s.m === 'game' ? 'in progress' : 'in lobby'}`;
      const b = document.createElement('button');
      b.className = 'btn';
      b.textContent = sq >= 4 ? 'Full' : 'Join';
      b.disabled = sq >= 4;
      b.onclick = () => NET.join(h.peer);
      el.appendChild(b);
      gl.appendChild(el);
    });
  }
  $('#hostBtn').hidden = NET.role !== 'solo';
  $('#hostBtn').disabled = !NET.connected;
  const lp = $('#lobbyPlayers');
  if (NET.role === 'solo') {
    lp.innerHTML = '<div class="empty">Host a game or join one to see the squad here.</div>';
    $('#myLobbyTitle').textContent = 'Your squad';
  } else {
    const hostPeer = NET.role === 'host' ? NET.me : NET.host;
    const sq = NET.squadOf(hostPeer);
    if (!sq.some((p) => p.sameTab)) {
      sq.push({
        peer: NET.me,
        sameTab: true,
        presence: {
          n: SET.game.name,
        },
      });
    }
    lp.innerHTML = '';
    sq.forEach((p) => {
      const el = document.createElement('div');
      el.className = 'li';
      el.innerHTML = '<b><span class="dot"></span></b><span></span>';
      el.querySelector('b').append(p.sameTab ? SET.game.name : cleanName(p.presence && p.presence.n));
      el.querySelector('span:last-child').textContent =
        (p.peer === hostPeer ? 'Host' : 'Player') + (p.sameTab ? ' • you' : '');
      lp.appendChild(el);
    });
    $('#myLobbyTitle').textContent = NET.role === 'host' ? 'Your lobby' : 'Squad';
  }
  $('#lobbyStart').hidden = NET.role !== 'host';
  $('#lobbyLeave').hidden = NET.role === 'solo';
  const note =
    NET.role === 'host'
      ? 'Start whenever your squad is in. Up to four players.'
      : NET.role === 'client'
        ? 'Waiting for the host to start the game.'
        : lobbyNoteText;
  $('#lobbyNote').textContent = note;
  if (NET.role === 'host') {
    let seg = $('#lobbyDiff');
    if (!seg) {
      const bar = document.createElement('div');
      bar.className = 'bar';
      bar.innerHTML = '<span class="lbl">Difficulty</span><div class="seg" id="lobbyDiff"></div>';
      $('#myLobby').insertBefore(bar, $('#lobbyPlayers'));
      seg = $('#lobbyDiff');
    }
    renderDiff(seg, (v) =>
      NET.pres({
        L: {
          map: 'depot',
          diff: v,
          st: 0,
        },
      }),
    );
  } else if ($('#lobbyDiff')) {
    $('#lobbyDiff').parentElement.remove();
  }
}

function uiStartClient() {
  startGame('client');
}

const PCT = (v) => Math.round(v * 100) + '%';

const SCHEMA = {
  video: [
    {
      k: 'quality',
      l: 'Quality preset',
      n: 'Ultra adds sharper shadows from more lamps, full-resolution rendering and every-frame shadow updates',
      t: 'seg',
      o: [
        ['low', 'Low'],
        ['medium', 'Medium'],
        ['high', 'High'],
        ['ultra', 'Ultra'],
      ],
    },
    {
      k: 'scale',
      l: 'Render scale',
      t: 'range',
      min: 0.5,
      max: 1,
      step: 0.05,
      f: PCT,
    },
    {
      k: 'shadows',
      l: 'Shadows',
      t: 'seg',
      o: [
        ['off', 'Off'],
        ['low', 'Flashlight'],
        ['high', 'All'],
      ],
    },
    {
      k: 'aa',
      l: 'Anti-aliasing',
      t: 'tog',
    },
    {
      k: 'bloom',
      l: 'Bloom',
      n: 'Glow around lamps, muzzle flashes and eyes',
      t: 'tog',
    },
    {
      k: 'dynres',
      l: 'Adaptive resolution',
      n: 'Lowers render scale briefly when the frame rate drops below 48',
      t: 'tog',
    },
    {
      k: 'fov',
      l: 'Field of view',
      t: 'range',
      min: 65,
      max: 100,
      step: 1,
      f: (v) => v + '°',
    },
    {
      k: 'bright',
      l: 'Brightness',
      t: 'range',
      min: 0.7,
      max: 1.7,
      step: 0.05,
      f: PCT,
    },
    {
      k: 'grain',
      l: 'Film grain',
      t: 'tog',
    },
    {
      k: 'chroma',
      l: 'Lens fringing',
      t: 'tog',
    },
    {
      k: 'bob',
      l: 'View bob',
      t: 'tog',
    },
    {
      k: 'fps',
      l: 'Show frame rate',
      t: 'tog',
    },
  ],
  audio: [
    {
      k: 'master',
      l: 'Master volume',
      t: 'range',
      min: 0,
      max: 1,
      step: 0.05,
      f: PCT,
    },
    {
      k: 'sfx',
      l: 'Effects',
      t: 'range',
      min: 0,
      max: 1,
      step: 0.05,
      f: PCT,
    },
    {
      k: 'music',
      l: 'Music',
      t: 'range',
      min: 0,
      max: 1,
      step: 0.05,
      f: PCT,
    },
    {
      k: 'zombies',
      l: 'Zombie voices',
      t: 'range',
      min: 0,
      max: 1.5,
      step: 0.05,
      f: PCT,
    },
    {
      k: 'voice',
      l: 'Announcer voice',
      n: 'Calls out power-ups with your browser’s speech voice',
      t: 'tog',
    },
  ],
  controls: [
    {
      k: 'padSens',
      l: 'Controller look speed',
      t: 'range',
      min: 0.3,
      max: 2.5,
      step: 0.05,
      f: (v) => v.toFixed(2),
    },
    {
      k: 'sens',
      l: 'Mouse sensitivity',
      t: 'range',
      min: 0.2,
      max: 3,
      step: 0.05,
      f: (v) => v.toFixed(2),
    },
    {
      k: 'adsSens',
      l: 'Aiming sensitivity',
      n: 'Multiplier while aiming down sights',
      t: 'range',
      min: 0.3,
      max: 1.2,
      step: 0.05,
      f: PCT,
    },
    {
      k: 'invertY',
      l: 'Invert vertical look',
      t: 'tog',
    },
    {
      k: 'aimToggle',
      l: 'Toggle aim',
      n: 'Click once to aim instead of holding',
      t: 'tog',
    },
    {
      k: 'sprintToggle',
      l: 'Toggle sprint',
      t: 'tog',
    },
    {
      k: 'crouchHold',
      l: 'Hold to crouch',
      n: 'Off: tap to crouch, hold to go prone',
      t: 'tog',
    },
  ],
  keys: 'keys',
  game: [
    {
      k: 'name',
      l: 'Your name',
      n: 'Shown to teammates in co-op',
      t: 'text',
    },
    {
      k: 'crosshair',
      l: 'Crosshair',
      t: 'tog',
    },
    {
      k: 'hitmarkers',
      l: 'Hit markers',
      t: 'tog',
    },
    {
      k: 'tags',
      l: 'Teammate name tags',
      t: 'tog',
    },
  ],
};

const TABS = [
  ['video', 'Video'],
  ['audio', 'Audio'],
  ['controls', 'Controls'],
  ['keys', 'Keybinds'],
  ['game', 'Gameplay'],
];

let setTab = 'video',
  capture = null;

function openSettings(tab) {
  setTab = tab || setTab;
  renderSettings();
  show('scrSettings');
}

$('#pSettings').onclick = () => openSettings(setTab);

function applySetting(cat) {
  saveSet();
  if (cat === 'video') {
    applyVideo();
  }
  if (cat === 'audio') {
    AU.applyVolumes();
  }
  if (cat === 'game') {
    NET.pres({
      n: SET.game.name,
    });
  }
  $('#fps').hidden = !SET.video.fps;
}

function renderSettings() {
  const tb = $('#setTabs');
  tb.innerHTML = '';
  TABS.forEach(([k, l]) => {
    const b = document.createElement('button');
    b.role = 'tab';
    b.textContent = l;
    b.setAttribute('aria-selected', k === setTab);
    b.onclick = () => {
      setTab = k;
      capture = null;
      renderSettings();
    };
    tb.appendChild(b);
  });
  const rows = $('#setRows');
  rows.innerHTML = '';
  if (SCHEMA[setTab] === 'keys') {
    KEY_ACTIONS.forEach(([a, l]) => {
      const row = document.createElement('div');
      row.className = 'row';
      row.innerHTML = `<div class="k"></div><div class="ctl"><button class="key" id="key_${a}"></button></div>`;
      row.querySelector('.k').textContent = l;
      const b = row.querySelector('.key');
      b.textContent = capture === a ? 'Press a key or mouse button…' : keyLabel(SET.keys[a]);
      b.classList.toggle('wait', capture === a);
      b.onclick = (e) => {
        e.stopPropagation();
        capture = a;
        renderSettings();
      };
      rows.appendChild(row);
    });
    const r = document.createElement('div');
    r.className = 'row';
    r.innerHTML =
      '<div class="k">Escape<small>Pause is always Escape</small></div><div class="ctl"><span class="sub">Fixed</span></div>';
    rows.appendChild(r);
    return;
  }
  const cat = setTab;
  SCHEMA[cat].forEach((s) => {
    const row = document.createElement('div');
    row.className = 'row';
    const k = document.createElement('div');
    k.className = 'k';
    k.textContent = s.l;
    if (s.n) {
      const sm = document.createElement('small');
      sm.textContent = s.n;
      k.appendChild(sm);
    }
    row.appendChild(k);
    const c = document.createElement('div');
    c.className = 'ctl';
    const id = `set_${cat}_${s.k}`;
    const v = SET[cat][s.k];
    if (s.t === 'range') {
      const inp = document.createElement('input');
      inp.type = 'range';
      inp.id = id;
      inp.min = s.min;
      inp.max = s.max;
      inp.step = s.step;
      inp.value = v;
      inp.setAttribute('aria-label', s.l);
      const out = document.createElement('output');
      out.textContent = s.f(v);
      inp.oninput = () => {
        SET[cat][s.k] = +inp.value;
        out.textContent = s.f(+inp.value);
        if (cat === 'video' && s.k === 'scale') {
        }
        applySetting(cat);
      };
      c.append(inp, out);
    } else if (s.t === 'tog') {
      const b = document.createElement('button');
      b.className = 'tog';
      b.id = id;
      b.role = 'switch';
      b.setAttribute('aria-checked', v);
      b.setAttribute('aria-label', s.l);
      b.onclick = () => {
        SET[cat][s.k] = !SET[cat][s.k];
        b.setAttribute('aria-checked', SET[cat][s.k]);
        applySetting(cat);
      };
      c.appendChild(b);
    } else if (s.t === 'seg') {
      const sg = document.createElement('div');
      sg.className = 'seg';
      s.o.forEach(([val, lab]) => {
        const b = document.createElement('button');
        b.textContent = lab;
        b.setAttribute('aria-pressed', v === val);
        b.onclick = () => {
          SET[cat][s.k] = val;
          if (s.k === 'quality') {
            const q = QUALITY[val];
            Object.assign(SET.video, {
              scale: q.scale,
              shadows: q.shadows,
              aa: q.aa,
              bloom: q.bloom,
            });
          }
          applySetting(cat);
          renderSettings();
        };
        sg.appendChild(b);
      });
      c.appendChild(sg);
    } else if (s.t === 'text') {
      const inp = document.createElement('input');
      inp.type = 'text';
      inp.id = id;
      inp.maxLength = 16;
      inp.value = v;
      inp.setAttribute('aria-label', s.l);
      inp.oninput = () => {
        SET[cat][s.k] = cleanName(inp.value);
        applySetting(cat);
      };
      c.appendChild(inp);
    }
    row.appendChild(c);
    rows.appendChild(row);
  });
}

$('#setReset').onclick = () => {
  if (setTab === 'keys') {
    SET.keys = JSON.parse(JSON.stringify(DEFAULTS.keys));
  } else {
    const keep = setTab === 'game' ? SET.game.name : null;
    SET[setTab] = JSON.parse(JSON.stringify(DEFAULTS[setTab]));
    if (keep) {
      SET.game.name = keep;
    }
  }
  capture = null;
  applySetting(setTab);
  renderSettings();
};

function captureKey(code) {
  if (!capture) {
    return false;
  }
  if (code !== 'Escape') {
    const prev = SET.keys[capture];
    for (const a in SET.keys) {
      if (SET.keys[a] === code && a !== capture) {
        SET.keys[a] = prev;
      }
    }
    SET.keys[capture] = code;
    saveSet();
  }
  capture = null;
  renderSettings();
  return true;
}

function uiPauseNote() {
  $('#pauseNote').textContent =
    G.net === 'solo'
      ? 'The depot waits for you.'
      : 'This is a co-op game. The zombies keep coming while you are paused.';
}

function pauseGame() {
  if (G.mode !== 'play' || G.paused) {
    return;
  }
  G.paused = true;
  if (G.net === 'solo') {
    AU.suspend();
  }
  for (const k of ['f', 'b', 'l', 'r']) {
    IN[k] = 0;
  }
  IN.fire = IN.aim = IN.use = IN.sprint = IN.crouch = IN.scores = false;
  uiPauseNote();
  screenStack = ['scrPause'];
  show('scrPause', false);
  document.body.classList.remove('playing');
}

function resumeGame() {
  if (G.mode !== 'play') {
    return;
  }
  G.paused = false;
  AU.resume();
  hideScreens();
  screenStack = [];
  document.body.classList.add('playing');
  requestLock();
}

$('#pResume').onclick = resumeGame;

$('#pRestart').onclick = () => {
  if (G.net === 'client') {
    showNet('Only the host can restart.');
    return;
  }
  startGame(G.net);
};

$('#pQuit').onclick = () => {
  if (G.net !== 'solo') {
    NET.leave();
  }
  uiToMenu();
};

function uiToMenu() {
  G.mode = 'menu';
  G.paused = false;
  clearRemotes();
  resetWorld();
  resetMe(0);
  spawnMenuZombies();
  $('#hud').hidden = true;
  $('#touch').hidden = true;
  document.body.classList.remove('playing');
  screenStack = ['scrMain'];
  show('scrMain', false);
  updateBest();
  AU.stopLoop('drone');
  AU.stopLoop('rain');
  AU.stopLoop('radio');
  AU._menuOn = false;
  menuMusic();
  try {
    document.exitPointerLock();
  } catch (e) {}
}

function showOverScreen(best) {
  document.body.classList.remove('playing');
  $('#touch').hidden = true;
  const all = [
    {
      name: SET.game.name,
      pts: ME.pts,
      st: ME.stats,
      me: true,
    },
  ].concat(
    NET.remotes().map((r) => ({
      name: r.name,
      pts: r.pts,
      st: r.st,
    })),
  );
  $('#overTitle').textContent = `You survived ${G.round} ${G.round === 1 ? 'round' : 'rounds'}`;
  $('#overSub').textContent =
    `${G.net === 'solo' ? 'You' : 'Your squad'} held Depot 9 for ${G.round} wave${G.round === 1 ? '' : 's'} on ${DIFF[G.diff].label}. ` +
    (G.round > best
      ? best
        ? `A new record for this device (previous best: wave ${best}).`
        : 'A new record for this device.'
      : `Best on this device: wave ${best}.`);
  $('#overTable').innerHTML =
    `<tr><th>Player</th><th>Points earned</th><th>Kills</th><th>Headshots</th><th>Downs</th><th>Revives</th></tr>` +
    all
      .map(
        (p) =>
          `<tr><td>${escapeHTML(p.name)}${p.me ? ' (you)' : ''}</td><td>${p.me ? ME.stats.earned : p.pts}</td><td>${p.st.kills}</td><td>${p.st.heads}</td><td>${p.st.downs}</td><td>${p.st.revives}</td></tr>`,
      )
      .join('');
  $('#oAgain').textContent = G.net === 'client' ? 'Waiting for the host…' : 'Play again';
  $('#oAgain').disabled = G.net === 'client';
  screenStack = ['scrOver'];
  show('scrOver', false);
}

$('#oAgain').onclick = () => {
  if (G.net === 'client') {
    return;
  }
  startGame(G.net === 'host' ? 'host' : 'solo');
};

$('#oMenu').onclick = () => {
  if (G.net !== 'solo') {
    NET.leave();
  }
  uiToMenu();
};

function startGame(role) {
  AU.init();
  G.net = role;
  NET.role = role === 'solo' ? NET.role : role;
  if (role === 'host') {
    NET.startHosting();
  }
  if (role === 'client') {
    NET.rp.clear();
    NET.lastSeen = {};
    NET.out = [];
  }
  clearRemotes();
  resetWorld();
  const slot =
    role === 'client'
      ? 1 + (Math.abs(NET.me.split('').reduce((a, c) => a * 31 + c.charCodeAt(0), 7)) % 3)
      : 0;
  resetMe(slot);
  ME.yaw = 0;
  if (role === 'client') {
    G.inter = 1e9;
  }
  G.mode = 'play';
  G.paused = false;
  hideScreens();
  screenStack = [];
  $('#hud').hidden = false;
  $('#touch').hidden = !TOUCH;
  document.body.classList.add('playing');
  $('#round').textContent = '';
  $('#fps').hidden = !SET.video.fps;
  AU.stopLoop('menu', 1.5);
  AU._menuOn = false;
  AU.whenBuf('laugh', () => {
    if (G.mode === 'play') {
      setTimeout(
        () =>
          AU.play('laugh', {
            bus: 'mus',
            g: 0.9,
            wet: 0.6,
          }),
        400,
      );
    }
  });
  AU.whenReady(() => {
    if (G.mode !== 'play') {
      return;
    }
    AU.loop('drone', 'mus_drone', {
      bus: 'mus',
      g: 0.7,
    });
    AU.loop('rain', 'rain', {
      bus: 'amb',
      g: 0.28,
    });
    if (WORLD.radio) {
      AU.loop('radio', 'radio', {
        pos: [WORLD.radio.x, WORLD.radio.y, WORLD.radio.z],
        ref: 1.5,
        roll: 1.4,
        g: 0.35,
      });
    }
  });
  requestLock();
  last = performance.now();
}

function requestLock() {
  if (TOUCH) {
    return;
  }
  try {
    const r = canvas.requestPointerLock();
    if (r && r.catch) {
      r.catch(() => {
        G.noLock = true;
      });
    }
  } catch (e) {
    G.noLock = true;
  }
}

function actionFor(code) {
  for (const a in SET.keys) {
    if (SET.keys[a] === code) {
      return a;
    }
  }
  return null;
}

function act(a, down, repeat) {
  switch (a) {
    case 'forward':
      IN.f = down ? 1 : 0;
      break;

    case 'back':
      IN.b = down ? 1 : 0;
      break;

    case 'left':
      IN.l = down ? 1 : 0;
      break;

    case 'right':
      IN.r = down ? 1 : 0;
      break;

    case 'sprint':
      IN.sprint = down;
      if (down && !repeat) {
        IN.sprintT = !IN.sprintT;
      }
      break;

    case 'jump':
      if (down && !repeat) {
        IN.jump = true;
      }
      break;

    case 'crouch':
      if (down && !repeat) {
        IN.crouchHT = 0;
        IN.proneLock = false;
        if (SET.controls.crouchHold) {
          ME.stance = 1;
        } else {
          ME.stance = ME.stance === 1 ? 0 : 1;
        }
      }
      if (!down && SET.controls.crouchHold && ME.stance === 1) {
        ME.stance = 0;
      }
      IN.crouch = down;
      break;

    case 'prone':
      if (down && !repeat) {
        ME.stance = ME.stance === 2 ? 0 : 2;
      }
      break;

    case 'fire':
      IN.fire = down;
      break;

    case 'aim':
      IN.aim = down;
      if (down && !repeat) {
        IN.aimT = !IN.aimT;
      }
      break;

    case 'reload':
      if (down) {
        startReload();
      }
      break;

    case 'use':
      IN.use = down;
      if (down && !repeat) {
        IN.usePressed = true;
      }
      break;

    case 'melee':
      if (down && !repeat) {
        doKnife();
      }
      break;

    case 'grenade':
      if (down && !repeat) {
        throwNade();
      }
      break;

    case 'swap':
      if (down && !repeat) {
        switchWeapon();
      }
      break;

    case 'weapon1':
      if (down) {
        switchWeapon(0);
      }
      break;

    case 'weapon2':
      if (down) {
        switchWeapon(1);
      }
      break;

    case 'flashlight':
      if (down && !repeat) {
        ME.flashOn = !ME.flashOn;
        AU.play('dry', {
          g: 0.6,
        });
      }
      break;

    case 'scores':
      IN.scores = down;
      break;
  }
}

const playing = () => G.mode === 'play' && !G.paused;

window.addEventListener('keydown', (e) => {
  if (capture) {
    e.preventDefault();
    captureKey(e.code);
    return;
  }
  if (e.code === 'Escape') {
    if (G.mode === 'play' && G.paused) {
      e.preventDefault();
      resumeGame();
    } else if (G.mode === 'play' && G.noLock) {
      pauseGame();
    } else if (!$('#scrSettings').hidden || !$('#scrMaps').hidden || !$('#scrLobby').hidden) {
      back();
    }
    return;
  }
  if (!playing()) {
    return;
  }
  const a = actionFor(e.code);
  if (a) {
    e.preventDefault();
    act(a, true, e.repeat);
  }
});

window.addEventListener('keyup', (e) => {
  const a = actionFor(e.code);
  if (a) {
    act(a, false, false);
  }
});

canvas.addEventListener('mousedown', (e) => {
  if (!playing()) {
    return;
  }
  if (document.pointerLockElement !== canvas && !G.noLock && !TOUCH) {
    requestLock();
    return;
  }
  const a = actionFor('Mouse' + e.button);
  if (a) {
    e.preventDefault();
    act(a, true, false);
  }
});

window.addEventListener(
  'mousedown',
  (e) => {
    if (capture && e.target.closest('#scrSettings')) {
      if (
        e.target.classList &&
        e.target.classList.contains('key') &&
        e.button === 0 &&
        !e.target.classList.contains('wait')
      ) {
        return;
      }
      e.preventDefault();
      captureKey('Mouse' + e.button);
    }
  },
  true,
);

window.addEventListener('mouseup', (e) => {
  const a = actionFor('Mouse' + e.button);
  if (a) {
    act(a, false, false);
  }
});

canvas.addEventListener('contextmenu', (e) => e.preventDefault());

window.addEventListener(
  'wheel',
  (e) => {
    if (playing()) {
      switchWeapon();
    }
  },
  {
    passive: true,
  },
);

document.addEventListener('mousemove', (e) => {
  if (!playing() || TOUCH) {
    return;
  }
  if (document.pointerLockElement !== canvas && !G.noLock) {
    return;
  }
  const k =
    0.0022 *
    SET.controls.sens *
    (ME.adsK > 0.5 ? SET.controls.adsSens * (GUNS[curW().id].adsFov ? 0.5 : 1) : 1);
  const dx = clamp(e.movementX, -300, 300),
    dy = clamp(e.movementY, -300, 300);
  ME.yaw -= dx * k;
  ME.pitch -= dy * k * (SET.controls.invertY ? -1 : 1);
  IN.lookDX += dx;
  IN.lookDY += dy;
});

document.addEventListener('pointerlockchange', () => {
  if (document.pointerLockElement !== canvas && G.mode === 'play' && !G.paused && !G.noLock) {
    pauseGame();
  }
});

document.addEventListener('pointerlockerror', () => {
  G.noLock = true;
});

document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    pauseGame();
  }
});

window.addEventListener('blur', () => {
  for (const k of ['f', 'b', 'l', 'r']) {
    IN[k] = 0;
  }
  IN.fire = IN.aim = IN.use = IN.sprint = false;
});

$('#c').addEventListener('click', () => {
  AU.init();
});

const touchMove = {
  active: false,
  x: 0,
  y: 0,
  id: null,
};

let lookId = null,
  lookX = 0,
  lookY = 0;

if (TOUCH) {
  const stick = $('#stick'),
    knob = $('#knob');
  const moveStick = (t) => {
    const r = stick.getBoundingClientRect();
    let x = (t.clientX - r.left - r.width / 2) / (r.width / 2),
      y = (t.clientY - r.top - r.height / 2) / (r.height / 2);
    const l = Math.hypot(x, y);
    if (l > 1) {
      x /= l;
      y /= l;
    }
    touchMove.x = x;
    touchMove.y = y;
    knob.style.transform = `translate(${x * 40}px,${y * 40}px)`;
  };
  stick.addEventListener(
    'touchstart',
    (e) => {
      const t = e.changedTouches[0];
      touchMove.id = t.identifier;
      touchMove.active = true;
      moveStick(t);
      e.preventDefault();
    },
    {
      passive: false,
    },
  );
  window.addEventListener(
    'touchmove',
    (e) => {
      for (const t of e.changedTouches) {
        if (t.identifier === touchMove.id) {
          moveStick(t);
        } else if (t.identifier === lookId && playing()) {
          const k = 0.006 * SET.controls.sens * (ME.adsK > 0.5 ? SET.controls.adsSens : 1);
          const dx = t.clientX - lookX,
            dy = t.clientY - lookY;
          ME.yaw -= dx * k;
          ME.pitch -= dy * k * (SET.controls.invertY ? -1 : 1);
          IN.lookDX += dx * 3;
          IN.lookDY += dy * 3;
          lookX = t.clientX;
          lookY = t.clientY;
        }
      }
    },
    {
      passive: true,
    },
  );
  const endT = (e) => {
    for (const t of e.changedTouches) {
      if (t.identifier === touchMove.id) {
        touchMove.active = false;
        touchMove.id = null;
        touchMove.x = touchMove.y = 0;
        knob.style.transform = '';
      }
      if (t.identifier === lookId) {
        lookId = null;
      }
    }
  };
  window.addEventListener('touchend', endT);
  window.addEventListener('touchcancel', endT);
  canvas.addEventListener(
    'touchstart',
    (e) => {
      const t = e.changedTouches[0];
      if (t.clientX > innerWidth * 0.4 && lookId === null) {
        lookId = t.identifier;
        lookX = t.clientX;
        lookY = t.clientY;
      }
      e.preventDefault();
    },
    {
      passive: false,
    },
  );
  const btn = (id, down, up) => {
    const el = $('#' + id);
    el.addEventListener(
      'touchstart',
      (e) => {
        e.preventDefault();
        el.classList.add('on');
        down && down();
        const t = e.changedTouches[0];
        if (id === 'tFire' && lookId === null) {
          lookId = t.identifier;
          lookX = t.clientX;
          lookY = t.clientY;
        }
      },
      {
        passive: false,
      },
    );
    el.addEventListener(
      'touchend',
      (e) => {
        e.preventDefault();
        el.classList.remove('on');
        up && up();
      },
      {
        passive: false,
      },
    );
  };
  btn(
    'tFire',
    () => (IN.fire = true),
    () => (IN.fire = false),
  );
  btn(
    'tAim',
    () => {
      IN.aimT = !IN.aimT;
      IN.aim = IN.aimT;
    },
    () => $('#tAim').classList.toggle('on', IN.aimT),
  );
  btn(
    'tUse',
    () => {
      IN.use = true;
      IN.usePressed = true;
    },
    () => (IN.use = false),
  );
  btn('tRel', startReload);
  btn('tSwap', () => switchWeapon());
  btn('tMelee', doKnife);
  btn('tNade', throwNade);
  btn('tJump', () => (IN.jump = true));
  btn('tCrouch', () => {
    ME.stance = (ME.stance + 1) % 3;
  });
  btn('tPause', pauseGame);
}

const PAD = {
  idx: -1,
  prev: [],
  last: 0,
  active: false,
  navT: 0,
  useHeldT: 0,
};

window.addEventListener('gamepadconnected', (e) => {
  PAD.idx = e.gamepad.index;
  showNet('Controller connected');
});

window.addEventListener('gamepaddisconnected', (e) => {
  if (PAD.idx === e.gamepad.index) {
    PAD.idx = -1;
    PAD.active = false;
  }
});

const dz = (v, d = 0.16) => (Math.abs(v) < d ? 0 : (Math.sign(v) * (Math.abs(v) - d)) / (1 - d));

function padButtons(gp) {
  return gp.buttons.map((b) => b && (b.pressed || b.value > 0.5));
}

function pollPad(dt) {
  const pads = navigator.getGamepads ? navigator.getGamepads() : [];
  let gp = pads[PAD.idx];
  if (!gp) {
    gp = [...pads].find((p) => p);
    if (!gp) {
      return;
    }
    PAD.idx = gp.index;
  }
  const b = padButtons(gp),
    pr = PAD.prev,
    down = (i) => b[i] && !pr[i],
    up = (i) => !b[i] && pr[i];
  const lx = dz(gp.axes[0] || 0),
    ly = dz(gp.axes[1] || 0),
    rx = dz(gp.axes[2] || 0, 0.12),
    ry = dz(gp.axes[3] || 0, 0.12);
  if (b.some(Boolean) || lx || ly || rx || ry) {
    PAD.active = true;
  }
  if (G.mode === 'play' && !G.paused) {
    touchMove.active = !!(lx || ly);
    if (touchMove.active) {
      touchMove.x = lx;
      touchMove.y = ly;
    }
    const curve = (v) => Math.sign(v) * Math.pow(Math.abs(v), 1.8);
    let assist = 1;
    if (ME.adsK > 0.3) {
      camera.getWorldDirection(_v1);
      for (const z of ZBS) {
        if (z.dead) {
          continue;
        }
        const to = new THREE.Vector3(z.x, 1.4, z.z).sub(camera.position);
        const d = to.length();
        if (d < 30 && to.normalize().dot(_v1) > Math.cos(0.08 + 0.6 / d)) {
          assist = 0.45;
          break;
        }
      }
    }
    const k = 3.2 * SET.controls.padSens * dt * (ME.adsK > 0.5 ? SET.controls.adsSens : 1) * assist;
    ME.yaw -= curve(rx) * k;
    ME.pitch -= curve(ry) * k * 0.75 * (SET.controls.invertY ? -1 : 1);
    IN.lookDX += rx * 12;
    IN.lookDY += ry * 12;
    IN.fire = !!b[7];
    IN.aim = !!b[6];
    if (down(0)) {
      IN.jump = true;
    }
    if (down(1)) {
      PAD.bT = 0;
      ME.stance = ME.stance === 1 ? 0 : ME.stance === 2 ? 1 : 1;
    }
    if (b[1]) {
      PAD.bT = (PAD.bT || 0) + dt;
      if (PAD.bT > 0.45 && ME.stance === 1) {
        ME.stance = 2;
      }
    }
    if (b[2]) {
      PAD.useHeldT += dt;
      if (focus) {
        IN.use = true;
        if (down(2)) {
          IN.usePressed = true;
        }
      }
    } else {
      if (up(2) && PAD.useHeldT < 0.3 && !focus) {
        startReload();
      }
      PAD.useHeldT = 0;
      IN.use = false;
    }
    if (down(3)) {
      switchWeapon();
    }
    if (down(5)) {
      throwNade();
    }
    if (down(4)) {
      ME.flashOn = !ME.flashOn;
    }
    if (down(11)) {
      doKnife();
    }
    if (b[10] && ly < -0.3) {
      IN.sprint = true;
    } else if (!b[10] && !IN.sprintT) {
      IN.sprint = false;
    }
    if (down(10)) {
      IN.sprintT = !IN.sprintT;
    }
    IN.scores = !!b[8];
    if (down(9)) {
      pauseGame();
    }
    if (down(12)) {
      ME.flashOn = !ME.flashOn;
    }
  } else {
    PAD.navT -= dt;
    const vy = ly || (b[13] ? 1 : b[12] ? -1 : 0),
      vx = lx || (b[15] ? 1 : b[14] ? -1 : 0);
    if ((Math.abs(vy) > 0.5 || Math.abs(vx) > 0.5) && PAD.navT <= 0) {
      PAD.navT = 0.22;
      moveFocus(Math.abs(vy) > Math.abs(vx) ? Math.sign(vy) : Math.sign(vx));
    }
    if (down(0) && document.activeElement && document.activeElement.click) {
      document.activeElement.click();
    }
    if (down(1)) {
      if (G.mode === 'play' && G.paused) {
        resumeGame();
      } else if (!$('#scrMain').hidden) {
      } else {
        back();
      }
    }
    if (down(9) && G.mode === 'play' && G.paused) {
      resumeGame();
    }
  }
  PAD.prev = b;
}

function moveFocus(dir) {
  const scr = SCREENS.map((id) => $('#' + id)).find((e) => !e.hidden);
  if (!scr) {
    return;
  }
  const items = $$('button:not([disabled]), input, [tabindex="0"]', scr).filter(
    (e) => e.offsetParent !== null,
  );
  if (!items.length) {
    return;
  }
  const i = items.indexOf(document.activeElement);
  const n = items[(i + dir + items.length) % items.length];
  n.focus();
  n.scrollIntoView({
    block: 'nearest',
  });
  if (n.type === 'range' && Math.abs(dir) === 1 && false) {
    n.stepUp();
  }
}

let menuT = 0;

const menuZ = [];

function spawnMenuZombies() {
  menuZ.forEach((z) => zRemove(z));
  menuZ.length = 0;
  for (let i = 0; i < 3; i++) {
    const z = zCreate(9e3 + i, 'walk');
    z.x = -6 + i * 5;
    z.z = -7.5 + i * 0.6;
    z.y = 0;
    z.yaw = Math.PI / 2;
    z.anim = 0;
    z.mdir = i % 2 ? -1 : 1;
    menuZ.push(z);
  }
}

function menuUpdate(dt) {
  menuT += dt;
  G.time += dt;
  const a = menuT * 0.05;
  camera.position.set(Math.sin(a) * 3.5, 1.75 + Math.sin(menuT * 0.3) * 0.08, 3.6 + Math.cos(a) * 1.2);
  camera.lookAt(Math.sin(a * 0.7) * 4, 1.4, -6);
  camera.fov = 68;
  camera.updateProjectionMatrix();
  for (const z of menuZ) {
    z.x += z.mdir * 0.45 * dt;
    if (z.x > 9) {
      z.mdir = -1;
    }
    if (z.x < -9) {
      z.mdir = 1;
    }
    z.yaw = z.mdir > 0 ? Math.PI / 2 : -Math.PI / 2;
    z.moveSpd = 0.45;
    animZombie(z, dt);
  }
  updateLights(dt, G.time);
  updateFX(dt);
  updateCrateVisual(dt);
  AU.setListener(camera.position.x, camera.position.y, camera.position.z, 0, 0);
}

let last = performance.now(),
  fpsAcc = 0,
  fpsN = 0;

function frame(now) {
  requestAnimationFrame(frame);
  const dt = Math.min(0.05, (now - last) / 1e3);
  last = now;
  fpsAcc += dt;
  fpsN++;
  if (fpsAcc > 0.5) {
    if (SET.video.fps) {
      $('#fps').textContent = Math.round(fpsN / fpsAcc) + ' fps';
    }
    fpsAcc = 0;
    fpsN = 0;
  }
  pollPad(dt);
  if (TOUCH) {
    $('#rotate').hidden = !(G.mode === 'play' && innerHeight > innerWidth);
  }
  if (G.mode === 'play') {
    if (!(G.paused && G.net === 'solo')) {
      if (G.paused) {
        IN.fire = false;
      }
      gameUpdate(dt);
    }
  } else if (G.mode === 'menu') {
    menuUpdate(dt);
  } else {
    updateLights(dt, (G.time += dt));
    updateFX(dt);
    updateBoards(dt);
    if (G.mode === 'over') {
      G.overT = (G.overT || 0) + dt;
      const a = G.overT * 0.07 + 0.6;
      camera.position.set(-2 + Math.cos(a) * 13, 4.7 + Math.sin(G.overT * 0.2) * 0.3, 14 + Math.sin(a) * 4.6);
      camera.lookAt(-2 + Math.cos(a + 0.9) * 4, 0.8, 14 + Math.sin(a + 0.9) * 2);
      camera.fov = 62;
      camera.updateProjectionMatrix();
      for (const z of ZBS) {
        if (!z.dead && z.anim === 0) {
          z.yaw += Math.sin(G.overT * 0.4 + z.id) * dt * 0.5;
          z.x += Math.sin(z.yaw) * dt * 0.4;
          z.z += Math.cos(z.yaw) * dt * 0.4;
        }
        animZombie(z, dt);
      }
      POST.mat.uniforms.desat.value = damp(POST.mat.uniforms.desat.value, 0.55, 1, dt);
      POST.mat.uniforms.hurt.value = damp(POST.mat.uniforms.hurt.value, 0.25, 1, dt);
      POST.mat.uniforms.blur.value = 0;
      AU.setListener(camera.position.x, camera.position.y, camera.position.z, a, 0);
    } else {
      for (const z of ZBS) {
        animZombie(z, dt);
      }
    }
  }
  dynRes(dt);
  POST.mat.uniforms.time.value = now / 1e3;
  renderFrame(G.mode === 'play' && !ME.dead);
}

function boot() {
  buildTextures();
  buildMaterials();
  buildEnvironment();
  zInit();
  VM.init();
  initGameLights();
  buildMap('depot');
  applyVideo();
  resetWorld();
  resetMe(0);
  spawnMenuZombies();
  updateBest();
  uiCoopAvail();
  $('#loading').hidden = true;
  showTitle();
  requestAnimationFrame(frame);
  NET.init();
}

let booted = false;

const doBoot = () => {
  if (booted) {
    return;
  }
  booted = true;
  try {
    boot();
  } catch (e) {
    $('#loading').textContent = 'The depot failed to load: ' + e.message;
    console.error(e);
  }
};

if (document.fonts && document.fonts.load) {
  Promise.all(
    ['40px Creepster', '20px "Special Elite"', '20px Oswald', '40px Yellowtail'].map((f) =>
      document.fonts.load(f),
    ),
  ).then(doBoot, doBoot);
  setTimeout(doBoot, 3e3);
} else {
  doBoot();
}
